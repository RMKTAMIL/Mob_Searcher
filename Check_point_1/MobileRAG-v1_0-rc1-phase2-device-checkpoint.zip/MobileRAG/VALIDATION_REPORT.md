# Validation report: Phase 1 (core reliability)

Scope: Phase 1 only (PowerGate, WorkManager pause/resume, checkpoint verification). This file did not exist in the
1.0.0-rc1 zip and was created in this session. Everything below is what was actually executed; anything not listed as run was not run.

## 1. Environment
| Item | Result |
|---|---|
| Android SDK / `ANDROID_HOME` | not present |
| Gradle | not installed |
| JDK | OpenJDK 21 (no `javac` binary) |
| Kotlin compiler | `kotlinc` 1.9.24 (same version as the project), fetched from the JetBrains GitHub release |
| JUnit jar | not available (no Maven access) |
| Reachability (6 s `curl` timeout) | `dl.google.com`, `services.gradle.org`, `maven.google.com`, `repo.maven.apache.org`, `plugins.gradle.org`: all failed to connect (HTTP code 000) |

## 2. Build status
**Android build: NOT performed. Blocker:** no Android SDK or Gradle in the sandbox, and the Google/Gradle/Maven hosts needed to
fetch them are unreachable from it. `gradle assembleDebug` and `gradle testDebugUnitTest` therefore did not run, and the
APK INTERNET-permission check did not run.

What was compiled instead (kotlinc 1.9.24, kotlinx-coroutines from the compiler distribution): `power/PowerPolicy.kt`,
`power/PowerGate.kt`, `index/ResumePlanner.kt`, `index/ChangeDetection.kt`, `index/Fingerprint.kt`, `data/Status.kt` and the five
test classes below. Compilation succeeded with no errors.

Not compiled by any compiler (reviewed by reading only): `power/AndroidPowerSource.kt`, `semantic/SemanticIndexer.kt`,
`index/IndexWorker.kt`, `index/IndexScheduler.kt`, `settings/Prefs.kt`, `AppContainer.kt`, `build.gradle.kts`, and the two
instrumented tests. Review found and fixed one compile error of mine in `AppContainer.kt` (a trailing lambda would have bound
to `PowerGate`'s `sleep` parameter instead of `config`). Other errors may remain; the README's warning that the project
has never been compiled still applies.

## 3. Tests executed
Runner: a **local shim of the JUnit API** (`@Test`, `Assert.*`) plus a small reflection runner, kept outside the repository
under `/home/claude/tools/shim`, because no JUnit jar was reachable. This is **not** a Gradle/JUnit run. Assertion semantics
of the shim match JUnit for the calls these tests use, but a real `gradle testDebugUnitTest` is still required.

Command shape:
```
kotlinc -jvm-target 17 -cp kotlinx-coroutines-core-jvm.jar -d out  <shim> <pure main files> <test files>
java -cp out:kotlinx-coroutines-core-jvm.jar:kotlin-stdlib.jar RunnerKt <test classes>
```

Result: **45 passed, 0 failed.**

```
PASS PowerPolicyTest.androidStatusMapping
PASS PowerPolicyTest.batteryAboveThresholdProceeds
PASS PowerPolicyTest.batteryAtThresholdProceeds
PASS PowerPolicyTest.batteryBelowThresholdPauses
PASS PowerPolicyTest.chargingCheckComesBeforeThermal
PASS PowerPolicyTest.chargingNotRequiredRunsOnBatteryAboveFloor
PASS PowerPolicyTest.chargingRequiredAndCharging
PASS PowerPolicyTest.chargingRequiredAndStateUnreadablePauses
PASS PowerPolicyTest.chargingRequiredButOnBatteryPauses
PASS PowerPolicyTest.criticalThermalPausesByDefault
PASS PowerPolicyTest.lowBatteryIgnoredWhileCharging
PASS PowerPolicyTest.missingStatusMapsToUnknownNotNormal
PASS PowerPolicyTest.moderateThermalThrottlesByDefault
PASS PowerPolicyTest.normalThermalContinuesWithoutDelay
PASS PowerPolicyTest.severeThermalPausesByDefault
PASS PowerPolicyTest.thermalBehaviourIsConfigurable
PASS PowerPolicyTest.unknownBatteryLevelOnBatteryPauses
PASS PowerPolicyTest.unknownThermalIsNotReportedAsNormalAndIsThrottled
PASS PowerPolicyTest.zeroFloorDisablesBatteryCheck
PASS PowerGateTest.cancellationDuringThrottleIsPromptAndPropagates
PASS PowerGateTest.checkDoesNotSleep
PASS PowerGateTest.configurationIsReadFreshForEveryBatch
PASS PowerGateTest.normalThermalDoesNotWait
PASS PowerGateTest.pauseThenResumeWhenConditionsRecover
PASS PowerGateTest.throttleWaitsBeforeTheBatch
PASS PowerGateTest.unplugDuringThrottleWaitPausesTheBatch
PASS ResumePlannerTest.chargingPreferenceKeepsTheChargerConstraintForEveryPause
PASS ResumePlannerTest.delayGrowsWhileNothingProgressesAndIsCapped
PASS ResumePlannerTest.givesUpAfterTooManyPausesWithoutProgress
PASS ResumePlannerTest.idleCounterIncrementsWithoutProgress
PASS ResumePlannerTest.negativeStoredCounterIsTreatedAsZero
PASS ResumePlannerTest.notChargingWaitsOnTheChargerConstraintWithoutPolling
PASS ResumePlannerTest.progressResetsTheIdleCounter
PASS ResumePlannerTest.thermalPauseWaitsWithADelay
PASS ChangeDetectionTest.failedExhausted
PASS ChangeDetectionTest.failedWithRetriesLeft
PASS ChangeDetectionTest.modifiedSize
PASS ChangeDetectionTest.modifiedTime
PASS ChangeDetectionTest.newFile
PASS ChangeDetectionTest.skippedStaysSkipped
PASS ChangeDetectionTest.staleMarkerForcesWork
PASS ChangeDetectionTest.unchanged
PASS FingerprintTest.differentTailDiffers
PASS FingerprintTest.identicalContentSameFingerprint
PASS FingerprintTest.smallFilesWork
TOTAL passed=45 failed=0
```

Note: the first run had 3 failures in the existing `FingerprintTest` (`File.createTempFile("fp", ...)`: prefix shorter than 3
characters is rejected by the JDK). That is a defect in the existing test, unrelated to Phase 1 code. It was fixed in the test
(`"fpt"`) and the run above is the re-run.

### Coverage against the Phase 1 test list
| Required case | Where | Status |
|---|---|---|
| Charging required / not charging | `PowerPolicyTest` (4 cases incl. unreadable state) | run, pass |
| Battery below / above threshold | `PowerPolicyTest` (below, at, above, while charging, unknown, floor 0) | run, pass |
| Thermal throttling and pausing | `PowerPolicyTest` (normal/moderate/severe/critical, configurable), `PowerGateTest` (throttle wait, recover after pause, unplug during throttle) | run, pass |
| Missing thermal information | `PowerPolicyTest` (`UNKNOWN` is throttled and reported as unknown; status mapping of null/-1/99) | run, pass |
| Cancellation | `PowerGateTest.cancellationDuringThrottleIsPromptAndPropagates` (real `delay`, cancelled within 5 s bound) | run, pass. **Worker-level cancellation: no executable test** |
| Process interruption and resumption | `EmbeddingCheckpointTest` (`completedFilesStayCompletedAfterRestart`, `pendingWorkSurvivesRepeatedRestarts`; restart = close and reopen the DB) | **written, not run** (needs device) |
| Duplicate work scheduling | `IndexSchedulingTest` (4 cases, WorkManager test driver) | **written, not run** (needs device) |
| Failed files and recovery | `EmbeddingCheckpointTest.failedFileDoesNotBlockTheOthers...`, `exhaustedFailureBecomesEligibleAgain...` | **written, not run** |
| Changed file re-indexing | `EmbeddingCheckpointTest.changedFileIsReEmbedded...`; existing `ChangeDetectionTest` (run, pass) | DB part **not run**; change detection run, pass |
| Duplicate embedding prevention | `EmbeddingCheckpointTest.savedFileIsNotEmbeddedAgain`, `identicalFileReusesVectors...` | **written, not run** |
| Resume planning / bounded retries | `ResumePlannerTest` (8 cases: constraints, back-off, cap, reset on progress, give-up) | run, pass |

Not executed at all: the other existing JVM test classes (tokenizers, search, extract, etc.; Phase 1 did not touch that
code), and all four existing instrumented classes.

## 4. Device validation
**None.** No test was run on the realme RMX5000 or any emulator. No thermal, battery, reboot or process-death behaviour has
been observed on real hardware. Nothing in this report is a device measurement.

## 5. Phase 1 completion criteria
| Criterion | Status |
|---|---|
| PowerGate integrated into the actual indexing worker | Implemented (`IndexWorker` -> `SemanticIndexer` gate); not compiled with Gradle |
| Indexing can safely pause and resume | Implemented by design (batch-boundary pause, DB-derived pending set, unique resume job); pause/resume **not exercised by an executable test** |
| Existing indexing and duplicate prevention remain functional | Existing logic untouched; relevant pure tests pass; DB-level checks written but not run |
| Relevant tests pass | The 45 tests above pass under the shim runner; instrumented tests not run |
| Android build succeeds or blocker documented | Blocker documented in section 2 |

Conclusion: Phase 1 code and tests are in place, but it is **not verified** by a Gradle build or on a device. The next session must
start with a CI run and the instrumented tests (see DEVELOPMENT_PROGRESS.md, "Handoff").

## 6. Remaining limitations
See "Unresolved issues / limitations" in DEVELOPMENT_PROGRESS.md. Headline items: OEM thermal reporting unmeasured (the OS
reports NONE for both "cool" and "no data" on API 29+); no Settings UI for the battery floor / thermal actions; the
extraction phase is not gated; the gate call inside the image loop touches `imagePhase`; default-on charging-only now
defers semantic indexing on battery.


## 7. Phase 2 validation (2026-11-04)

- Source changes implemented: image tensor batching, provider selection with CPU retry, configurable inference settings, bounded thumbnail cache, and benchmark extension.
- Added `ImageBatchPlannerTest` for stable input/output ordering, incomplete final batches, per-item fallback after batch failure, and invalid batch sizes.
- **Not run:** Android/Gradle build, all Gradle unit tests, instrumented thumbnail/cache tests, provider tests on Android, and RMX5000 device validation. This environment has no Gradle executable/wrapper or Android SDK.
- **Not measured:** CPU vs XNNPACK vs NNAPI comparison, actual gallery indexing throughput, search latency, and peak memory profiling. The benchmark extension only measures synthetic bitmap batch latency on the configured provider when run on a device. No measurements are fabricated here.
- Thumbnail cache has been added to `AppContainer`, but existing image presentation call sites have not yet been switched over; this is an integration gap, not a claim that repeated UI image decoding is already eliminated.
- ONNX Runtime remains pinned at 1.19.2. Provider registration is reflective to avoid compiling against methods absent from the pinned Android artifact; actual API/provider availability must be validated on target hardware.


## 8. Phase 2 final risk-fix validation (2026-11-04)

### Source changes
- `SemanticIndexer.textPhase`: explicitly rethrows `CancellationException` before the ordinary `Exception` handler, so cancellation cannot call `markFailed`.
- `SemanticIndexer.imagePhase`: explicitly rethrows cancellation; catches `OutOfMemoryError` separately during decode, batch inference, single-item retry, and outer image processing. OOM returns a paused result and leaves remaining database work pending for a later run.
- Batch inference OOM does not trigger size-one retries. The enclosing `finally` recycles all decoded batch bitmaps before control returns. For ordinary batch exceptions, batch bitmaps are recycled and cleared before any individual retry bitmap is allocated.
- Individual retry bitmaps are recycled in `finally`; OOM during a single retry stops the pass, preserving that and subsequent files as pending. Previously committed embeddings are not rolled back.
- `ImageBatchPlanner.infer` propagates `CancellationException` and `OutOfMemoryError`; only ordinary `Exception` failures invoke the single-item fallback.

### Regression tests added
- `cancellationPropagatesWithoutIndividualRetry`
- `outOfMemoryPropagatesWithoutIndividualRetry`
- `ordinaryBatchFailureRetriesEveryItem`
- Existing mapping, incomplete final batch, and invalid batch-size tests retained.

### Execution results
- **Executed:** a standalone Kotlin/JVM harness compiled `ImageBatchPlanner.kt` with the installed Kotlin compiler and coroutines runtime; mapping, incomplete batching, cancellation propagation (including no single-item retry), OOM propagation (including no single-item retry), and ordinary-exception fallback all passed.
- **Not executed:** the JUnit/Gradle test suite, Android build, instrumented tests, and physical-device tests. The environment has no Gradle executable, Gradle wrapper, or Android SDK.
- **Not measured:** RMX5000 memory behaviour, bitmap allocation pressure, and device inference performance.
- Source-level inspection confirms the new cancellation and OOM branches are present. This is not a substitute for compilation or runtime validation.

No Phase 3 work was started. Models, dimensions, normalization, ranking, provider architecture, UI, and Phase 1 power-gating logic were not intentionally changed.


## 9. Phase 2 real-device checkpoint (2026-11-04)

Evidence supplied by the user from GitHub Actions and a realme RMX5000: CI completed successfully with
`assembleDebug` and `testDebugUnitTest`; APK and unit-test report artifacts were produced. The APK was
installed and launched. Home, Settings, and Index screens opened. First observed indexing run reported
347 indexed and 0 failed. A subsequent run reported 349 scanned, 349 unchanged, 0 failed; a later search
screen displayed 350 indexed. Counts are transcribed from separate screenshots and should not be treated
as one atomic measurement.

A keyword query `lock screen photo` returned 350 results in 35 ms and included an unrelated Settings
screenshot. This demonstrates a search result list was produced, but it is a relevance failure for the
intended visual query. The search screen displayed `Semantic: off`. The Settings semantic toggle appeared
enabled, but no model pack had been imported. MiniLM/CLIP loading, inference, and semantic retrieval are
therefore **not verified**.

Live indexing status showed zero counters while a run was active, although the completed summary later
reported 349 scanned / 349 unchanged. This is a progress-reporting/data-refresh issue to investigate.
No device benchmark, thermal, battery, or memory measurements have been recorded.

This checkpoint is based on user-provided screenshots; the CI workflow summary is not a substitute for
reviewing the detailed unit-test report. No claims are made here about instrumented tests or semantic
accuracy. Phase 3 remains blocked until compatible model packs are imported and real on-device semantic
retrieval is validated.
