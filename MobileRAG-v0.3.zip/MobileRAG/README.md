# MobileRAG (File RAG) v0.3

On-device file search for Android. Describe a file or photo, see matches with the full path, open them inside the app.

0.3: app folders (WhatsApp, WhatsApp Business, Telegram, Instagram, Camera, Screenshots, Downloads, Documents)
- Settings -> Quick add app folders: one tap adds an app's media folders to the index
- Search screen -> App filter: show results only from one app

0.2: custom folders, filters (type, date, size, folder), sorting, browse by filter, index switches, clear index.

Same debug key as 0.2, so this installs over 0.2 without uninstalling.
