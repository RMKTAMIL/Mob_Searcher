package com.mrk.filerag

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.io.File

data class Hit(
    val path: String,
    val name: String,
    val snippet: String,
    val score: Int,
    val mtime: Long,
    val size: Long
)

class Db(ctx: Context) : SQLiteOpenHelper(ctx, "rag.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE files(id INTEGER PRIMARY KEY AUTOINCREMENT, path TEXT UNIQUE, mtime INTEGER, size INTEGER)")
        db.execSQL("CREATE VIRTUAL TABLE fts USING fts4(name, content, tokenize=porter)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun count(): Int =
        readableDatabase.rawQuery("SELECT COUNT(*) FROM files", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }

    fun isUpToDate(path: String, mtime: Long, size: Long): Boolean =
        readableDatabase.rawQuery(
            "SELECT 1 FROM files WHERE path=? AND mtime=? AND size=?",
            arrayOf(path, mtime.toString(), size.toString())
        ).use { it.moveToFirst() }

    fun upsert(path: String, name: String, content: String, mtime: Long, size: Long) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            var id = -1L
            db.rawQuery("SELECT id FROM files WHERE path=?", arrayOf(path)).use { if (it.moveToFirst()) id = it.getLong(0) }
            if (id >= 0) {
                db.execSQL("DELETE FROM fts WHERE docid=?", arrayOf<Any>(id))
                db.execSQL("UPDATE files SET mtime=?, size=? WHERE id=?", arrayOf<Any>(mtime, size, id))
            } else {
                val cv = ContentValues().apply { put("path", path); put("mtime", mtime); put("size", size) }
                id = db.insert("files", null, cv)
            }
            db.execSQL("INSERT INTO fts(docid, name, content) VALUES(?,?,?)", arrayOf<Any>(id, name, content))
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    private fun deleteIds(ids: List<Long>) {
        if (ids.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            for (id in ids) {
                db.execSQL("DELETE FROM fts WHERE docid=?", arrayOf<Any>(id))
                db.execSQL("DELETE FROM files WHERE id=?", arrayOf<Any>(id))
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun removeMissing() {
        val gone = ArrayList<Long>()
        readableDatabase.rawQuery("SELECT id, path FROM files", null).use { c ->
            while (c.moveToNext()) if (!File(c.getString(1)).exists()) gone.add(c.getLong(0))
        }
        deleteIds(gone)
    }

    fun pruneOutside(roots: List<String>) {
        if (roots.isEmpty()) return
        val gone = ArrayList<Long>()
        readableDatabase.rawQuery("SELECT id, path FROM files", null).use { c ->
            while (c.moveToNext()) {
                val p = c.getString(1)
                if (roots.none { p == it || p.startsWith(it.trimEnd('/') + "/") }) gone.add(c.getLong(0))
            }
        }
        deleteIds(gone)
    }

    fun clear() {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.execSQL("DELETE FROM fts")
            db.execSQL("DELETE FROM files")
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    private fun filterSql(f: Filters, args: MutableList<String>): String {
        val sb = StringBuilder()
        if (f.kind.exts.isNotEmpty()) {
            sb.append(" AND (")
            sb.append(f.kind.exts.joinToString(" OR ") { "files.path LIKE '%.$it'" })
            sb.append(")")
        }
        if (f.date.days > 0) {
            sb.append(" AND files.mtime >= ").append(System.currentTimeMillis() - f.date.days * 86_400_000L)
        }
        if (f.size.min > 0L) sb.append(" AND files.size >= ").append(f.size.min)
        if (f.size.max != Long.MAX_VALUE) sb.append(" AND files.size < ").append(f.size.max)
        val folder = f.folder
        if (folder != null) {
            val prefix = folder.trimEnd('/') + "/"
            sb.append(" AND substr(files.path, 1, ").append(prefix.length).append(") = ?")
            args.add(prefix)
        }
        val src = f.source
        if (src != null && src.paths.isNotEmpty()) {
            val parts = src.paths.map { p ->
                val prefix = p.trimEnd('/') + "/"
                args.add(prefix)
                "substr(files.path, 1, " + prefix.length + ") = ?"
            }
            sb.append(" AND (").append(parts.joinToString(" OR ")).append(")")
        }
        return sb.toString()
    }

    fun search(q: String, f: Filters, limit: Int = 200): List<Hit> {
        val tokens = q.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length > 1 }.distinct()
        val out = ArrayList<Hit>()
        try {
            if (tokens.isEmpty()) {
                if (!f.isActive) return emptyList()
                val args = ArrayList<String>()
                val order = when (f.sort) {
                    SortBy.OLDEST -> "files.mtime ASC"
                    SortBy.LARGEST -> "files.size DESC"
                    SortBy.NAME -> "files.path COLLATE NOCASE ASC"
                    else -> "files.mtime DESC"
                }
                val sql = "SELECT files.path, files.mtime, files.size FROM files WHERE 1=1" +
                    filterSql(f, args) + " ORDER BY " + order + " LIMIT " + limit
                readableDatabase.rawQuery(sql, args.toTypedArray()).use { c ->
                    while (c.moveToNext()) {
                        val p = c.getString(0)
                        out.add(Hit(p, File(p).name, "", 0, c.getLong(1), c.getLong(2)))
                    }
                }
                return if (f.sort == SortBy.NAME) out.sortedBy { it.name.lowercase() } else out
            }

            val match = tokens.joinToString(" OR ") { "$it*" }
            val args = ArrayList<String>()
            args.add(match)
            val sql = "SELECT files.path, fts.name, substr(fts.content,1,20000), files.mtime, files.size " +
                "FROM fts JOIN files ON files.id = fts.docid WHERE fts MATCH ?" +
                filterSql(f, args) + " LIMIT 600"
            readableDatabase.rawQuery(sql, args.toTypedArray()).use { c ->
                while (c.moveToNext()) {
                    val path = c.getString(0)
                    val name = (c.getString(1) ?: "").lowercase()
                    val content = c.getString(2) ?: ""
                    val lc = content.lowercase()
                    var score = 0
                    var first = -1
                    for (t in tokens) {
                        val s = if (t.length > 3) t.removeSuffix("s") else t
                        if (name.contains(s)) score += 3
                        val i = lc.indexOf(s)
                        if (i >= 0) {
                            score += 1
                            if (first < 0 || i < first) first = i
                        }
                    }
                    val snip = if (first >= 0)
                        content.substring(maxOf(0, first - 50), minOf(content.length, first + 120)).replace(Regex("\\s+"), " ")
                    else ""
                    out.add(Hit(path, File(path).name, snip, score, c.getLong(3), c.getLong(4)))
                }
            }
        } catch (e: Exception) {
        }
        val sorted = when (f.sort) {
            SortBy.NEWEST -> out.sortedByDescending { it.mtime }
            SortBy.OLDEST -> out.sortedBy { it.mtime }
            SortBy.LARGEST -> out.sortedByDescending { it.size }
            SortBy.NAME -> out.sortedBy { it.name.lowercase() }
            SortBy.RELEVANCE -> out.sortedWith(compareByDescending<Hit> { it.score }.thenByDescending { it.mtime })
        }
        return sorted.take(limit)
    }
}
