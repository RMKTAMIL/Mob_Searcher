package com.mrk.filerag

enum class Kind(val label: String, val exts: List<String>) {
    ALL("All types", emptyList()),
    PHOTOS("Photos", listOf("jpg", "jpeg", "png", "webp")),
    PDF("PDF", listOf("pdf")),
    WORD("Word", listOf("docx")),
    TEXT("Text/code", TEXT_EXT.toList())
}

enum class DateRange(val label: String, val days: Int) {
    ANY("Any date", 0),
    DAY("Last 24 hours", 1),
    WEEK("Last 7 days", 7),
    MONTH("Last 30 days", 30),
    YEAR("Last year", 365)
}

enum class SizeRange(val label: String, val min: Long, val max: Long) {
    ANY("Any size", 0L, Long.MAX_VALUE),
    SMALL("Under 1 MB", 0L, 1_048_576L),
    MEDIUM("1 to 10 MB", 1_048_576L, 10_485_760L),
    LARGE("Over 10 MB", 10_485_760L, Long.MAX_VALUE)
}

enum class SortBy(val label: String) {
    RELEVANCE("Best match"),
    NEWEST("Newest"),
    OLDEST("Oldest"),
    LARGEST("Largest"),
    NAME("Name")
}

data class Filters(
    val kind: Kind = Kind.ALL,
    val date: DateRange = DateRange.ANY,
    val size: SizeRange = SizeRange.ANY,
    val sort: SortBy = SortBy.RELEVANCE,
    val folder: String? = null,
    val source: AppSource? = null
) {
    val isActive: Boolean
        get() = kind != Kind.ALL || date != DateRange.ANY || size != SizeRange.ANY || folder != null || source != null
}
