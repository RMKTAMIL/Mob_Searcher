package com.mrk.filerag

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract
import android.provider.Settings
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var db: Db

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = Db(applicationContext)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App(db) }
            }
        }
    }
}

enum class Screen { HOME, SETTINGS }

fun hasAccess(ctx: Context): Boolean =
    if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
    else ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

fun openExternal(ctx: Context, f: File) {
    try {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".provider", f)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(i)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, "No app can open this file", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        Toast.makeText(ctx, "Cannot open: " + e.message, Toast.LENGTH_SHORT).show()
    }
}

fun treeUriToPath(uri: Uri): String? {
    return try {
        val id = DocumentsContract.getTreeDocumentId(uri)
        val parts = id.split(":", limit = 2)
        val vol = parts[0]
        val rel = if (parts.size > 1) parts[1] else ""
        val base = if (vol == "primary") Environment.getExternalStorageDirectory().path else "/storage/$vol"
        val f = if (rel.isEmpty()) File(base) else File(base, rel)
        if (f.isDirectory) f.path else null
    } catch (e: Exception) {
        null
    }
}

fun shortName(p: String): String = p.trimEnd('/').split('/').takeLast(2).joinToString("/")

fun fmtSize(b: Long): String = when {
    b >= 1_048_576L -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
    b >= 1024L -> (b / 1024L).toString() + " KB"
    else -> "$b B"
}

@Composable
fun App(db: Db) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val prefs = remember { Prefs(ctx.applicationContext) }

    var access by remember { mutableStateOf(hasAccess(ctx)) }
    DisposableEffect(lifecycle) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) access = hasAccess(ctx) }
        lifecycle.addObserver(obs)
        onDispose { lifecycle.removeObserver(obs) }
    }
    val legacyLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        access = hasAccess(ctx)
    }

    var query by remember { mutableStateOf("") }
    var filters by remember { mutableStateOf(Filters()) }
    var hits by remember { mutableStateOf(emptyList<Hit>()) }
    var viewing by remember { mutableStateOf<Hit?>(null) }
    var screen by remember { mutableStateOf(Screen.HOME) }
    var indexing by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf("") }
    var total by remember { mutableStateOf(db.count()) }
    var job by remember { mutableStateOf<Job?>(null) }
    var folders by remember { mutableStateOf(prefs.folders()) }
    var optPhotos by remember { mutableStateOf(prefs.photos) }
    var optDocs by remember { mutableStateOf(prefs.docs) }
    var optText by remember { mutableStateOf(prefs.text) }
    var showClear by remember { mutableStateOf(false) }
    val sources = remember(access) { Sources.detected() }

    val view = LocalView.current
    SideEffect { view.keepScreenOn = indexing }

    LaunchedEffect(query, total, filters) {
        delay(250)
        hits = withContext(Dispatchers.IO) { db.search(query, filters) }
    }

    BackHandler(enabled = viewing != null || screen == Screen.SETTINGS) {
        if (viewing != null) viewing = null else screen = Screen.HOME
    }

    fun startIndex() {
        val roots = folders.map { File(it) }.ifEmpty { listOf(Environment.getExternalStorageDirectory()) }
        val p = optPhotos
        val d = optDocs
        val t = optText
        indexing = true
        job = scope.launch(Dispatchers.Default) {
            try {
                Indexer(ctx.applicationContext, db, p, d, t).run(
                    roots,
                    { n, name -> progress = "$n new: $name" },
                    { isActive }
                )
            } finally {
                withContext(NonCancellable + Dispatchers.Main) {
                    indexing = false
                    progress = ""
                    total = db.count()
                }
            }
        }
    }

    fun toggleIndex() {
        if (indexing) job?.cancel() else startIndex()
    }

    if (!access) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
            Text("File RAG", fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.padding(8.dp))
            Text("Allow access to all files so the app can index your documents and photos. Everything stays on your phone.")
            Spacer(Modifier.padding(8.dp))
            Button(onClick = {
                if (Build.VERSION.SDK_INT >= 30) {
                    ctx.startActivity(
                        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + ctx.packageName))
                    )
                } else {
                    legacyLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                }
            }) { Text("Grant access") }
        }
        return
    }

    if (showClear) {
        AlertDialog(
            onDismissRequest = { showClear = false },
            title = { Text("Clear index?") },
            text = { Text("All indexed data is deleted and you will need to index again.") },
            confirmButton = {
                Button(onClick = {
                    db.clear()
                    total = db.count()
                    showClear = false
                }) { Text("Clear") }
            },
            dismissButton = { OutlinedButton(onClick = { showClear = false }) { Text("Cancel") } }
        )
    }

    val v = viewing
    if (v != null) {
        Viewer(v) { viewing = null }
        return
    }

    if (screen == Screen.SETTINGS) {
        SettingsScreen(
            folders = folders,
            sources = sources,
            onToggleSource = { s ->
                val has = s.paths.all { it in folders }
                folders = if (has) folders - s.paths.toSet() else (folders + s.paths).distinct()
                prefs.setFolders(folders)
                val cur = filters.folder
                if (has && cur != null && cur in s.paths) filters = filters.copy(folder = null)
            },
            onAddFolder = { p ->
                if (p !in folders) {
                    folders = folders + p
                    prefs.setFolders(folders)
                }
            },
            onRemoveFolder = { p ->
                folders = folders - p
                prefs.setFolders(folders)
                if (filters.folder == p) filters = filters.copy(folder = null)
            },
            photos = optPhotos,
            onPhotos = { optPhotos = it; prefs.photos = it },
            docs = optDocs,
            onDocs = { optDocs = it; prefs.docs = it },
            text = optText,
            onText = { optText = it; prefs.text = it },
            indexing = indexing,
            progress = progress,
            total = total,
            onToggleIndex = { toggleIndex() },
            onClear = { showClear = true },
            onBack = { screen = Screen.HOME }
        )
        return
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("File RAG", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            OutlinedButton(onClick = { screen = Screen.SETTINGS }) { Text("Settings") }
        }
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("Describe a file or photo") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
        )
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Picker("Type", filters.kind, Kind.values().toList(), { it.label }) { filters = filters.copy(kind = it) }
            Picker("Date", filters.date, DateRange.values().toList(), { it.label }) { filters = filters.copy(date = it) }
            Picker("Size", filters.size, SizeRange.values().toList(), { it.label }) { filters = filters.copy(size = it) }
            Picker("Sort", filters.sort, SortBy.values().toList(), { it.label }) { filters = filters.copy(sort = it) }
            if (folders.isNotEmpty()) {
                Picker("Folder", filters.folder, listOf<String?>(null) + folders, { p -> p?.let { shortName(it) } ?: "All" }) {
                    filters = filters.copy(folder = it)
                }
            }
            if (sources.isNotEmpty()) {
                Picker("App", filters.source, listOf<AppSource?>(null) + sources, { s -> s?.label ?: "All apps" }) {
                    filters = filters.copy(source = it)
                }
            }
            if (filters.isActive) {
                TextButton(onClick = { filters = Filters() }) { Text("Reset") }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { toggleIndex() }) { Text(if (indexing) "Stop" else "Index files") }
            Spacer(Modifier.width(12.dp))
            Text("$total files indexed", fontSize = 13.sp)
        }
        if (progress.isNotEmpty()) {
            Text(progress, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (hits.isEmpty()) {
            Text(
                if (total == 0) "Tap Index files first (or choose folders in Settings). Keep the app open until it finishes."
                else if (query.isBlank() && !filters.isActive) "Type what you are looking for, or pick a filter to browse."
                else "No matches.",
                modifier = Modifier.padding(top = 16.dp)
            )
        } else {
            Text("${hits.size} results", fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        }
        LazyColumn(Modifier.fillMaxSize()) {
            items(hits) { h -> ResultRow(h) { viewing = h } }
        }
    }
}

@Composable
fun <T> Picker(label: String, current: T, options: List<T>, name: (T) -> String, onPick: (T) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(
            onClick = { open = true },
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
        ) {
            Text(label + ": " + name(current), fontSize = 12.sp, maxLines = 1)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { o ->
                DropdownMenuItem(text = { Text(name(o)) }, onClick = {
                    open = false
                    onPick(o)
                })
            }
        }
    }
}

@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Switch(checked = checked, onCheckedChange = onChange)
        Spacer(Modifier.width(12.dp))
        Text(label, fontSize = 14.sp, modifier = Modifier.weight(1f))
    }
}

@Composable
fun SettingsScreen(
    folders: List<String>,
    sources: List<AppSource>,
    onToggleSource: (AppSource) -> Unit,
    onAddFolder: (String) -> Unit,
    onRemoveFolder: (String) -> Unit,
    photos: Boolean,
    onPhotos: (Boolean) -> Unit,
    docs: Boolean,
    onDocs: (Boolean) -> Unit,
    text: Boolean,
    onText: (Boolean) -> Unit,
    indexing: Boolean,
    progress: String,
    total: Int,
    onToggleIndex: () -> Unit,
    onClear: () -> Unit,
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            val p = treeUriToPath(uri)
            if (p != null) onAddFolder(p)
            else Toast.makeText(ctx, "Pick a folder in phone or SD card storage", Toast.LENGTH_LONG).show()
        }
    }
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = onBack) { Text("Back") }
            Spacer(Modifier.width(12.dp))
            Text("Settings", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(16.dp))

        Text("Quick add app folders", fontWeight = FontWeight.Bold)
        if (sources.isEmpty()) {
            Text("No app folders found on this phone.", fontSize = 13.sp)
        }
        sources.forEach { s ->
            val added = s.paths.all { it in folders }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(s.label, modifier = Modifier.weight(1f))
                if (added) {
                    OutlinedButton(onClick = { onToggleSource(s) }) { Text("Remove") }
                } else {
                    Button(onClick = { onToggleSource(s) }) { Text("Add") }
                }
            }
        }
        Spacer(Modifier.height(20.dp))

        Text("Folders to index", fontWeight = FontWeight.Bold)
        if (folders.isEmpty()) {
            Text(
                "None chosen: the whole phone storage is indexed, except the Android folder. Add WhatsApp or Telegram above to include their media.",
                fontSize = 13.sp
            )
        }
        folders.forEach { p ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(p, fontSize = 12.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { onRemoveFolder(p) }) { Text("Remove") }
            }
        }
        OutlinedButton(onClick = { picker.launch(null) }) { Text("Add folder") }
        Text(
            "After a full index run, files outside the chosen folders are removed from the index.",
            fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(Modifier.height(20.dp))
        Text("What to read inside files", fontWeight = FontWeight.Bold)
        SwitchRow("Photos: objects and text in images (slow)", photos, onPhotos)
        SwitchRow("PDF and Word text", docs, onDocs)
        SwitchRow("Text and code files", text, onText)
        Text(
            "File and folder names are always indexed. A changed switch applies to new or changed files; use Clear index to redo everything.",
            fontSize = 12.sp
        )

        Spacer(Modifier.height(20.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = onToggleIndex) { Text(if (indexing) "Stop" else "Index now") }
            Spacer(Modifier.width(12.dp))
            Text("$total files indexed", fontSize = 13.sp)
        }
        if (progress.isNotEmpty()) {
            Text(progress, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onClear, enabled = !indexing) { Text("Clear index") }
    }
}

@Composable
fun ResultRow(h: Hit, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 10.dp)) {
        Text(h.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(
            File(h.path).extension.uppercase() + "  |  " + fmtSize(h.size) + "  |  " +
                DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(h.mtime)),
            fontSize = 11.sp
        )
        if (h.snippet.isNotBlank()) Text(h.snippet, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Text(
            h.path, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
            color = MaterialTheme.colorScheme.primary
        )
    }
}

@Composable
fun Viewer(hit: Hit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val file = File(hit.path)
    val ext = file.extension.lowercase()
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = onBack) { Text("Back") }
            Spacer(Modifier.width(8.dp))
            OutlinedButton(onClick = { openExternal(ctx, file) }) { Text("Open with...") }
        }
        SelectionContainer {
            Text("Path: " + hit.path, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                ext in IMG_EXT -> ImageView(file)
                ext == "pdf" -> PdfView(file)
                ext in TEXT_EXT -> TextView(file)
                else -> Text("No built-in viewer for this file type. Tap Open with...")
            }
        }
    }
}

@Composable
fun ImageView(file: File) {
    val bmp by produceState<Bitmap?>(null, file) {
        value = withContext(Dispatchers.IO) { decodeScaled(file.path, 2048) }
    }
    val b = bmp
    if (b != null) {
        Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
    } else {
        CircularProgressIndicator()
    }
}

@Composable
fun TextView(file: File) {
    val text by produceState("Loading...", file) {
        value = withContext(Dispatchers.IO) { readHead(file, 200_000) }
    }
    SelectionContainer {
        Text(text, fontSize = 13.sp, modifier = Modifier.verticalScroll(rememberScrollState()))
    }
}

@Composable
fun PdfView(file: File) {
    val holder = remember(file) {
        try {
            val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            Pair(PdfRenderer(pfd), pfd)
        } catch (e: Exception) {
            null
        }
    }
    DisposableEffect(holder) {
        onDispose {
            try { holder?.first?.close() } catch (e: Exception) {}
            try { holder?.second?.close() } catch (e: Exception) {}
        }
    }
    val mutex = remember { Mutex() }
    if (holder == null) {
        Text("Cannot open this PDF here. Tap Open with...")
        return
    }
    val renderer = holder.first
    LazyColumn(Modifier.fillMaxSize()) {
        items(renderer.pageCount) { i ->
            val bmp by produceState<Bitmap?>(null, i) {
                value = withContext(Dispatchers.IO) {
                    mutex.withLock {
                        try { renderPage(renderer, i, 1000) } catch (e: Exception) { null }
                    }
                }
            }
            val b = bmp
            if (b != null) {
                Image(
                    b.asImageBitmap(), null,
                    Modifier.fillMaxWidth().padding(bottom = 6.dp),
                    contentScale = ContentScale.FillWidth
                )
            } else {
                Box(Modifier.fillMaxWidth().heightIn(min = 240.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
        }
    }
}
