package com.mrk.filerag

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("rag_prefs", Context.MODE_PRIVATE)

    fun folders(): List<String> =
        (sp.getString("folders", "") ?: "").split("\n").filter { it.isNotBlank() }

    fun setFolders(l: List<String>) {
        sp.edit().putString("folders", l.joinToString("\n")).apply()
    }

    var photos: Boolean
        get() = sp.getBoolean("photos", true)
        set(v) { sp.edit().putBoolean("photos", v).apply() }

    var docs: Boolean
        get() = sp.getBoolean("docs", true)
        set(v) { sp.edit().putBoolean("docs", v).apply() }

    var text: Boolean
        get() = sp.getBoolean("text", true)
        set(v) { sp.edit().putBoolean("text", v).apply() }
}
