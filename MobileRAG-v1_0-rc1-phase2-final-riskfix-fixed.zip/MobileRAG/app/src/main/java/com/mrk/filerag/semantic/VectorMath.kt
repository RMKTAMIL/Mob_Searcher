package com.mrk.filerag.semantic

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sqrt

object VectorMath {
    fun l2Normalize(v: FloatArray): FloatArray {
        var s = 0.0
        for (x in v) s += x.toDouble() * x
        val n = sqrt(s)
        if (n < 1e-12) return v
        return FloatArray(v.size) { (v[it] / n).toFloat() }
    }

    /** Symmetric int8 quantization: value = byte * scale. Storage is 1 byte per dimension instead of 4. */
    fun quantize(v: FloatArray): Pair<ByteArray, Float> {
        var m = 0f
        for (x in v) m = max(m, abs(x))
        val scale = if (m == 0f) 1f else m / 127f
        val q = ByteArray(v.size) { (v[it] / scale).roundToInt().coerceIn(-127, 127).toByte() }
        return Pair(q, scale)
    }

    fun dot(q: FloatArray, vec: ByteArray, scale: Float): Float {
        val n = minOf(q.size, vec.size)
        var s = 0f
        for (i in 0 until n) s += q[i] * vec[i]
        return s * scale
    }

    fun cosine(a: FloatArray, b: FloatArray): Float {
        var d = 0.0
        var na = 0.0
        var nb = 0.0
        for (i in a.indices) {
            d += a[i].toDouble() * b[i]
            na += a[i].toDouble() * a[i]
            nb += b[i].toDouble() * b[i]
        }
        val den = sqrt(na) * sqrt(nb)
        return if (den < 1e-12) 0f else (d / den).toFloat()
    }

    /** Mean of token vectors where mask == 1. hidden is [tokens][dim]. */
    fun meanPool(hidden: Array<FloatArray>, mask: LongArray): FloatArray {
        val dim = if (hidden.isEmpty()) 0 else hidden[0].size
        val out = FloatArray(dim)
        var count = 0
        for (t in hidden.indices) {
            if (t < mask.size && mask[t] == 0L) continue
            for (d in 0 until dim) out[d] += hidden[t][d]
            count++
        }
        if (count > 0) for (d in 0 until dim) out[d] /= count
        return out
    }
}
