# Changelog

## Unreleased: Phase 2, inference optimization (not yet built with Gradle or run on a device)
- Added real CLIP image tensor batching (1/2/4), reusable preprocessing buffers, ordered file/vector mapping, incomplete-batch support, individual retries after batch failures and reliable bitmap cleanup.
- Added configurable CPU/XNNPACK/NNAPI session selection using the pinned ONNX Runtime 1.19.2 API surface via reflection, with CPU fallback and activated-provider logging.
- Added bounded app-private LRU thumbnail cache with source fingerprint keys and downsampled previews; exposed cache capacity in Settings.
- Added Settings for image batch size, provider, thread count and cache capacity. Session-bound settings require model unload/reload.
- Extended the on-device benchmark with measured synthetic-image batch inference on the selected provider. Cross-provider, real-gallery, indexing-throughput and search-latency measurements remain unavailable.
- Added image batch planner JVM tests. No Phase 3 work.
- Validation limitation: no Gradle/Android SDK or RMX5000 device was available; no Android build or physical-device benchmark is claimed.

## Unreleased: Phase 1, core reliability (not yet built with Gradle or run on a device)
- New: `PowerGate` for semantic indexing. Honors the existing "only while charging" setting (previously stored but never
  enforced), a minimum battery percentage (default 20%, not enforced while charging), and Android thermal status
  (API 29+). Defaults: moderate throttles, severe/critical pause. Missing thermal data is `UNKNOWN` (throttled), never
  treated as a safe reading. All values are configurable in `Prefs`; no Settings UI for the new ones yet.
- New: checks run before each batch (and before the first model load). A running batch finishes; finished files are already
  committed, so a pause loses nothing.
- New: automatic resume through a unique WorkManager job (`index_resume`, semantic-only) with charging/battery-not-low
  constraints and a bounded back-off (stops after 6 consecutive pauses without progress). Survives process death/reboot via
  WorkManager. "Stop" now also cancels a pending resume.
- Changed: with the default settings, a manual run on battery now finishes the keyword phase and then waits for the charger
  before semantic indexing; turn the Settings switch off to allow it on battery.
- Tests added: `PowerPolicyTest`, `PowerGateTest`, `ResumePlannerTest` (JVM); `EmbeddingCheckpointTest`,
  `IndexSchedulingTest` (instrumented, not run).
- Fixed: `FingerprintTest` used a temp-file prefix that is too short for `File.createTempFile`.
- Not changed: models, embedding dimensions/preprocessing, search, UI, image batching size, no new permissions, no network.

## 1.0.0-rc1 (release candidate; never compiled or run by the author)
- New: WorkManager indexing (foreground notification, resumable, optional 12-hourly re-scan while charging).
- New: bounded-concurrency pipeline, batched commits, retry of failed files, failed-files list, re-index/clear with confirmation.
- New: extraction for PPTX, XLSX, HTML, Markdown and many code formats; improved DOCX/PDF; binary detection; size limits.
- New: image metadata (dimensions, EXIF date/camera, rotation), separate label/OCR columns, duplicate reuse.
- New: BM25 ranking, phrase and prefix search, paging, search history, suggestions, timing display.
- New: optional on-device semantic search (ONNX Runtime): sentence embeddings + CLIP image-text, model import with SHA-256
  verification, model versioning, embedding migration, load/unload with memory guard, keyword fallback, benchmark screen.
- Changed: database schema v2 (non-destructive migration + backup), WAL, singleton, all DB work off the main thread.
- Changed: INTERNET permission removed from the merged manifest and checked in CI; FileProvider narrowed.
- Fixed: PdfRenderer close race in the viewer.
- Tests added (not yet executed): see DEVELOPMENT_PROGRESS.md.

## 0.3 / 0.2 / 0.1
Folder selection, filters, app-folder presets, first on-device keyword/label/OCR search.


## Phase 2 final risk fixes (2026-11-04)

- `SemanticIndexer` now rethrows `CancellationException` before ordinary text/image error handling; cancellation is not recorded as an embedding failure. Completed database commits remain intact and unprocessed files remain eligible for the next run.
- `ImageBatchPlanner` now propagates coroutine cancellation and `OutOfMemoryError`; only ordinary exceptions trigger per-item fallback.
- Image inference OOM now stops the current indexing pass and leaves affected/unprocessed files pending. It does not mark them failed or launch individual inference retries under memory pressure.
- On ordinary batch inference failure, all batch bitmaps are recycled before individual bitmaps are decoded and retried. Temporary individual bitmaps are recycled in `finally`.
- Added regression tests for cancellation propagation, OOM propagation without individual retry, and ordinary-error fallback.
