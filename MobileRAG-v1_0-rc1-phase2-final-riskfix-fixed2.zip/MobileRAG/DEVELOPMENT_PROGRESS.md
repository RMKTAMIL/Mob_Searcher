# Development progress

Legend: Written = source exists. Compiled = Gradle build passed. Tests run = executed with a pass/fail result.
**Nothing below is compiled or run by Gradle yet** (authoring environments had no Android SDK/Gradle access). Phase 1 is the
only stage with any executed checks, and those are limited: see the Phase 1 section and VALIDATION_REPORT.md. Update the last
two columns from your first CI run.

| Stage | Scope | Written | Compiled | Tests run |
|---|---|---|---|---|
| 1 Audit | docs/AUDIT.md | yes | n/a | n/a |
| 2 Critical fixes/security | INTERNET stripped, FileProvider narrowed, PdfView race, errors recorded | yes | no | no |
| 3 DB + indexing | schema v2 + migration, WAL, pipeline, WorkManager | yes | no | no |
| 4 Extraction/OCR | Office/HTML/code/PDF/image extractors, EXIF | yes | no | no |
| 5 Search | BM25, phrases, paging, history, RRF | yes | no | no |
| 6 Background/recovery | worker, scheduler, resumable runs, interrupted-run notice | yes | no | no |
| 7 UI | Home, Index dashboard, Settings, Viewer | yes | no | no |
| 8 Tests | 14 JVM classes + 4 instrumented classes | yes | no | no |
| 9 Build | Gradle, workflow with INTERNET check, optional signed release | yes | no | no |
| 10 Docs | README, ARCHITECTURE, MODELS, AUDIT, CHANGELOG, AIRPLANE_MODE_TEST | yes | n/a | n/a |
| AI | on-device embeddings, model store/versioning/unloading, fallback, benchmark | yes | no | no |
| P1 Core reliability | PowerGate, WorkManager pause/resume, checkpoint verification | yes | no (pure-logic files only, via kotlinc) | partial (45 JVM tests, shim runner) |

## Acceptance criteria (v1.0 only when all true)
- [ ] Builds in CI, unit tests pass, instrumented tests pass on an emulator
- [ ] Models import and load on a real phone; dim checks pass
- [ ] Benchmarks recorded (latency, RAM, storage, battery) on at least one real device
- [ ] Airplane-mode test performed and recorded (docs/AIRPLANE_MODE_TEST.md)
- [ ] Search quality spot-checked; `min_score` calibrated per model
- [ ] Upgrade from a real v0.3 database verified

## Not implemented / open
- Approximate nearest-neighbour index (exact scan only), semantic retrieval for non-relevance sorts.
- Storage Access Framework mode (needs a rewrite; see ARCHITECTURE.md).
- Real-model golden tests for the tokenizers (only synthetic-vocabulary tests exist).
- Measured benchmark numbers (harness exists, no data).

---

## Phase 1: Core reliability (power-aware, thermally safe, resumable semantic indexing)

Status: implemented, **not built with Gradle, not run on a device**. Scope was Phase 1 only.

### What the inspection found (before any change)
- `Prefs.semanticOnlyCharging` ("Background semantic indexing only while charging") was stored and shown in Settings but
  **never enforced anywhere**. No battery or thermal check existed.
- Checkpointing already exists and is correct in principle, so no second system was added: pending work is *derived from
  the database* (`EmbeddingRepository.pendingText/pendingImages`: files with no finished `embed_state` row for the active
  `model_key`); each file's vectors and state are saved in one transaction (`save`); `Indexer` commits per batch
  (`writeBatch`, `NonCancellable`); a changed file loses its embeddings and state in `writeBatch` and is re-embedded;
  identical fingerprints reuse vectors (`reuse`); a failed file gets `attempts+1` and is excluded after 3.
- `Extractors.extract` never throws (failures become `Failed` rows), and the semantic loops catch per-file model errors,
  so one bad file does not abort a run.
- `VALIDATION_REPORT.md` did not exist in the zip; it was created.

### Files added
- `power/PowerPolicy.kt` pure decision logic (no Android imports): `ThermalLevel`, `ThermalAction`, `PowerConfig`, `PowerSnapshot`, `PowerDecision`, `PowerPolicy.evaluate`.
- `power/PowerGate.kt` `PowerGate` (`check()`, `beforeBatch()` with cancellable throttle wait + re-check) and the `PowerSource` interface. No Android imports.
- `power/AndroidPowerSource.kt` reads the sticky battery broadcast and, on API 29+, `PowerManager.currentThermalStatus`.
- `index/ResumePlanner.kt` pure: constraints, delay and give-up rule for a resume job.
- Tests: `test/.../power/PowerPolicyTest.kt`, `test/.../power/PowerGateTest.kt`, `test/.../index/ResumePlannerTest.kt` (JVM);
  `androidTest/.../EmbeddingCheckpointTest.kt`, `androidTest/.../IndexSchedulingTest.kt` (device/emulator).

### Files modified
- `semantic/SemanticIndexer.kt`: optional `gate` constructor parameter (default null = old behaviour); `gatePaused()` is called after a batch is fetched and before it is processed, in both the text and the image phase; new `powerPause` and `madeProgress` properties; a power pause skips the image phase and is reported in the summary. `BATCH`, the image decode/embed steps and the models are untouched.
- `index/IndexWorker.kt`: passes `c.power` to `SemanticIndexer`; on a power pause it clears `runInProgress`, asks `ResumePlanner` for a plan and calls `IndexScheduler.scheduleResume`, then returns `Result.success()`. Cancellation and the bounded failure retry (`runAttemptCount < 3`) are unchanged.
- `index/IndexScheduler.kt`: `RESUME` unique work name, `scheduleResume(...)`, and `stop()` now cancels `RESUME` as well as `NOW`.
- `settings/Prefs.kt`: `semanticMinBattery` (default 20), per-level thermal actions, `powerConfig()`.
- `AppContainer.kt`: `val power = PowerGate(AndroidPowerSource(app), config = { prefs.powerConfig() })`.
- `app/build.gradle.kts`: `androidTestImplementation("androidx.work:work-testing:2.9.1")` (instrumented scheduling test only).
- `test/.../index/FingerprintTest.kt`: temp-file prefix `"fp"` -> `"fpt"`. The existing test failed on any JVM (`createTempFile` needs a prefix of 3+ characters); a test-only fix.
- `DEVELOPMENT_PROGRESS.md`, `CHANGELOG.md`, `VALIDATION_REPORT.md` (new).

### Architecture decisions
1. **Gate at batch boundaries only.** A batch that has started always finishes; the gate is asked before the next one. Every finished file is already committed, so a pause loses nothing.
2. **Semantic phase only.** The file-extraction phase (`Indexer`) is not gated, so keyword search indexing behaves as before. The gate also runs before the first model load, so a hot or unplugged phone never loads a model it is about to unload.
3. **Rules** (`PowerPolicy.evaluate`, in this order): charging required and not charging (or unreadable) -> pause; not charging and battery below the floor (or unreadable, floor > 0) -> pause; thermal action for the level. The battery floor is not enforced while charging.
4. **Thermal defaults:** normal continue, moderate throttle (3 s before each batch), severe and critical pause. Android LIGHT maps to normal; EMERGENCY and SHUTDOWN map to critical. **Missing information is its own level, `UNKNOWN`, never `NORMAL`**, and it defaults to throttle. Status is polled at each batch boundary instead of registering a listener (one cheap call per batch; no listener lifecycle).
5. **Automatic resume** = a separate unique WorkManager job (`index_resume`, `MODE_EMBED`) persisted by WorkManager (so it survives process death and reboot). Its constraints: battery-not-low always, charging when the preference requires it or the reason is "not charging" (a constraint wait, no polling). Thermal and battery-floor pauses wait 15, 30, then 60 min. From inside the running resume job the next one is chained (`APPEND_OR_REPLACE`) because `REPLACE` would cancel the job doing the scheduling; from anywhere else it uses `REPLACE`.
6. **No endless loops:** the resume job carries a counter of consecutive pauses without progress; after 6 it stops rescheduling, the UI says "Tap Semantic only to continue", and the periodic charging scan or a manual run picks the work up from the database. Real errors still use the existing 3-attempt retry.
7. **Duplicate jobs:** `NOW` (KEEP) and `RESUME` have separate unique names; the existing `IndexState.lock` mutex still guarantees a single running pass.
8. **Reboot/process death:** nothing new was added for persistence. The DB-derived pending set is the checkpoint; WorkManager restores queued and interrupted work.

### Behaviour change to be aware of
Because `semanticOnlyCharging` defaults to **true** and is now enforced, a manual "Index now" / "Semantic only" on battery
completes the keyword phase, then reports "Paused: waiting for the charger..." and queues a resume for when the phone is
plugged in. Turning the Settings switch off lets semantic indexing run on battery (above the battery floor).

### Test results (actual)
- Run here: 45 JVM tests, **45 passed, 0 failed** (PowerPolicyTest 19, PowerGateTest 7, ResumePlannerTest 8, plus the existing ChangeDetectionTest 8 and FingerprintTest 3). They were compiled with Kotlin 1.9.24 `kotlinc` and run with a **local JUnit-API shim and reflection runner, not Gradle/JUnit** (no JUnit jar was reachable). Details in VALIDATION_REPORT.md.
- **Not run:** `EmbeddingCheckpointTest` (7 tests) and `IndexSchedulingTest` (4 tests) need a device/emulator. All other existing JVM tests and all existing instrumented tests were not run.

### Build status
**No Gradle build was possible.** The sandbox has no Android SDK or Gradle, and `dl.google.com`, `services.gradle.org`, `maven.google.com`, `repo.maven.apache.org` and `plugins.gradle.org` were unreachable. Only the pure files (`PowerPolicy`, `PowerGate`, `ResumePlanner`, plus `ChangeDetection`, `Fingerprint`, `Status`) were compiled. `AndroidPowerSource`, `SemanticIndexer`, `IndexWorker`, `IndexScheduler`, `Prefs`, `AppContainer` and the two instrumented tests were checked by reading only. One compile error of mine (a trailing lambda binding to the wrong `PowerGate` parameter) was found that way, which is a reason to expect more on the first real build.

### Unresolved issues / limitations
- First real `gradle assembleDebug testDebugUnitTest` still has to be run (CI workflow exists).
- No device test on the realme RMX5000. OEM thermal behaviour is unmeasured: on API 29+ the OS reports `NONE` both when the phone is cool and when the HAL gives no data, and that cannot be told apart from the app. `UNKNOWN` only covers API < 29, an exception, or an out-of-range value.
- Not covered by an executable test: the pause check inside the `SemanticIndexer` loops, and worker-level cancellation and reboot resume. They need real models or a WorkManager instrumented harness (`SemanticIndexer` depends on concrete `ModelManager`/ONNX classes). They are covered only by the gate/planner unit tests, the DB-level instrumented tests and code reading.
- The gate check was added inside `imagePhase`. Batch size and image processing are unchanged, but this touches the image loop.
- No Settings UI for the battery floor or thermal actions; they are SharedPreferences values with the defaults above.
- The resume job's charging constraint is fixed when it is queued; toggling the charging switch later does not change an already queued job (the gate still re-reads the preference when it runs).
- A pending resume that fires after a manual run has finished is a cheap no-op (nothing pending, no model loaded).
- Existing behaviour kept: a file that fails can use all 3 embed attempts within one run (the loop re-fetches it), and after an interruption `runInProgress` stays true so the "interrupted" notice may show while WorkManager is about to resume.
- Phase 2 and later were not started.

### Handoff for the next session
1. Push and run CI (`assembleDebug`, INTERNET check, `testDebugUnitTest`); fix any compile errors in the files listed as "read only" above.
2. Run `connectedDebugAndroidTest` (workflow_dispatch) to execute `EmbeddingCheckpointTest` and `IndexSchedulingTest`.
3. On the RMX5000: with semantic on and a model imported, check (a) unplugged -> "Paused: waiting for the charger" and a queued `index_resume`, (b) plug in -> it resumes, (c) kill the app mid-run and reboot -> it continues without re-embedding finished files, (d) log what `currentThermalStatus` reports under load.
4. Decide whether to expose the battery floor/thermal actions in Settings, and whether the extraction phase should also be gated.


## Phase 2: inference and thumbnail optimization (implementation checkpoint; not device-validated)

Implemented in this checkpoint:
- CLIP image inference now supports real NCHW tensor batches of 1, 2, or 4 images. The indexer preserves input order/file mapping, handles incomplete groups, retries failed batch inference per image, and recycles decoded bitmaps in `finally`. Preprocessing reuses its pixel array and direct float buffer while the image session remains loaded.
- ONNX provider preference supports CPU, XNNPACK and NNAPI through runtime API reflection, preserving the pinned ONNX Runtime Android 1.19.2 dependency. Missing APIs or session creation failures retry with CPU. The activated provider is logged. This is provider selection, not a claim of GPU execution; NNAPI may delegate operations to CPU.
- Added a bounded app-private LRU thumbnail cache keyed by canonical file path, length, modification time and requested thumbnail size. It decodes downsampled RGB_565 previews, returns caller-owned copies, and does not store source metadata. Cache capacity is configurable.
- Settings expose batch size, provider, thread count and thumbnail cache capacity. Provider/thread changes unload model sessions; new settings take effect on subsequent session creation.
- Benchmark output now measures synthetic-image batch inference for 1/2/4 on the configured provider and reports configured provider/thread/batch settings. It explicitly identifies unsupported/unmeasured comparisons rather than inventing results.
- Added pure JVM tests for batch ordering, incomplete final groups and fallback semantics.

Not yet verified / known gaps:
- No Android SDK, Gradle executable/wrapper or reachable dependency repositories are available in this environment. Android compilation and Gradle tests were not run.
- No RMX5000 physical device is connected. No device performance, peak memory, thermal or battery claims are made.
- Provider cross-comparison, real gallery corpus indexing throughput, search latency, thumbnail LRU instrumentation tests and hardware provider behavior remain unmeasured. The thumbnail cache primitive is provided in AppContainer; current image display call sites have not yet been migrated to it.
- Runtime reflection intentionally avoids upgrading ONNX Runtime, but provider API signatures and execution-provider availability must be confirmed on-device. CPU fallback is attempted if provider session creation fails.
- Phase 3 was not started.
