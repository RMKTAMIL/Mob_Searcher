# MobileRAG 1.0.0-rc1

Private, on-device file search for Android: keywords, phrases, OCR text, image labels and (optionally) meaning-based
search with local AI models. Results show the real path and open inside the app.

**Status: release candidate, written but never compiled or run by its author.** Expect to fix a few build errors on the
first CI run. Offline operation is by design and NOT yet verified (docs/AIRPLANE_MODE_TEST.md).

## Build
Push the folder to your own repository; the GitHub Action builds `app-debug.apk` (artifact `MobileRAG-debug-apk`), checks
that the APK has no INTERNET permission, then runs the unit tests. Optional signed release: add secrets
`RELEASE_KEYSTORE_BASE64`, `RELEASE_KEYSTORE_PASSWORD`, `RELEASE_KEY_ALIAS`, `RELEASE_KEY_PASSWORD`.
Emulator tests: run the workflow manually (workflow_dispatch). Never commit release keys.

## Use
1. Install, grant all-files access (see docs/ARCHITECTURE.md for why).
2. Settings: pick folders / quick-add WhatsApp, Telegram etc.
3. Index > Index now (background, resumable).
4. Search: words, "exact phrase", filters (type, date, size, folder, app), sort.

## Semantic search (optional, on-device)
The app cannot download models. Build model packs on a computer (`tools/make_model_pack.py`), copy them to the phone and
import them in Settings. Without models everything still works with keywords, OCR and labels. See docs/MODELS.md.

## Privacy
No INTERNET permission, no analytics, app-private database, no backups. Files, text, OCR results and embeddings never
leave the device.

Docs: docs/ARCHITECTURE.md, docs/MODELS.md, docs/AUDIT.md, docs/AIRPLANE_MODE_TEST.md, CHANGELOG.md, DEVELOPMENT_PROGRESS.md
