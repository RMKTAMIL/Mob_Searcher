package com.mrk.filerag

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.mrk.filerag.data.Db
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class DbMigrationTest {
    @Test fun v1ToV2KeepsAllData() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val name = "mig_test.db"
        ctx.deleteDatabase(name)
        val f = ctx.getDatabasePath(name)
        f.parentFile?.mkdirs()
        val old = SQLiteDatabase.openOrCreateDatabase(f, null)
        old.execSQL("CREATE TABLE files(id INTEGER PRIMARY KEY AUTOINCREMENT, path TEXT UNIQUE, mtime INTEGER, size INTEGER)")
        old.execSQL("CREATE VIRTUAL TABLE fts USING fts4(name, content, tokenize=porter)")
        old.execSQL("INSERT INTO files(path, mtime, size) VALUES('/x/a.txt', 5, 10)")
        old.execSQL("INSERT INTO fts(docid, name, content) VALUES(1, 'a.txt x', 'hello migration world')")
        old.version = 1
        old.close()

        val db = Db(ctx, name)
        db.readableDatabase.rawQuery("SELECT path, status, attempts FROM files", null).use { c ->
            assertTrue(c.moveToFirst())
            assertEquals("/x/a.txt", c.getString(0))
            assertEquals(1, c.getInt(1))
            assertEquals(0, c.getInt(2))
        }
        db.readableDatabase.rawQuery("SELECT docid FROM docs_fts WHERE docs_fts MATCH 'migration'", null).use {
            assertTrue("old text must still be searchable", it.moveToFirst())
        }
        db.readableDatabase.rawQuery("SELECT name FROM sqlite_master WHERE name = 'fts'", null).use {
            assertFalse("old fts table is replaced by docs_fts", it.moveToFirst())
        }
        db.readableDatabase.rawQuery("SELECT name FROM sqlite_master WHERE name IN ('embeddings','embed_state','search_history')", null).use {
            assertEquals(3, it.count)
        }
        db.close()
        ctx.deleteDatabase(name)
    }
}
