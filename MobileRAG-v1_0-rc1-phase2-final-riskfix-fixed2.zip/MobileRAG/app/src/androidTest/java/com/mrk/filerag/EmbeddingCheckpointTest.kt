package com.mrk.filerag

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.mrk.filerag.data.Db
import com.mrk.filerag.data.EmbeddingRepository
import com.mrk.filerag.data.FileJob
import com.mrk.filerag.data.IndexRepository
import com.mrk.filerag.data.IndexedItem
import com.mrk.filerag.data.Status
import com.mrk.filerag.extract.Extracted
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

/**
 * Phase 1 checkpoint/recovery behaviour of the EXISTING embed_state/embeddings tables (no second checkpoint system).
 * "Process death" is simulated by closing the database and opening a fresh Db on the same file, which is what a
 * restarted process sees. These tests need a device/emulator (real SQLite); they are not part of the JVM unit run.
 */
@RunWith(AndroidJUnit4::class)
class EmbeddingCheckpointTest {
    private lateinit var ctx: Context
    private lateinit var db: Db
    private lateinit var repo: IndexRepository
    private lateinit var emb: EmbeddingRepository
    private val name = "ckpt_test.db"
    private val key = "text-model@1"
    private val vec = listOf(FloatArray(8) { it / 8f })

    @Before fun setUp() {
        ctx = ApplicationProvider.getApplicationContext()
        ctx.deleteDatabase(name)
        open()
    }

    @After fun tearDown() { db.close(); ctx.deleteDatabase(name) }

    private fun open() {
        db = Db(ctx, name)
        repo = IndexRepository(db)
        emb = EmbeddingRepository(db)
    }

    private fun restartProcess() { db.close(); open() }

    private fun index(path: String, mtime: Long, fp: String?, text: String = "content of $path") {
        val job = FileJob(File(path), path, mtime, 10L)
        repo.writeBatch(listOf(IndexedItem(job, "text/plain", Status.OK, null, Extracted(content = text), fp)))
    }

    private fun idOf(path: String): Long =
        emb.pendingText(key, 100).first { it.path == path }.id

    private fun pendingPaths() = emb.pendingText(key, 100).map { it.path }

    @Test fun completedFilesStayCompletedAfterRestart() {
        index("/t/a.txt", 1, "fa"); index("/t/b.txt", 1, "fb"); index("/t/c.txt", 1, "fc")
        emb.save(idOf("/t/a.txt"), key, vec)           // batch boundary reached for a only
        restartProcess()
        assertEquals(listOf("/t/b.txt", "/t/c.txt"), pendingPaths())
        assertEquals(1, emb.embeddedFiles(key))        // a's vectors survived
    }

    @Test fun savedFileIsNotEmbeddedAgain() {
        index("/t/a.txt", 1, "fa")
        emb.save(idOf("/t/a.txt"), key, vec)
        assertTrue(pendingPaths().isEmpty())
        assertEquals(0, emb.countPendingText(key))
    }

    @Test fun failedFileDoesNotBlockTheOthersAndIsRetriedUntilExhausted() {
        index("/t/bad.txt", 1, "f1"); index("/t/good.txt", 1, "f2")
        val bad = idOf("/t/bad.txt")
        emb.markFailed(bad, key, "boom")
        assertTrue("one failure leaves retries", "/t/bad.txt" in pendingPaths())
        emb.save(idOf("/t/good.txt"), key, vec)        // the rest of the job carries on
        emb.markFailed(bad, key, "boom"); emb.markFailed(bad, key, "boom")
        assertFalse("exhausted after 3 attempts", "/t/bad.txt" in pendingPaths())
        restartProcess()
        assertTrue(pendingPaths().isEmpty())           // and that survives a restart
    }

    @Test fun changedFileIsReEmbeddedAndUnchangedFileIsNot() {
        index("/t/a.txt", 1, "fa"); index("/t/b.txt", 1, "fb")
        emb.save(idOf("/t/a.txt"), key, vec); emb.save(idOf("/t/b.txt"), key, vec)
        assertTrue(pendingPaths().isEmpty())
        index("/t/a.txt", 2, "fa2", "a changed")        // new mtime/fingerprint, as the Indexer would write it
        assertEquals(listOf("/t/a.txt"), pendingPaths())
        assertEquals(1, emb.embeddedFiles(key))         // only b still has vectors; a's stale ones were dropped
    }

    @Test fun exhaustedFailureBecomesEligibleAgainWhenTheFileChanges() {
        index("/t/a.txt", 1, "fa")
        val id = idOf("/t/a.txt")
        repeat(3) { emb.markFailed(id, key, "boom") }
        assertTrue(pendingPaths().isEmpty())
        index("/t/a.txt", 2, "fa2")
        assertEquals(listOf("/t/a.txt"), pendingPaths())
    }

    @Test fun identicalFileReusesVectorsWithoutRunningTheModel() {
        index("/t/a.txt", 1, "same"); index("/t/copy.txt", 1, "same")
        emb.save(idOf("/t/a.txt"), key, vec)
        val copy = idOf("/t/copy.txt")
        assertTrue(emb.reuse(copy, "same", key))
        assertTrue(pendingPaths().isEmpty())
        assertEquals(2, emb.embeddedFiles(key))
    }

    @Test fun pendingWorkSurvivesRepeatedRestarts() {
        for (i in 1..30) index("/t/f$i.txt", 1, "fp$i")
        repeat(3) { round ->
            val batch = emb.pendingText(key, 10)
            batch.forEach { emb.save(it.id, key, vec) }
            restartProcess()
            assertEquals(30 - 10 * (round + 1), emb.countPendingText(key))
        }
    }
}
