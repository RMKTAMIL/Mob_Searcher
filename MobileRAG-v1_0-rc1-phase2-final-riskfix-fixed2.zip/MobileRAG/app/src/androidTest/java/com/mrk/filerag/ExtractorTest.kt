package com.mrk.filerag

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.mrk.filerag.extract.ExtractContext
import com.mrk.filerag.extract.ExtractResult
import com.mrk.filerag.extract.Extractors
import com.mrk.filerag.extract.Limits
import com.mrk.filerag.index.IndexOptions
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

@RunWith(AndroidJUnit4::class)
class ExtractorTest {
    private lateinit var ctx: Context
    private lateinit var dir: File
    private val noMl = IndexOptions(labels = false, ocr = false)

    @Before fun setUp() {
        ctx = ApplicationProvider.getApplicationContext()
        dir = File(ctx.cacheDir, "extract_test").apply { deleteRecursively(); mkdirs() }
    }

    private fun zip(name: String, entries: Map<String, String>): File {
        val f = File(dir, name)
        ZipOutputStream(f.outputStream()).use { z -> entries.forEach { (n, c) -> z.putNextEntry(ZipEntry(n)); z.write(c.toByteArray()); z.closeEntry() } }
        return f
    }

    private fun run(f: File, opts: IndexOptions = noMl) = Extractors.extract(f, f.extension, ExtractContext(ctx, opts))
    private fun text(r: ExtractResult) = (r as ExtractResult.Ok).data.content

    @Test fun docx() = assertTrue(text(run(zip("a.docx", mapOf("word/document.xml" to "<w:p><w:r><w:t>Quarterly budget</w:t></w:r></w:p>")))).contains("Quarterly budget"))

    @Test fun pptx() = assertTrue(text(run(zip("a.pptx", mapOf("ppt/slides/slide1.xml" to "<a:p><a:r><a:t>Roadmap</a:t></a:r></a:p>")))).contains("Roadmap"))

    @Test fun xlsx() {
        val f = zip("a.xlsx", mapOf("xl/workbook.xml" to "<sheets><sheet name=\"Sales\"/></sheets>", "xl/sharedStrings.xml" to "<sst><si><t>Invoice</t></si></sst>"))
        val t = text(run(f))
        assertTrue(t.contains("Sales") && t.contains("Invoice"))
    }

    @Test fun corruptedArchiveFailsSafely() {
        val f = File(dir, "bad.docx").apply { writeText("this is not a zip") }
        assertTrue(run(f) is ExtractResult.Failed)
    }

    @Test fun docxMissingBodyFails() = assertTrue(run(zip("x.docx", mapOf("other.xml" to "x"))) is ExtractResult.Failed)

    @Test fun binaryNamedLogIsSkipped() {
        val f = File(dir, "bin.log").apply { writeBytes(ByteArray(2048) { (it % 7).toByte() }) }
        assertTrue(run(f) is ExtractResult.Skipped)
    }

    @Test fun hugeTextIsCapped() {
        val f = File(dir, "big.txt").apply { writeText("word ".repeat(2_000_000)) }
        assertEquals(Limits.TEXT_CHARS, text(run(f)).length)
    }

    @Test fun htmlAndMarkdown() {
        assertEquals("Hello", text(run(File(dir, "p.html").apply { writeText("<html><body><script>x()</script><b>Hello</b></body></html>") })))
        assertEquals("# Title", text(run(File(dir, "p.md").apply { writeText("# Title") })).trim())
    }

    @Test fun pdfTextLayer() {
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        page.canvas.drawText("hello pdf extraction", 50f, 100f, Paint().apply { textSize = 18f })
        doc.finishPage(page)
        val f = File(dir, "t.pdf")
        f.outputStream().use { doc.writeTo(it) }
        doc.close()
        assertTrue(text(run(f)).contains("pdf extraction"))
    }

    @Test fun ocrPipelineReadsTextInImage() {
        val bmp = Bitmap.createBitmap(900, 300, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.WHITE)
        c.drawText("INVOICE 2024", 40f, 170f, Paint().apply { color = Color.BLACK; textSize = 90f; isAntiAlias = true })
        val f = File(dir, "scan.png")
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val r = run(f, IndexOptions(labels = false, ocr = true)) as ExtractResult.Ok
        assertTrue(r.data.ocr.uppercase().contains("INVOICE"))
        assertEquals(900, r.data.width)
    }

    @Test fun undecodableImageFails() = assertTrue(run(File(dir, "x.jpg").apply { writeText("nope") }) is ExtractResult.Failed)
}
