package com.mrk.filerag

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.mrk.filerag.data.Db
import com.mrk.filerag.data.IndexRepository
import com.mrk.filerag.index.IndexOptions
import com.mrk.filerag.index.Indexer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

@RunWith(AndroidJUnit4::class)
class IncrementalIndexTest {
    private lateinit var ctx: Context
    private lateinit var db: Db
    private lateinit var repo: IndexRepository
    private lateinit var dir: File
    private val name = "inc_test.db"
    private val opts = IndexOptions(labels = false, ocr = false)

    @Before fun setUp() {
        ctx = ApplicationProvider.getApplicationContext()
        ctx.deleteDatabase(name)
        db = Db(ctx, name)
        repo = IndexRepository(db)
        dir = File(ctx.cacheDir, "inc_test").apply { deleteRecursively(); mkdirs() }
        File(dir, "a.txt").writeText("alpha")
        File(dir, "b.txt").writeText("bravo")
        File(dir, "c.txt").writeText("alpha")      // same bytes as a.txt: duplicate
        File(dir, "empty.txt").writeText("")
    }

    @After fun tearDown() { db.close(); ctx.deleteDatabase(name); dir.deleteRecursively() }

    private fun run() = runBlocking { Indexer(ctx, repo).run(listOf(dir), opts) { } }

    @Test fun incrementalDeletedAndDuplicates() {
        val first = run()
        assertEquals(3, first.indexed)
        assertEquals(1, first.empty)

        val second = run()
        assertEquals(0, second.indexed)
        assertEquals(3, second.unchanged)

        File(dir, "d.txt").writeText("alpha") // identical bytes to a.txt/c.txt, added after they were committed
        val third = run()
        assertEquals(1, third.indexed)
        assertEquals(1, third.reused)

        val b = File(dir, "b.txt")
        b.writeText("bravo changed")
        b.setLastModified(System.currentTimeMillis() + 5000)
        assertEquals(1, run().indexed)

        File(dir, "a.txt").delete()
        val fourth = run()
        assertEquals(1, fourth.removed)
        assertEquals(3, repo.count())
    }

    @Test fun cancellationKeepsCommittedWorkAndResumes() {
        for (i in 1..200) File(dir, "f$i.txt").writeText("content number $i")
        runBlocking {
            val job = launch(Dispatchers.Default) { Indexer(ctx, repo).run(listOf(dir), opts) { } }
            delay(30)
            job.cancel()
            job.join()
        }
        val partial = repo.count()
        val resumed = run()
        assertEquals(203, repo.count()) // 200 + a, b, c
        assertEquals(203 - partial, resumed.indexed)
    }
}
