package com.mrk.filerag

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.work.Configuration
import androidx.work.WorkManager
import androidx.work.testing.WorkManagerTestInitHelper
import com.mrk.filerag.index.IndexScheduler
import com.mrk.filerag.index.ResumePlan
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Unique-work behaviour with WorkManager's test driver (nothing actually runs; delays and constraints are never met).
 * Needs a device/emulator; not part of the JVM unit run.
 */
@RunWith(AndroidJUnit4::class)
class IndexSchedulingTest {
    private lateinit var ctx: Context
    private lateinit var wm: WorkManager

    @Before fun setUp() {
        ctx = ApplicationProvider.getApplicationContext()
        WorkManagerTestInitHelper.initializeTestWorkManager(ctx, Configuration.Builder().build())
        wm = WorkManager.getInstance(ctx)
    }

    private fun pending(name: String) = wm.getWorkInfosForUniqueWork(name).get().count { !it.state.isFinished }

    @Test fun repeatedStartDoesNotQueueDuplicateIndexJobs() {
        IndexScheduler.start(ctx); IndexScheduler.start(ctx); IndexScheduler.start(ctx)
        assertEquals(1, pending(IndexScheduler.NOW))
    }

    @Test fun repeatedResumeSchedulingKeepsASinglePendingResume() {
        val plan = ResumePlan(requiresCharging = true, delayMinutes = 15, idlePauses = 1)
        IndexScheduler.scheduleResume(ctx, plan, fromResumeJob = false)
        IndexScheduler.scheduleResume(ctx, plan.copy(idlePauses = 2), fromResumeJob = false)
        assertEquals(1, pending(IndexScheduler.RESUME))
    }

    @Test fun stopCancelsBothTheRunAndAPendingResume() {
        IndexScheduler.start(ctx)
        IndexScheduler.scheduleResume(ctx, ResumePlan(true, 0, 1), fromResumeJob = false)
        IndexScheduler.stop(ctx)
        assertEquals(0, pending(IndexScheduler.NOW))
        assertEquals(0, pending(IndexScheduler.RESUME))
    }

    @Test fun resumeAndRunUseDifferentUniqueNames() {
        IndexScheduler.start(ctx)
        IndexScheduler.scheduleResume(ctx, ResumePlan(false, 15, 1), fromResumeJob = false)
        assertEquals(1, pending(IndexScheduler.NOW))
        assertEquals(1, pending(IndexScheduler.RESUME))
    }
}
