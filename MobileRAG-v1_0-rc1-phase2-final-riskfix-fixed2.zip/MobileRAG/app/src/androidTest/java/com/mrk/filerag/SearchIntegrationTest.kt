package com.mrk.filerag

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.mrk.filerag.data.Db
import com.mrk.filerag.data.FileJob
import com.mrk.filerag.data.IndexRepository
import com.mrk.filerag.data.IndexedItem
import com.mrk.filerag.data.Status
import com.mrk.filerag.extract.Extracted
import com.mrk.filerag.search.Filters
import com.mrk.filerag.search.KeywordRetriever
import com.mrk.filerag.search.Kind
import com.mrk.filerag.search.SearchEngine
import com.mrk.filerag.search.SortBy
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

@RunWith(AndroidJUnit4::class)
class SearchIntegrationTest {
    private lateinit var ctx: Context
    private lateinit var db: Db
    private lateinit var repo: IndexRepository
    private lateinit var engine: SearchEngine
    private val name = "search_test.db"

    @Before fun setUp() {
        ctx = ApplicationProvider.getApplicationContext()
        ctx.deleteDatabase(name)
        db = Db(ctx, name)
        repo = IndexRepository(db)
        engine = SearchEngine(db, listOf(KeywordRetriever(db)))
    }

    @After fun tearDown() { db.close(); ctx.deleteDatabase(name) }

    private fun add(path: String, content: String, mtime: Long = 1000, ocr: String = "") {
        val f = File(path)
        repo.writeBatch(listOf(IndexedItem(FileJob(f, path, mtime, 100), "text/plain", Status.OK, null, Extracted(content = content, ocr = ocr), null)))
    }

    private fun names(q: String, f: Filters = Filters()): List<String> {
        val s = engine.start(q, f)
        val out = ArrayList<String>()
        while (s.hasMore()) out.addAll(s.nextPage().map { it.name })
        return out
    }

    @Test fun andPhrasePrefix() {
        add("/t/a.txt", "the quick brown fox")
        add("/t/b.txt", "quick red fox")
        assertEquals(setOf("a.txt", "b.txt"), names("quick fox").toSet())
        assertEquals(listOf("a.txt"), names("\"quick brown\""))
        assertEquals(setOf("a.txt", "b.txt"), names("fo").toSet())
    }

    @Test fun nameMatchRanksFirst() {
        for (i in 1..30) add("/t/f$i.txt", "filler text $i") // gives BM25 a meaningful corpus size
        add("/t/report.txt", "nothing relevant here")
        add("/t/other.txt", "this report is about reports and more reports")
        assertEquals("report.txt", names("report").first())
    }

    @Test fun exactPhraseOutranksScatteredTerms() {
        add("/t/scattered.txt", "free things and a fire elsewhere")
        add("/t/adjacent.txt", "free fire")
        add("/t/far.txt", "free " + "x ".repeat(50) + "fire")
        assertEquals("adjacent.txt", names("free fire").first())
    }

    @Test fun ocrTextIsSearchable() {
        add("/t/shot.png", "photo", ocr = "invoice total 4821")
        assertEquals(listOf("shot.png"), names("invoice"))
    }

    @Test fun paginationReturnsEverythingOnce() {
        for (i in 1..75) add("/t/doc$i.txt", "common keyword number $i")
        val s = engine.start("keyword", Filters())
        assertEquals(75, s.total)
        val sizes = ArrayList<Int>()
        val seen = HashSet<Long>()
        while (s.hasMore()) { val p = s.nextPage(); sizes.add(p.size); p.forEach { seen.add(it.id) } }
        assertEquals(listOf(30, 30, 15), sizes)
        assertEquals(75, seen.size)
    }

    @Test fun filtersAndSorting() {
        add("/t/a.pdf", "alpha budget", mtime = 1)
        add("/t/b.txt", "alpha budget", mtime = 3)
        add("/t/c.pdf", "alpha budget", mtime = 2)
        assertEquals(setOf("a.pdf", "c.pdf"), names("alpha", Filters(kind = Kind.PDF)).toSet())
        assertEquals(listOf("b.txt", "c.pdf", "a.pdf"), names("alpha", Filters(sort = SortBy.NEWEST)))
        assertEquals(listOf("a.pdf", "c.pdf"), names("", Filters(kind = Kind.PDF, sort = SortBy.OLDEST)))
    }

    @Test fun reindexingReplacesTextAndDropsEmbeddings() {
        add("/t/a.txt", "first version")
        val id = engine.start("first", Filters()).nextPage().first().id
        db.writableDatabase.execSQL("INSERT INTO embeddings(file_id, model_key, chunk, dim, scale, vec) VALUES(?,?,?,?,?,?)", arrayOf<Any>(id, "m@1", 0, 2, 1.0, byteArrayOf(1, 2)))
        add("/t/a.txt", "second version", mtime = 2000)
        assertTrue(names("first").isEmpty())
        assertEquals(listOf("a.txt"), names("second"))
        db.readableDatabase.rawQuery("SELECT COUNT(*) FROM embeddings", null).use { it.moveToFirst(); assertEquals(0, it.getInt(0)) }
    }

    @Test fun deletingFileCascadesToEmbeddings() {
        add("/t/gone.txt", "bye")
        val id = engine.start("bye", Filters()).nextPage().first().id
        db.writableDatabase.execSQL("INSERT INTO embeddings(file_id, model_key, chunk, dim, scale, vec) VALUES(?,?,?,?,?,?)", arrayOf<Any>(id, "m@1", 0, 2, 1.0, byteArrayOf(1, 2)))
        assertEquals(1, repo.removeMissing()) // /t/gone.txt does not exist on the device
        db.readableDatabase.rawQuery("SELECT COUNT(*) FROM embeddings", null).use { it.moveToFirst(); assertEquals(0, it.getInt(0)) }
    }
}
