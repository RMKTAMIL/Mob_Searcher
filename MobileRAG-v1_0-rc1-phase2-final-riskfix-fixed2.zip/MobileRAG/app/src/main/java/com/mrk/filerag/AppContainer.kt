package com.mrk.filerag

import android.content.ComponentCallbacks2
import android.content.Context
import android.content.res.Configuration
import com.mrk.filerag.files.ThumbnailCache
import com.mrk.filerag.data.Db
import com.mrk.filerag.data.EmbeddingRepository
import com.mrk.filerag.data.HistoryStore
import com.mrk.filerag.data.IndexRepository
import com.mrk.filerag.power.AndroidPowerSource
import com.mrk.filerag.power.PowerGate
import com.mrk.filerag.search.KeywordRetriever
import com.mrk.filerag.search.SearchEngine
import com.mrk.filerag.semantic.ModelManager
import com.mrk.filerag.semantic.ModelStore
import com.mrk.filerag.semantic.SemanticRetriever
import com.mrk.filerag.settings.Prefs

/** Hand-wired dependencies (small app: no DI framework needed). */
class AppContainer private constructor(val app: Context) {
    val db = Db.get(app)
    val prefs = Prefs(app)
    val thumbnails = ThumbnailCache(prefs.thumbnailCacheMb * 1024 * 1024)
    val repo = IndexRepository(db)
    val embeddings = EmbeddingRepository(db)
    val history = HistoryStore(db)
    val models = ModelManager(app, ModelStore(app), prefs)
    val power = PowerGate(AndroidPowerSource(app), config = { prefs.powerConfig() })
    val search = SearchEngine(db, listOf(KeywordRetriever(db), SemanticRetriever(db, embeddings, models, prefs)))

    init {
        app.registerComponentCallbacks(object : ComponentCallbacks2 {
            override fun onTrimMemory(level: Int) {
                if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) models.unloadAll()
            }
            override fun onConfigurationChanged(newConfig: Configuration) {}
            @Deprecated("Deprecated in Java")
            override fun onLowMemory() { models.unloadAll() }
        })
    }

    companion object {
        @Volatile
        private var inst: AppContainer? = null

        fun get(ctx: Context): AppContainer = inst ?: synchronized(this) {
            inst ?: AppContainer(ctx.applicationContext).also { inst = it }
        }
    }
}
