package com.mrk.filerag.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import java.io.File

/**
 * Schema v2. v1 databases (app v0.1-v0.3) are migrated in place without deleting data; the old file is
 * additionally copied to rag.db.v1.bak before the first open of a v2 build (see [get]).
 */
class Db internal constructor(ctx: Context, name: String = NAME) : SQLiteOpenHelper(ctx, name, null, VERSION) {

    init {
        setWriteAheadLoggingEnabled(true) // readers (search) are not blocked by the indexer's writes
    }

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(FILES_SQL)
        db.execSQL(FTS_SQL)
        createAux(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) migrateV1ToV2(db)
    }

    private fun migrateV1ToV2(db: SQLiteDatabase) {
        val cols = listOf(
            "mime TEXT", "status INTEGER NOT NULL DEFAULT 1", "attempts INTEGER NOT NULL DEFAULT 0", "error TEXT",
            "indexed_at INTEGER NOT NULL DEFAULT 0", "fp TEXT", "width INTEGER NOT NULL DEFAULT 0",
            "height INTEGER NOT NULL DEFAULT 0"
        )
        for (c in cols) db.execSQL("ALTER TABLE files ADD COLUMN $c")
        db.execSQL(FTS_SQL)
        // Existing text (v1 stored labels/OCR inside `content`) is copied, not discarded.
        db.execSQL("INSERT INTO docs_fts(docid, name, content, labels, ocr) SELECT docid, name, content, '', '' FROM fts")
        db.execSQL("DROP TABLE fts")
        createAux(db)
    }

    companion object {
        const val NAME = "rag.db"
        const val VERSION = 2
        private const val TAG = "Db"

        private const val FILES_SQL =
            "CREATE TABLE files(id INTEGER PRIMARY KEY AUTOINCREMENT, path TEXT UNIQUE NOT NULL, " +
                "mtime INTEGER NOT NULL, size INTEGER NOT NULL, mime TEXT, status INTEGER NOT NULL DEFAULT 1, " +
                "attempts INTEGER NOT NULL DEFAULT 0, error TEXT, indexed_at INTEGER NOT NULL DEFAULT 0, fp TEXT, " +
                "width INTEGER NOT NULL DEFAULT 0, height INTEGER NOT NULL DEFAULT 0)"
        private const val FTS_SQL =
            "CREATE VIRTUAL TABLE docs_fts USING fts4(name, content, labels, ocr, tokenize=porter)"

        private fun createAux(db: SQLiteDatabase) {
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_files_fp ON files(fp)")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_files_status ON files(status)")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_files_mtime ON files(mtime)")
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS search_history(q TEXT PRIMARY KEY, last_used INTEGER NOT NULL, " +
                    "uses INTEGER NOT NULL DEFAULT 1)"
            )
            // Embeddings are keyed by model_key ("id@version") so several model versions can coexist during migration.
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS embeddings(file_id INTEGER NOT NULL, model_key TEXT NOT NULL, " +
                    "chunk INTEGER NOT NULL, dim INTEGER NOT NULL, scale REAL NOT NULL, vec BLOB NOT NULL, " +
                    "PRIMARY KEY(file_id, model_key, chunk), FOREIGN KEY(file_id) REFERENCES files(id) ON DELETE CASCADE)"
            )
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_emb_model ON embeddings(model_key)")
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS embed_state(file_id INTEGER NOT NULL, model_key TEXT NOT NULL, " +
                    "status INTEGER NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, error TEXT, " +
                    "updated_at INTEGER NOT NULL, PRIMARY KEY(file_id, model_key), " +
                    "FOREIGN KEY(file_id) REFERENCES files(id) ON DELETE CASCADE)"
            )
        }

        @Volatile
        private var inst: Db? = null

        fun get(ctx: Context): Db = inst ?: synchronized(this) {
            inst ?: run {
                val app = ctx.applicationContext
                backupIfUpgrading(app)
                Db(app).also { inst = it }
            }
        }

        /** Copies an older-version database aside once, before any migration can touch it. */
        private fun backupIfUpgrading(ctx: Context) {
            val f = ctx.getDatabasePath(NAME)
            if (!f.exists()) return
            val v = try {
                SQLiteDatabase.openDatabase(f.path, null, SQLiteDatabase.OPEN_READONLY).use { it.version }
            } catch (e: Exception) {
                Log.w(TAG, "could not read db version: " + e.javaClass.simpleName)
                return
            }
            if (v in 1 until VERSION) {
                val bak = File(f.path + ".v$v.bak")
                if (!bak.exists()) {
                    try { f.copyTo(bak) } catch (e: Exception) { Log.w(TAG, "backup failed: " + e.javaClass.simpleName) }
                }
            }
        }
    }
}
