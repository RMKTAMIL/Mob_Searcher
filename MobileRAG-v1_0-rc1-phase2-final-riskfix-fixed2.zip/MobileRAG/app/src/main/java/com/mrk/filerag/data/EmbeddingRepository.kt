package com.mrk.filerag.data

import com.mrk.filerag.extract.FileTypes
import com.mrk.filerag.semantic.VectorMath

data class PendingFile(val id: Long, val path: String, val fp: String?)

/** Stores int8-quantized embeddings per (file, model_key, chunk). Old model versions are kept until the user purges them. */
class EmbeddingRepository(private val db: Db) {

    private val imageLike: String =
        "(" + FileTypes.IMAGE_EXT.joinToString(" OR ") { "f.path LIKE '%.$it'" } + ")"

    private val pendingBase =
        "FROM files f WHERE f.status = ${Status.OK} AND NOT EXISTS (SELECT 1 FROM embed_state s " +
            "WHERE s.file_id = f.id AND s.model_key = ? AND (s.status = 1 OR s.attempts >= 3))"
    private val hasText =
        " AND EXISTS (SELECT 1 FROM docs_fts d WHERE d.docid = f.id AND length(d.content) + length(d.ocr) > 0)"

    fun pendingText(key: String, limit: Int): List<PendingFile> = pending("$pendingBase$hasText", key, limit)
    fun pendingImages(key: String, limit: Int): List<PendingFile> = pending("$pendingBase AND $imageLike", key, limit)
    fun countPendingText(key: String): Int = countOf("$pendingBase$hasText", key)
    fun countPendingImages(key: String): Int = countOf("$pendingBase AND $imageLike", key)

    private fun pending(from: String, key: String, limit: Int): List<PendingFile> {
        val out = ArrayList<PendingFile>()
        db.readableDatabase.rawQuery("SELECT f.id, f.path, f.fp $from ORDER BY f.id LIMIT $limit", arrayOf(key)).use { c ->
            while (c.moveToNext()) out.add(PendingFile(c.getLong(0), c.getString(1), c.getString(2)))
        }
        return out
    }

    private fun countOf(from: String, key: String): Int =
        db.readableDatabase.rawQuery("SELECT COUNT(*) $from", arrayOf(key)).use { if (it.moveToFirst()) it.getInt(0) else 0 }

    fun save(fileId: Long, key: String, vectors: List<FloatArray>) {
        val d = db.writableDatabase
        d.beginTransaction()
        try {
            d.delete("embeddings", "file_id=? AND model_key=?", arrayOf(fileId.toString(), key))
            vectors.forEachIndexed { i, v ->
                val (q, scale) = VectorMath.quantize(v)
                d.execSQL(
                    "INSERT INTO embeddings(file_id, model_key, chunk, dim, scale, vec) VALUES(?,?,?,?,?,?)",
                    arrayOf<Any>(fileId, key, i, v.size, scale.toDouble(), q)
                )
            }
            setState(fileId, key, 1, 0, null)
            d.setTransactionSuccessful()
        } finally {
            d.endTransaction()
        }
    }

    fun markFailed(fileId: Long, key: String, message: String) {
        val d = db.writableDatabase
        var prev = 0
        d.rawQuery("SELECT attempts FROM embed_state WHERE file_id=? AND model_key=?", arrayOf(fileId.toString(), key)).use {
            if (it.moveToFirst()) prev = it.getInt(0)
        }
        setState(fileId, key, 3, prev + 1, message.take(200))
    }

    private fun setState(fileId: Long, key: String, status: Int, attempts: Int, error: String?) {
        db.writableDatabase.execSQL(
            "INSERT OR REPLACE INTO embed_state(file_id, model_key, status, attempts, error, updated_at) VALUES(?,?,?,?,?,?)",
            arrayOf<Any?>(fileId, key, status, attempts, error, System.currentTimeMillis())
        )
    }

    /** Copies vectors from an identical file (same fingerprint) instead of running the model again. */
    fun reuse(fileId: Long, fp: String?, key: String): Boolean {
        if (fp == null) return false
        val d = db.writableDatabase
        var src = -1L
        d.rawQuery(
            "SELECT f.id FROM files f JOIN embed_state s ON s.file_id = f.id " +
                "WHERE f.fp = ? AND f.id != ? AND s.model_key = ? AND s.status = 1 LIMIT 1",
            arrayOf(fp, fileId.toString(), key)
        ).use { if (it.moveToFirst()) src = it.getLong(0) }
        if (src < 0) return false
        d.beginTransaction()
        try {
            d.delete("embeddings", "file_id=? AND model_key=?", arrayOf(fileId.toString(), key))
            d.execSQL(
                "INSERT INTO embeddings(file_id, model_key, chunk, dim, scale, vec) " +
                    "SELECT ?, model_key, chunk, dim, scale, vec FROM embeddings WHERE file_id=? AND model_key=?",
                arrayOf<Any>(fileId, src, key)
            )
            setState(fileId, key, 1, 0, null)
            d.setTransactionSuccessful()
        } finally {
            d.endTransaction()
        }
        return true
    }

    /** Streams every vector of [key]; keeps memory flat regardless of collection size. */
    fun scan(key: String, block: (fileId: Long, scale: Float, vec: ByteArray) -> Unit) {
        db.readableDatabase.rawQuery("SELECT file_id, scale, vec FROM embeddings WHERE model_key=?", arrayOf(key)).use { c ->
            while (c.moveToNext()) block(c.getLong(0), c.getFloat(1), c.getBlob(2))
        }
    }

    fun embeddedFiles(key: String): Int =
        db.readableDatabase.rawQuery("SELECT COUNT(DISTINCT file_id) FROM embeddings WHERE model_key=?", arrayOf(key)).use {
            if (it.moveToFirst()) it.getInt(0) else 0
        }

    /** (model_key, files) for every key present in the database. */
    fun keysInUse(): List<Pair<String, Int>> {
        val out = ArrayList<Pair<String, Int>>()
        db.readableDatabase.rawQuery("SELECT model_key, COUNT(DISTINCT file_id) FROM embeddings GROUP BY model_key", null).use { c ->
            while (c.moveToNext()) out.add(Pair(c.getString(0), c.getInt(1)))
        }
        return out
    }

    /** Destructive: only called after explicit user confirmation. */
    fun purgeExcept(keep: Set<String>) {
        val d = db.writableDatabase
        d.beginTransaction()
        try {
            val ph = if (keep.isEmpty()) "''" else keep.joinToString(",") { "?" }
            val args = keep.toTypedArray()
            d.execSQL("DELETE FROM embeddings WHERE model_key NOT IN ($ph)", args)
            d.execSQL("DELETE FROM embed_state WHERE model_key NOT IN ($ph)", args)
            d.setTransactionSuccessful()
        } finally {
            d.endTransaction()
        }
    }
}
