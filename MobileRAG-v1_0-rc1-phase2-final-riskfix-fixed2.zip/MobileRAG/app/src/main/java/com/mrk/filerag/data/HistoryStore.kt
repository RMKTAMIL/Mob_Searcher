package com.mrk.filerag.data

class HistoryStore(private val db: Db) {
    fun record(raw: String) {
        val q = raw.trim().lowercase()
        if (q.length < 2) return
        val d = db.writableDatabase
        val now = System.currentTimeMillis()
        d.beginTransaction()
        try {
            d.execSQL("INSERT OR IGNORE INTO search_history(q, last_used, uses) VALUES(?,?,0)", arrayOf<Any>(q, now))
            d.execSQL("UPDATE search_history SET last_used=?, uses=uses+1 WHERE q=?", arrayOf<Any>(now, q))
            d.execSQL("DELETE FROM search_history WHERE q NOT IN (SELECT q FROM search_history ORDER BY last_used DESC LIMIT 200)")
            d.setTransactionSuccessful()
        } finally {
            d.endTransaction()
        }
    }

    fun recent(limit: Int = 8): List<String> = list("SELECT q FROM search_history ORDER BY last_used DESC LIMIT $limit", emptyArray())

    fun suggest(prefix: String, limit: Int = 4): List<String> {
        val p = prefix.trim().lowercase().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
        if (p.length < 2) return emptyList()
        return list(
            "SELECT q FROM search_history WHERE q LIKE ? ESCAPE '\\' AND q != ? ORDER BY uses DESC, last_used DESC LIMIT $limit",
            arrayOf("$p%", prefix.trim().lowercase())
        )
    }

    fun delete(q: String) {
        db.writableDatabase.execSQL("DELETE FROM search_history WHERE q=?", arrayOf<Any>(q))
    }

    fun clear() {
        db.writableDatabase.execSQL("DELETE FROM search_history")
    }

    private fun list(sql: String, args: Array<String>): List<String> {
        val out = ArrayList<String>()
        db.readableDatabase.rawQuery(sql, args).use { c -> while (c.moveToNext()) out.add(c.getString(0)) }
        return out
    }
}
