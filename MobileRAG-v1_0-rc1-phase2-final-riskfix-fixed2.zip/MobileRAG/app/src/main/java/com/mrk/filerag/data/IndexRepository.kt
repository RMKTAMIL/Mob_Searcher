package com.mrk.filerag.data

import android.content.ContentValues
import com.mrk.filerag.extract.Extracted
import com.mrk.filerag.extract.Limits
import com.mrk.filerag.index.FileState
import java.io.File

data class FileJob(val file: File, val path: String, val mtime: Long, val size: Long)

data class IndexedItem(
    val job: FileJob,
    val mime: String,
    val status: Int,
    val error: String?,
    val data: Extracted,
    val fp: String?,
    val reused: Boolean = false
)

data class DbStats(
    val total: Int,
    val ok: Int,
    val failed: Int,
    val skipped: Int,
    val totalBytes: Long,
    val lastIndexedAt: Long,
    val dbBytes: Long
)

data class FailedFile(val path: String, val error: String, val attempts: Int)

class IndexRepository(private val db: Db) {

    fun count(): Int =
        db.readableDatabase.rawQuery("SELECT COUNT(*) FROM files", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }

    fun stateOf(path: String): FileState? =
        db.readableDatabase.rawQuery("SELECT mtime, size, status, attempts FROM files WHERE path=?", arrayOf(path)).use { c ->
            if (c.moveToFirst()) FileState(c.getLong(0), c.getLong(1), c.getInt(2), c.getInt(3)) else null
        }

    /** Extraction result of another already-indexed file with identical fingerprint (saves OCR/labeling work). */
    fun findReusable(fp: String, excludePath: String): Extracted? =
        db.readableDatabase.rawQuery(
            "SELECT f.width, f.height, d.content, d.labels, d.ocr FROM files f JOIN docs_fts d ON d.docid = f.id " +
                "WHERE f.fp = ? AND f.status = 1 AND f.path != ? " +
                "AND length(d.content) + length(d.labels) + length(d.ocr) > 0 LIMIT 1",
            arrayOf(fp, excludePath)
        ).use { c ->
            if (c.moveToFirst()) Extracted(
                content = c.getString(2) ?: "", labels = c.getString(3) ?: "", ocr = c.getString(4) ?: "",
                width = c.getInt(0), height = c.getInt(1)
            ) else null
        }

    /** Writes a batch in ONE transaction. Changed files lose their stale embeddings so they are re-embedded. */
    fun writeBatch(items: List<IndexedItem>) {
        if (items.isEmpty()) return
        val d = db.writableDatabase
        d.beginTransaction()
        try {
            val now = System.currentTimeMillis()
            for (item in items) {
                var id = -1L
                var prevAttempts = 0
                var prevMtime = -2L
                var prevSize = -2L
                d.rawQuery("SELECT id, attempts, mtime, size FROM files WHERE path=?", arrayOf(item.job.path)).use { c ->
                    if (c.moveToFirst()) {
                        id = c.getLong(0); prevAttempts = c.getInt(1); prevMtime = c.getLong(2); prevSize = c.getLong(3)
                    }
                }
                val same = prevMtime == item.job.mtime && prevSize == item.job.size
                val attempts = if (item.status == Status.FAILED) (if (same) prevAttempts + 1 else 1) else 0
                val cv = ContentValues().apply {
                    put("path", item.job.path); put("mtime", item.job.mtime); put("size", item.job.size)
                    put("mime", item.mime); put("status", item.status); put("attempts", attempts)
                    put("error", item.error); put("indexed_at", now); put("fp", item.fp)
                    put("width", item.data.width); put("height", item.data.height)
                }
                if (id >= 0) {
                    d.update("files", cv, "id=?", arrayOf(id.toString()))
                    d.delete("docs_fts", "docid=?", arrayOf(id.toString()))
                    d.delete("embeddings", "file_id=?", arrayOf(id.toString()))
                    d.delete("embed_state", "file_id=?", arrayOf(id.toString()))
                } else {
                    id = d.insert("files", null, cv)
                }
                val parent = item.job.file.parentFile?.name ?: ""
                d.execSQL(
                    "INSERT INTO docs_fts(docid, name, content, labels, ocr) VALUES(?,?,?,?,?)",
                    arrayOf<Any>(
                        id, item.job.file.name + " " + parent,
                        item.data.content.take(Limits.STORE_CHARS), item.data.labels.take(20_000),
                        item.data.ocr.take(Limits.STORE_CHARS)
                    )
                )
            }
            d.setTransactionSuccessful()
        } finally {
            d.endTransaction()
        }
    }

    private fun deleteIds(ids: List<Long>) {
        if (ids.isEmpty()) return
        val d = db.writableDatabase
        d.beginTransaction()
        try {
            for (id in ids) {
                d.delete("docs_fts", "docid=?", arrayOf(id.toString()))
                d.delete("files", "id=?", arrayOf(id.toString())) // FK cascade removes embeddings/state
            }
            d.setTransactionSuccessful()
        } finally {
            d.endTransaction()
        }
    }

    /** Removes index rows whose file no longer exists. Returns the number removed. */
    fun removeMissing(): Int {
        val gone = ArrayList<Long>()
        db.readableDatabase.rawQuery("SELECT id, path FROM files", null).use { c ->
            while (c.moveToNext()) if (!File(c.getString(1)).exists()) gone.add(c.getLong(0))
        }
        deleteIds(gone)
        db.writableDatabase.execSQL("DELETE FROM docs_fts WHERE docid NOT IN (SELECT id FROM files)")
        return gone.size
    }

    fun pruneOutside(roots: List<String>): Int {
        if (roots.isEmpty()) return 0
        val gone = ArrayList<Long>()
        db.readableDatabase.rawQuery("SELECT id, path FROM files", null).use { c ->
            while (c.moveToNext()) {
                val p = c.getString(1)
                if (roots.none { p == it || p.startsWith(it.trimEnd('/') + "/") }) gone.add(c.getLong(0))
            }
        }
        deleteIds(gone)
        return gone.size
    }

    /** Forces every file to be re-extracted on the next run while keeping current search results usable. */
    fun markAllStale() {
        db.writableDatabase.execSQL("UPDATE files SET mtime = -1")
    }

    fun resetFailed() {
        db.writableDatabase.execSQL("UPDATE files SET attempts = 0, mtime = -1 WHERE status = ${Status.FAILED}")
    }

    fun clear() {
        val d = db.writableDatabase
        d.beginTransaction()
        try {
            d.execSQL("DELETE FROM docs_fts")
            d.execSQL("DELETE FROM files") // cascades to embeddings/embed_state
            d.setTransactionSuccessful()
        } finally {
            d.endTransaction()
        }
    }

    fun optimize() {
        db.writableDatabase.execSQL("INSERT INTO docs_fts(docs_fts) VALUES('optimize')")
    }

    fun textOf(fileId: Long, maxChars: Int = 60_000): String =
        db.readableDatabase.rawQuery("SELECT content, ocr FROM docs_fts WHERE docid=?", arrayOf(fileId.toString())).use { c ->
            if (c.moveToFirst()) ((c.getString(0) ?: "") + " " + (c.getString(1) ?: "")).trim().take(maxChars) else ""
        }

    fun stats(): DbStats {
        val d = db.readableDatabase
        var total = 0; var ok = 0; var failed = 0; var skipped = 0; var bytes = 0L
        d.rawQuery("SELECT status, COUNT(*), COALESCE(SUM(size),0) FROM files GROUP BY status", null).use { c ->
            while (c.moveToNext()) {
                val n = c.getInt(1)
                total += n; bytes += c.getLong(2)
                when (c.getInt(0)) { Status.OK -> ok = n; Status.FAILED -> failed = n; Status.SKIPPED -> skipped = n }
            }
        }
        val last = d.rawQuery("SELECT COALESCE(MAX(indexed_at),0) FROM files", null).use { if (it.moveToFirst()) it.getLong(0) else 0L }
        val f = File(d.path)
        val dbBytes = f.length() + File(f.path + "-wal").length()
        return DbStats(total, ok, failed, skipped, bytes, last, dbBytes)
    }

    fun failedFiles(limit: Int = 50): List<FailedFile> {
        val out = ArrayList<FailedFile>()
        db.readableDatabase.rawQuery(
            "SELECT path, COALESCE(error,''), attempts FROM files WHERE status = ${Status.FAILED} " +
                "ORDER BY indexed_at DESC LIMIT $limit", null
        ).use { c -> while (c.moveToNext()) out.add(FailedFile(c.getString(0), c.getString(1), c.getInt(2))) }
        return out
    }
}
