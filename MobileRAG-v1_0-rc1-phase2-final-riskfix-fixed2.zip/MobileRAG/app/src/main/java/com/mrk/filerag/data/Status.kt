package com.mrk.filerag.data

object Status {
    const val OK = 1
    const val FAILED = 3
    const val SKIPPED = 4
}
