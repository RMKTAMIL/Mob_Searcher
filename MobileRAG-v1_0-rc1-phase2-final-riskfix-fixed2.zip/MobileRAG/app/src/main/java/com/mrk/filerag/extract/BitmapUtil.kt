package com.mrk.filerag.extract

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.util.Log
import androidx.exifinterface.media.ExifInterface
import java.io.IOException

object BitmapUtil {
    private const val TAG = "BitmapUtil"

    /** Downscaled decode (never larger than ~[max] px on the long side, via power-of-two sampling). */
    fun decodeScaled(path: String, max: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, o)
        var s = 1
        while (o.outWidth / s > max || o.outHeight / s > max) s *= 2
        return BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s })
    }

    fun exifDegrees(path: String): Int = try {
        when (ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90
            ExifInterface.ORIENTATION_ROTATE_180 -> 180
            ExifInterface.ORIENTATION_ROTATE_270 -> 270
            else -> 0
        }
    } catch (e: IOException) {
        Log.d(TAG, "no exif: " + e.javaClass.simpleName)
        0
    }

    /** Decoded and rotated according to EXIF so models see the image the right way up. */
    fun decodeUpright(path: String, max: Int): Bitmap? {
        val bm = decodeScaled(path, max) ?: return null
        val deg = exifDegrees(path)
        if (deg == 0) return bm
        val rotated = Bitmap.createBitmap(bm, 0, 0, bm.width, bm.height, Matrix().apply { postRotate(deg.toFloat()) }, true)
        if (rotated !== bm) bm.recycle()
        return rotated
    }

    fun renderPage(r: PdfRenderer, i: Int, w: Int): Bitmap {
        val p = r.openPage(i)
        try {
            val h = (w.toFloat() / p.width * p.height).toInt().coerceAtLeast(1)
            val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            b.eraseColor(Color.WHITE)
            p.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            return b
        } finally {
            p.close()
        }
    }
}
