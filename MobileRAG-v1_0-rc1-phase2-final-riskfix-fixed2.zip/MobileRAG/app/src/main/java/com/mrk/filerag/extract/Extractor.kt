package com.mrk.filerag.extract

import android.content.Context
import com.mrk.filerag.index.IndexOptions
import java.io.File

data class Extracted(
    val content: String = "",
    val labels: String = "",
    val ocr: String = "",
    val width: Int = 0,
    val height: Int = 0
)

sealed class ExtractResult {
    data class Ok(val data: Extracted) : ExtractResult()
    data class Skipped(val reason: String) : ExtractResult()
    data class Failed(val message: String) : ExtractResult()
}

class ExtractContext(val appContext: Context, val opts: IndexOptions)

/** One extractor per family of formats. New formats: implement this and register in [Extractors]. */
interface Extractor {
    fun supports(kind: FileKind): Boolean
    fun extract(file: File, ctx: ExtractContext): ExtractResult
}
