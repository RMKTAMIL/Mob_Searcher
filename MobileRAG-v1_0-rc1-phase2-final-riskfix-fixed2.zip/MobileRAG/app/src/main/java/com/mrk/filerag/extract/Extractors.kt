package com.mrk.filerag.extract

import android.util.Log
import java.io.File

object Extractors {
    private const val TAG = "Extractors"
    private val all: List<Extractor> =
        listOf(ImageExtractor(), PdfExtractor(), OfficeExtractor(), HtmlExtractor(), TextExtractor())

    /** Never throws: failures become [ExtractResult.Failed] so they are recorded and retried, not swallowed. */
    fun extract(file: File, ext: String, ctx: ExtractContext): ExtractResult {
        val kind = FileTypes.kindOf(ext)
        if (!ctx.opts.enabled(kind)) return ExtractResult.Ok(Extracted())
        val ex = all.firstOrNull { it.supports(kind) } ?: return ExtractResult.Ok(Extracted())
        return try {
            ex.extract(file, ctx)
        } catch (e: Throwable) {
            Log.w(TAG, "extract failed kind=$kind: ${e.javaClass.simpleName}")
            ExtractResult.Failed(e.javaClass.simpleName + (e.message?.let { ": " + it.take(120) } ?: ""))
        }
    }
}
