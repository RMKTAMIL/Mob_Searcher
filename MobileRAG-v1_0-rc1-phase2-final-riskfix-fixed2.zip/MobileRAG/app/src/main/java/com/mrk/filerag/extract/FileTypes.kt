package com.mrk.filerag.extract

enum class FileKind { IMAGE, PDF, WORD, SLIDES, SHEET, HTML, TEXT, OTHER }

object FileTypes {
    val IMAGE_EXT = setOf("jpg", "jpeg", "png", "webp", "heic", "heif")
    val HTML_EXT = setOf("html", "htm", "xhtml")
    val TEXT_EXT = setOf(
        "txt", "md", "markdown", "csv", "tsv", "json", "xml", "log", "ini", "yml", "yaml", "toml", "tex", "sql",
        "py", "java", "kt", "kts", "c", "h", "cpp", "cc", "hpp", "cs", "js", "jsx", "ts", "tsx", "go", "rs", "rb",
        "php", "sh", "bat", "swift", "gradle", "properties", "css", "scss"
    )

    fun kindOf(ext: String): FileKind = when (ext.lowercase()) {
        in IMAGE_EXT -> FileKind.IMAGE
        "pdf" -> FileKind.PDF
        "docx" -> FileKind.WORD
        "pptx" -> FileKind.SLIDES
        "xlsx" -> FileKind.SHEET
        in HTML_EXT -> FileKind.HTML
        in TEXT_EXT -> FileKind.TEXT
        else -> FileKind.OTHER
    }

    fun mimeOf(ext: String): String = when (ext.lowercase()) {
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "webp" -> "image/webp"
        "heic", "heif" -> "image/heic"
        "pdf" -> "application/pdf"
        "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
        "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        in HTML_EXT -> "text/html"
        "md", "markdown" -> "text/markdown"
        "csv" -> "text/csv"
        "json" -> "application/json"
        "xml" -> "application/xml"
        in TEXT_EXT -> "text/plain"
        else -> "application/octet-stream"
    }

    /** True when the sample contains a NUL byte or more than 10% control characters. */
    fun looksBinary(sample: ByteArray, len: Int): Boolean {
        if (len <= 0) return false
        var ctrl = 0
        for (i in 0 until len) {
            val b = sample[i].toInt() and 0xFF
            if (b == 0) return true
            if (b < 9 || b in 14..31) ctrl++
        }
        return ctrl * 10 > len
    }
}
