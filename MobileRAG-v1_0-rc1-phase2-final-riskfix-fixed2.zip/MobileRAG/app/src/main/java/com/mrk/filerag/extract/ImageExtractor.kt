package com.mrk.filerag.extract

import android.graphics.BitmapFactory
import android.util.Log
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.IOException

class ImageExtractor : Extractor {
    override fun supports(kind: FileKind) = kind == FileKind.IMAGE

    override fun extract(file: File, ctx: ExtractContext): ExtractResult {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return ExtractResult.Failed("not a decodable image")

        val degrees = BitmapUtil.exifDegrees(file.path)
        var w = bounds.outWidth
        var h = bounds.outHeight
        if (degrees == 90 || degrees == 270) { val t = w; w = h; h = t }

        val sb = StringBuilder("photo picture image ${w}x$h ")
        sb.append(if (w >= h) "landscape " else "portrait ").append(exifText(file.path))

        var labels = ""
        var ocr = ""
        if (ctx.opts.labels || ctx.opts.ocr) {
            val bm = BitmapUtil.decodeScaled(file.path, Limits.IMAGE_ANALYSIS_PX)
                ?: return ExtractResult.Failed("decode failed")
            try {
                if (ctx.opts.labels) labels = MlKit.labels(bm, degrees)
                if (ctx.opts.ocr) ocr = MlKit.ocr(bm, degrees)
            } finally {
                bm.recycle()
            }
        }
        return ExtractResult.Ok(Extracted(content = sb.toString().trim(), labels = labels, ocr = ocr, width = w, height = h))
    }

    /** Date taken, camera make/model. GPS coordinates are deliberately NOT indexed (privacy). */
    private fun exifText(path: String): String = try {
        val e = ExifInterface(path)
        val date = e.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL)?.take(10)?.replace(':', '-') ?: ""
        listOfNotNull(date.ifBlank { null }, e.getAttribute(ExifInterface.TAG_MAKE), e.getAttribute(ExifInterface.TAG_MODEL))
            .joinToString(" ")
    } catch (e: IOException) {
        Log.d("ImageExtractor", "exif unreadable: " + e.javaClass.simpleName)
        ""
    }
}
