package com.mrk.filerag.extract

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.Reader

/** Reads at most [max] bytes from [stream] (closing it) and decodes them as UTF-8. */
fun readLimited(stream: InputStream, max: Int): String {
    stream.use { s ->
        val out = ByteArrayOutputStream(minOf(max, 64 * 1024))
        val buf = ByteArray(8192)
        var total = 0
        while (total < max) {
            val n = s.read(buf, 0, minOf(buf.size, max - total))
            if (n < 0) break
            out.write(buf, 0, n)
            total += n
        }
        return out.toString("UTF-8")
    }
}

/** Reads at most [max] chars from [r]. */
fun readChars(r: Reader, max: Int): String {
    val sb = StringBuilder()
    val buf = CharArray(8192)
    while (sb.length < max) {
        val n = r.read(buf, 0, minOf(buf.size, max - sb.length))
        if (n < 0) break
        sb.append(buf, 0, n)
    }
    return sb.toString()
}
