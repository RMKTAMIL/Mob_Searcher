package com.mrk.filerag.extract

object Limits {
    const val TEXT_CHARS = 200_000
    const val TEXT_SAMPLE_BYTES = 4096
    const val HTML_BYTES = 2_000_000
    const val OFFICE_ENTRY_BYTES = 4_000_000
    const val OFFICE_CHARS = 200_000
    const val MAX_SLIDES = 300
    const val PDF_BYTES = 40_000_000L
    const val PDF_PAGES = 60
    const val PDF_OCR_PAGES = 3
    const val STORE_CHARS = 300_000
    const val IMAGE_ANALYSIS_PX = 1024
}
