package com.mrk.filerag.extract

import android.graphics.Bitmap
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** Bundled ML Kit models (no download, no network). Call only from background threads. */
object MlKit {
    private val labeler by lazy {
        ImageLabeling.getClient(ImageLabelerOptions.Builder().setConfidenceThreshold(0.55f).build())
    }
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    fun labels(bm: Bitmap, rotation: Int): String =
        Tasks.await(labeler.process(InputImage.fromBitmap(bm, rotation))).joinToString(" ") { it.text }

    fun ocr(bm: Bitmap, rotation: Int): String =
        Tasks.await(recognizer.process(InputImage.fromBitmap(bm, rotation))).text
}
