package com.mrk.filerag.extract

import java.io.File
import java.util.zip.ZipFile

/** DOCX, PPTX and XLSX are zip files of XML; only the needed entries are read, each with a hard size cap. */
class OfficeExtractor : Extractor {
    private val slideRe = Regex("ppt/slides/slide(\\d+)\\.xml")
    private val notesRe = Regex("ppt/notesSlides/notesSlide(\\d+)\\.xml")

    override fun supports(kind: FileKind) = kind == FileKind.WORD || kind == FileKind.SLIDES || kind == FileKind.SHEET

    override fun extract(file: File, ctx: ExtractContext): ExtractResult {
        val kind = FileTypes.kindOf(file.extension)
        ZipFile(file).use { zip ->
            val meta = entryText(zip, "docProps/core.xml")?.let { OfficeText.coreMeta(it) } ?: ""
            val body = when (kind) {
                FileKind.WORD -> entryText(zip, "word/document.xml")?.let { OfficeText.wordText(it) }
                    ?: return ExtractResult.Failed("missing word/document.xml")
                FileKind.SLIDES -> slides(zip)
                else -> sheet(zip)
            }
            return ExtractResult.Ok(Extracted(content = (meta + "\n" + body).trim().take(Limits.OFFICE_CHARS)))
        }
    }

    private fun entryText(zip: ZipFile, name: String): String? {
        val e = zip.getEntry(name) ?: return null
        return readLimited(zip.getInputStream(e), Limits.OFFICE_ENTRY_BYTES)
    }

    private fun numbered(zip: ZipFile, re: Regex): List<String> =
        zip.entries().asSequence().map { it.name }
            .mapNotNull { n -> re.matchEntire(n)?.let { Pair(it.groupValues[1].toIntOrNull() ?: 0, n) } }
            .sortedBy { it.first }.map { it.second }.take(Limits.MAX_SLIDES).toList()

    private fun slides(zip: ZipFile): String {
        val sb = StringBuilder()
        for (name in numbered(zip, slideRe) + numbered(zip, notesRe)) {
            if (sb.length > Limits.OFFICE_CHARS) break
            entryText(zip, name)?.let { sb.append(OfficeText.slideText(it)).append('\n') }
        }
        return sb.toString()
    }

    private fun sheet(zip: ZipFile): String {
        val names = entryText(zip, "xl/workbook.xml")?.let { OfficeText.sheetNames(it) } ?: ""
        val strings = entryText(zip, "xl/sharedStrings.xml")?.let { OfficeText.sharedStrings(it) } ?: ""
        return names + "\n" + strings
    }
}
