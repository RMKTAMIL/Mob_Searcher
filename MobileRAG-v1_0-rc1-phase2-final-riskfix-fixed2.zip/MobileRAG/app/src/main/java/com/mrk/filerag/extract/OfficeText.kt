package com.mrk.filerag.extract

/** Pure string helpers for Office XML / HTML text extraction (no Android dependencies). */
object OfficeText {
    private val wordRe = Regex("<w:t(?:\\s[^>]*)?>([^<]*)</w:t>|</w:p>")
    private val slideRe = Regex("<a:t(?:\\s[^>]*)?>([^<]*)</a:t>|</a:p>")
    private val siRe = Regex("<si>([\\s\\S]*?)</si>")
    private val tRe = Regex("<t(?:\\s[^>]*)?>([^<]*)</t>")
    private val sheetRe = Regex("<sheet\\s[^>]*name=\"([^\"]*)\"")
    private val entityRe = Regex("&(#[xX][0-9A-Fa-f]+|#[0-9]+|[a-zA-Z]+);")
    private val scriptRe = Regex("<script[\\s\\S]*?</script>", RegexOption.IGNORE_CASE)
    private val styleRe = Regex("<style[\\s\\S]*?</style>", RegexOption.IGNORE_CASE)
    private val commentRe = Regex("<!--[\\s\\S]*?-->")
    private val tagRe = Regex("<[^>]+>")
    private val wsRe = Regex("\\s+")

    fun decodeEntities(s: String): String {
        if (s.indexOf('&') < 0) return s
        return entityRe.replace(s) { m ->
            val g = m.groupValues[1]
            when {
                g.startsWith("#x") || g.startsWith("#X") -> codePoint(g.substring(2).toIntOrNull(16), m.value)
                g.startsWith("#") -> codePoint(g.substring(1).toIntOrNull(), m.value)
                else -> when (g) {
                    "amp" -> "&"
                    "lt" -> "<"
                    "gt" -> ">"
                    "quot" -> "\""
                    "apos" -> "'"
                    "nbsp" -> " "
                    else -> m.value
                }
            }
        }
    }

    private fun codePoint(cp: Int?, original: String): String =
        if (cp != null && cp in 1..0x10FFFF && cp !in 0xD800..0xDFFF) String(Character.toChars(cp)) else original

    private fun joinRuns(re: Regex, endTag: String, xml: String): String {
        val sb = StringBuilder()
        for (m in re.findAll(xml)) {
            if (m.value == endTag) {
                if (sb.isNotEmpty() && sb.last() != '\n') sb.append('\n')
            } else {
                sb.append(decodeEntities(m.groupValues[1]))
            }
        }
        return sb.toString()
    }

    fun wordText(xml: String): String = joinRuns(wordRe, "</w:p>", xml)
    fun slideText(xml: String): String = joinRuns(slideRe, "</a:p>", xml)

    fun sharedStrings(xml: String): String {
        val sb = StringBuilder()
        for (si in siRe.findAll(xml)) {
            var any = false
            for (t in tRe.findAll(si.groupValues[1])) {
                sb.append(decodeEntities(t.groupValues[1]))
                any = true
            }
            if (any) sb.append('\n')
        }
        return sb.toString()
    }

    fun sheetNames(xml: String): String =
        sheetRe.findAll(xml).joinToString(" ") { decodeEntities(it.groupValues[1]) }

    fun htmlText(html: String): String {
        var s = scriptRe.replace(html, " ")
        s = styleRe.replace(s, " ")
        s = commentRe.replace(s, " ")
        s = tagRe.replace(s, " ")
        return wsRe.replace(decodeEntities(s), " ").trim()
    }

    /** Title, creator, subject and keywords from docProps/core.xml. */
    fun coreMeta(xml: String): String {
        val out = ArrayList<String>()
        for (tag in listOf("dc:title", "dc:creator", "dc:subject", "cp:keywords")) {
            val m = Regex("<$tag[^>]*>([^<]*)</$tag>").find(xml)
            if (m != null && m.groupValues[1].isNotBlank()) out.add(decodeEntities(m.groupValues[1].trim()))
        }
        return out.joinToString(" ")
    }
}
