package com.mrk.filerag.extract

import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File

class PdfExtractor : Extractor {
    override fun supports(kind: FileKind) = kind == FileKind.PDF

    override fun extract(file: File, ctx: ExtractContext): ExtractResult {
        if (file.length() > Limits.PDF_BYTES) return ExtractResult.Skipped("PDF larger than 40 MB")
        PDFBoxResourceLoader.init(ctx.appContext)
        var text = ""
        var meta = ""
        PDDocument.load(file).use { doc ->
            val info = doc.documentInformation
            meta = listOfNotNull(info?.title, info?.author, info?.subject, info?.keywords).joinToString(" ")
            val s = PDFTextStripper()
            s.startPage = 1
            s.endPage = minOf(doc.numberOfPages, Limits.PDF_PAGES)
            text = s.getText(doc)
        }
        // Scanned PDFs have no text layer: OCR the first pages (bundled ML Kit, on device).
        val ocr = if (text.isBlank() && ctx.opts.ocr) ocrFirstPages(file) else ""
        return ExtractResult.Ok(Extracted(content = (meta + "\n" + text).trim(), ocr = ocr))
    }

    private fun ocrFirstPages(file: File): String {
        val sb = StringBuilder()
        val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
        try {
            val r = PdfRenderer(pfd)
            try {
                for (i in 0 until minOf(r.pageCount, Limits.PDF_OCR_PAGES)) {
                    val bm = BitmapUtil.renderPage(r, i, 1200)
                    try { sb.append(MlKit.ocr(bm, 0)).append('\n') } finally { bm.recycle() }
                }
            } finally {
                r.close()
            }
        } finally {
            pfd.close()
        }
        return sb.toString()
    }
}
