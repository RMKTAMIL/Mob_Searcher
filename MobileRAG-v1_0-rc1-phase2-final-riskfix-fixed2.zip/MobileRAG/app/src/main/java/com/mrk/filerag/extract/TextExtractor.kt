package com.mrk.filerag.extract

import java.io.File

class TextExtractor : Extractor {
    override fun supports(kind: FileKind) = kind == FileKind.TEXT

    override fun extract(file: File, ctx: ExtractContext): ExtractResult {
        val sample = ByteArray(Limits.TEXT_SAMPLE_BYTES)
        val n = file.inputStream().use { it.read(sample) }
        if (n > 0 && FileTypes.looksBinary(sample, n)) return ExtractResult.Skipped("binary content")
        val text = file.bufferedReader(Charsets.UTF_8).use { readChars(it, Limits.TEXT_CHARS) }
        return ExtractResult.Ok(Extracted(content = text))
    }
}

class HtmlExtractor : Extractor {
    override fun supports(kind: FileKind) = kind == FileKind.HTML

    override fun extract(file: File, ctx: ExtractContext): ExtractResult {
        val raw = readLimited(file.inputStream(), Limits.HTML_BYTES)
        return ExtractResult.Ok(Extracted(content = OfficeText.htmlText(raw).take(Limits.TEXT_CHARS)))
    }
}
