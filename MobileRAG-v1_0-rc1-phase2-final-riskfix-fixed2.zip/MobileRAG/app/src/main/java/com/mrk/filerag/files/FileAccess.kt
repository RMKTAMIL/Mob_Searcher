package com.mrk.filerag.files

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.util.Log
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File
import java.util.Locale

private const val TAG = "FileAccess"
private const val MAX_CACHE_COPY = 300L * 1024 * 1024

fun hasAccess(ctx: Context): Boolean =
    if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
    else ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

/** Maps a picked document-tree URI to a real directory path (primary storage or SD card). */
fun treeUriToPath(uri: Uri): String? = try {
    val id = DocumentsContract.getTreeDocumentId(uri)
    val parts = id.split(":", limit = 2)
    val vol = parts[0]
    val rel = if (parts.size > 1) parts[1] else ""
    val base = if (vol == "primary") Environment.getExternalStorageDirectory().path else "/storage/$vol"
    val f = if (rel.isEmpty()) File(base) else File(base, rel)
    if (f.isDirectory) f.path else null
} catch (e: Exception) {
    Log.w(TAG, "tree uri not mappable: " + e.javaClass.simpleName)
    null
}

fun shortName(p: String): String = p.trimEnd('/').split('/').takeLast(2).joinToString("/")

fun fmtSize(b: Long): String = when {
    b >= 1_073_741_824L -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
    b >= 1_048_576L -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
    b >= 1024L -> (b / 1024L).toString() + " KB"
    else -> "$b B"
}

/** True when the app did NOT declare the INTERNET permission, i.e. it cannot use the network at all. */
fun hasNoInternetPermission(ctx: Context): Boolean = try {
    @Suppress("DEPRECATION")
    val info = ctx.packageManager.getPackageInfo(ctx.packageName, PackageManager.GET_PERMISSIONS)
    info.requestedPermissions?.contains("android.permission.INTERNET") != true
} catch (e: Exception) {
    false
}

private fun copyToCache(ctx: Context, f: File): File? {
    if (f.length() > MAX_CACHE_COPY) return null
    val dir = File(ctx.cacheDir, "open").apply { mkdirs() }
    val cutoff = System.currentTimeMillis() - 24L * 3600 * 1000
    dir.listFiles()?.forEach { if (it.lastModified() < cutoff) it.delete() }
    val dst = File(dir, Integer.toHexString(f.path.hashCode()) + "_" + f.name)
    f.copyTo(dst, overwrite = true)
    return dst
}

/** Opens [f] in another app. Files outside primary storage are copied (temporarily) to the app cache first. */
fun openExternal(ctx: Context, f: File) {
    try {
        val primary = Environment.getExternalStorageDirectory().canonicalPath
        val shareFile = if (f.canonicalPath.startsWith("$primary/")) f else copyToCache(ctx, f)
        if (shareFile == null) {
            Toast.makeText(ctx, "File is too large to open externally; use the in-app viewer", Toast.LENGTH_LONG).show()
            return
        }
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".provider", shareFile)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, "No app can open this file", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        Log.w(TAG, "open failed: " + e.javaClass.simpleName)
        Toast.makeText(ctx, "Cannot open this file", Toast.LENGTH_SHORT).show()
    }
}
