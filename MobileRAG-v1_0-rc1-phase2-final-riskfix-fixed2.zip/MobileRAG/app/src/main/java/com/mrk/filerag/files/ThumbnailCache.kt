package com.mrk.filerag.files

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import java.io.File

/** App-private bounded thumbnail cache. It stores derived previews only, never source metadata. */
class ThumbnailCache(maxBytes: Int) {
    private val cache = object : LruCache<String, Bitmap>(maxBytes.coerceAtLeast(1)) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.allocationByteCount.coerceAtLeast(1)
        override fun entryRemoved(evicted: Boolean, key: String, oldValue: Bitmap, newValue: Bitmap?) {
            if (oldValue !== newValue && !oldValue.isRecycled) oldValue.recycle()
        }
    }

    @Synchronized fun get(file: File, maxSide: Int = 256): Bitmap? {
        if (!file.isFile || !file.canRead()) return null
        val key = "${file.canonicalPath}|${file.length()}|${file.lastModified()}|$maxSide"
        cache.get(key)?.let { return if (it.isRecycled) null else it.copy(it.config ?: Bitmap.Config.ARGB_8888, false) }
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.path, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            var sample = 1
            while (maxOf(bounds.outWidth / sample, bounds.outHeight / sample) > maxSide * 2) sample *= 2
            val decoded = BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply {
                inSampleSize = sample; inPreferredConfig = Bitmap.Config.RGB_565
            }) ?: return null
            val ratio = minOf(1f, maxSide.toFloat() / maxOf(decoded.width, decoded.height))
            val thumb = if (ratio < 1f) Bitmap.createScaledBitmap(decoded,
                (decoded.width * ratio).toInt().coerceAtLeast(1), (decoded.height * ratio).toInt().coerceAtLeast(1), true)
                else decoded
            if (thumb !== decoded) decoded.recycle()
            cache.put(key, thumb)
            thumb.copy(thumb.config ?: Bitmap.Config.RGB_565, false)
        } catch (_: Exception) { null }
    }

    @Synchronized fun clear() = cache.evictAll()
    @Synchronized fun setMaxBytes(bytes: Int) { cache.resize(bytes.coerceAtLeast(1)) }
}
