package com.mrk.filerag.index

import com.mrk.filerag.data.Status

data class FileState(val mtime: Long, val size: Long, val status: Int, val attempts: Int)

object ChangeDetection {
    /** True when a file is new, changed, or failed before and still has retries left. */
    fun needsWork(state: FileState?, mtime: Long, size: Long, maxAttempts: Int): Boolean {
        if (state == null) return true
        if (state.mtime != mtime || state.size != size) return true
        return state.status == Status.FAILED && state.attempts < maxAttempts
    }
}
