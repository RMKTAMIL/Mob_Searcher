package com.mrk.filerag.index

import java.io.File
import java.io.RandomAccessFile
import java.security.MessageDigest

/**
 * Cheap content fingerprint: SHA-1 over size + first 64 KB + last 64 KB.
 * Used to reuse extraction/embedding results for duplicate files. Two different files with the same size and
 * identical first/last 64 KB would collide; this is acceptable for personal photo/document collections.
 */
object Fingerprint {
    private const val CHUNK = 64 * 1024

    fun of(file: File, size: Long): String {
        val md = MessageDigest.getInstance("SHA-1")
        md.update(size.toString().toByteArray())
        RandomAccessFile(file, "r").use { raf ->
            val buf = ByteArray(CHUNK)
            val n1 = raf.read(buf)
            if (n1 > 0) md.update(buf, 0, n1)
            raf.seek(maxOf(0L, size - CHUNK))
            val n2 = raf.read(buf)
            if (n2 > 0) md.update(buf, 0, n2)
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
