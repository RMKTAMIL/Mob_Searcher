package com.mrk.filerag.index

import com.mrk.filerag.extract.FileKind

data class IndexOptions(
    val workers: Int = 2,
    val labels: Boolean = true,
    val ocr: Boolean = true,
    val docs: Boolean = true,
    val text: Boolean = true,
    val batchSize: Int = 20
) {
    /** Whether content extraction runs for [kind]. File names are always indexed. */
    fun enabled(kind: FileKind): Boolean = when (kind) {
        FileKind.IMAGE -> true // metadata always; labels/OCR are governed by their own switches
        FileKind.TEXT -> text
        FileKind.OTHER -> false
        else -> docs
    }
}
