package com.mrk.filerag.index

import android.content.Context
import androidx.work.Constraints
import androidx.work.Data
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.OutOfQuotaPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

/**
 * WorkManager schedules the work, but Android may delay, stop or kill it (battery, Doze, process death).
 * Indexing is therefore designed to be resumable rather than assumed to run uninterrupted.
 */
object IndexScheduler {
    const val NOW = "index_now"
    const val PERIODIC = "index_periodic"
    const val KEY_MODE = "mode"
    const val MODE_ALL = "all"
    const val MODE_EMBED = "embed"

    /** Unique name of the single pending "continue after a power pause" job. */
    const val RESUME = "index_resume"
    const val KEY_IS_RESUME = "is_resume"
    const val KEY_IDLE_PAUSES = "idle_pauses"

    fun start(ctx: Context, mode: String = MODE_ALL) {
        val req = OneTimeWorkRequestBuilder<IndexWorker>()
            .setInputData(Data.Builder().putString(KEY_MODE, mode).build())
            .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork(NOW, ExistingWorkPolicy.KEEP, req)
    }

    fun stop(ctx: Context) {
        val wm = WorkManager.getInstance(ctx)
        wm.cancelUniqueWork(NOW)
        wm.cancelUniqueWork(RESUME)
    }

    /**
     * Queues the semantic-only continuation of a run that paused for power/thermal reasons. WorkManager persists it, so it
     * survives process death and reboot; its constraints keep it from starting on battery when charging is required.
     * One unique name means at most one pending resume. From inside the running resume job the new request is chained
     * after it (REPLACE would cancel the job that is scheduling it); from anywhere else it replaces a stale pending one.
     */
    fun scheduleResume(ctx: Context, plan: ResumePlan, fromResumeJob: Boolean) {
        val constraints = Constraints.Builder()
            .setRequiresBatteryNotLow(true)
            .setRequiresCharging(plan.requiresCharging)
            .build()
        val req = OneTimeWorkRequestBuilder<IndexWorker>()
            .setInputData(
                Data.Builder()
                    .putString(KEY_MODE, MODE_EMBED)
                    .putBoolean(KEY_IS_RESUME, true)
                    .putInt(KEY_IDLE_PAUSES, plan.idlePauses)
                    .build()
            )
            .setConstraints(constraints)
            .setInitialDelay(plan.delayMinutes, TimeUnit.MINUTES)
            .build()
        val policy = if (fromResumeJob) ExistingWorkPolicy.APPEND_OR_REPLACE else ExistingWorkPolicy.REPLACE
        WorkManager.getInstance(ctx).enqueueUniqueWork(RESUME, policy, req)
    }

    fun setPeriodic(ctx: Context, enabled: Boolean) {
        val wm = WorkManager.getInstance(ctx)
        if (!enabled) {
            wm.cancelUniqueWork(PERIODIC)
            return
        }
        val req = PeriodicWorkRequestBuilder<IndexWorker>(12, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiresBatteryNotLow(true).setRequiresCharging(true).build())
            .build()
        wm.enqueueUniquePeriodicWork(PERIODIC, ExistingPeriodicWorkPolicy.UPDATE, req)
    }
}
