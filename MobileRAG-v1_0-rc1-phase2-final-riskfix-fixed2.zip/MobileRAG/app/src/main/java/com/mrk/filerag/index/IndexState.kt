package com.mrk.filerag.index

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.sync.Mutex

data class IndexProgress(
    val scanned: Int = 0,
    val indexed: Int = 0,
    val failed: Int = 0,
    val skipped: Int = 0,
    val reused: Int = 0,
    val current: String = ""
)

data class IndexStats(
    val scanned: Int,
    val indexed: Int,
    val unchanged: Int,
    val failed: Int,
    val skipped: Int,
    val reused: Int,
    val empty: Int,
    val inaccessible: Int,
    val removed: Int
) {
    fun summary(): String =
        "scanned $scanned, new/changed $indexed, unchanged $unchanged, failed $failed, skipped $skipped, " +
            "reused $reused, removed $removed"
}

data class IndexUi(
    val running: Boolean = false,
    val phase: String = "",
    val progress: IndexProgress = IndexProgress(),
    val message: String = ""
)

/** Process-wide view of the running index job, plus a lock so only one indexing job runs at a time. */
object IndexState {
    val ui = MutableStateFlow(IndexUi())
    val lock = Mutex()
}
