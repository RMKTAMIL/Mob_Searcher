package com.mrk.filerag.index

import android.content.Context
import android.os.Environment
import android.os.SystemClock
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import com.mrk.filerag.AppContainer
import com.mrk.filerag.files.hasAccess
import com.mrk.filerag.power.PowerDecision
import com.mrk.filerag.semantic.EmbedProgress
import com.mrk.filerag.semantic.EmbedState
import com.mrk.filerag.semantic.SemanticIndexer
import kotlinx.coroutines.CancellationException
import java.io.File

class IndexWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun getForegroundInfo(): ForegroundInfo = Notifier.foreground(applicationContext, "Indexing files")

    override suspend fun doWork(): Result {
        val app = applicationContext
        if (!hasAccess(app)) {
            IndexState.ui.value = IndexUi(message = "Storage access is not granted")
            return Result.failure()
        }
        if (!IndexState.lock.tryLock()) return Result.success() // another run is active
        val c = AppContainer.get(app)
        val prefs = c.prefs
        val mode = inputData.getString(IndexScheduler.KEY_MODE) ?: IndexScheduler.MODE_ALL
        val isResume = inputData.getBoolean(IndexScheduler.KEY_IS_RESUME, false)
        val idlePauses = inputData.getInt(IndexScheduler.KEY_IDLE_PAUSES, 0)
        var powerPause: PowerDecision.Pause? = null
        var madeProgress = false
        try {
            try {
                setForeground(getForegroundInfo())
            } catch (e: Exception) {
                // Android 12+ can refuse foreground promotion from the background; the job still runs, with limits.
                Log.w(TAG, "foreground not allowed: " + e.javaClass.simpleName)
            }
            prefs.runInProgress = true
            prefs.lastRunStart = System.currentTimeMillis()
            var summary = ""

            if (mode == IndexScheduler.MODE_ALL) {
                val roots = prefs.folders().map { File(it) }.ifEmpty { listOf(Environment.getExternalStorageDirectory()) }
                IndexState.ui.value = IndexUi(running = true, phase = "Indexing files")
                var lastNotify = 0L
                val stats = Indexer(app, c.repo).run(roots, prefs.indexOptions()) { p ->
                    IndexState.ui.value = IndexUi(running = true, phase = "Indexing files", progress = p)
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastNotify > 3000) {
                        lastNotify = now
                        setForegroundAsync(Notifier.foreground(app, "Indexed ${p.indexed + p.failed + p.skipped} files"))
                    }
                }
                summary = stats.summary()
            }

            if (prefs.semanticEnabled) {
                IndexState.ui.value = IndexUi(running = true, phase = "Semantic indexing")
                val sem = SemanticIndexer(app, c.repo, c.embeddings, c.models, c.power)
                val s = sem.run { p ->
                    EmbedState.ui.value = p
                    IndexState.ui.value = IndexUi(running = true, phase = "Semantic indexing", message = "${p.done}/${p.total}")
                }
                summary = listOf(summary, "semantic: $s").filter { it.isNotBlank() }.joinToString("; ")
                powerPause = sem.powerPause
                madeProgress = sem.madeProgress
            }

            prefs.lastRunEnd = System.currentTimeMillis()
            prefs.lastSummary = summary
            prefs.runInProgress = false
            val pause = powerPause
            if (pause == null) {
                IndexState.ui.value = IndexUi(running = false, message = "Done: $summary")
            } else {
                // A deliberate stop at a batch boundary: everything finished is committed, so the run is not "interrupted".
                val plan = ResumePlanner.plan(pause, madeProgress, idlePauses, prefs.semanticOnlyCharging)
                if (plan != null) {
                    IndexScheduler.scheduleResume(app, plan, isResume)
                    IndexState.ui.value = IndexUi(running = false, message = "Paused: ${pause.message}. Semantic indexing resumes automatically.")
                } else {
                    IndexState.ui.value = IndexUi(running = false, message = "Paused: ${pause.message}. Tap Semantic only to continue.")
                }
            }
            EmbedState.ui.value = EmbedProgress()
            return Result.success()
        } catch (e: CancellationException) {
            IndexState.ui.value = IndexUi(running = false, message = "Stopped. Progress is saved; the next run resumes.")
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "index run failed: " + e.javaClass.simpleName, e)
            IndexState.ui.value = IndexUi(running = false, message = "Index failed: " + e.javaClass.simpleName)
            return if (runAttemptCount < 3) Result.retry() else Result.failure()
        } finally {
            IndexState.lock.unlock()
        }
    }

    companion object {
        private const val TAG = "IndexWorker"
    }
}
