package com.mrk.filerag.index

import android.content.Context
import android.util.Log
import com.mrk.filerag.data.FileJob
import com.mrk.filerag.data.IndexRepository
import com.mrk.filerag.data.IndexedItem
import com.mrk.filerag.data.Status
import com.mrk.filerag.extract.ExtractContext
import com.mrk.filerag.extract.ExtractResult
import com.mrk.filerag.extract.Extracted
import com.mrk.filerag.extract.Extractors
import com.mrk.filerag.extract.FileKind
import com.mrk.filerag.extract.FileTypes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.ReceiveChannel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.util.concurrent.atomic.AtomicInteger

/**
 * Incremental, cancellable, bounded-concurrency indexing pipeline:
 *   producer (walk + change detection) -> N extraction workers -> single batching writer.
 * Completed batches are committed, so an interrupted run resumes by simply running again.
 */
class Indexer(private val ctx: Context, private val repo: IndexRepository) {

    companion object {
        private const val TAG = "Indexer"
        const val MAX_ATTEMPTS = 3
        private const val QUEUE = 64
    }

    private class Counters {
        val scanned = AtomicInteger()
        val unchanged = AtomicInteger()
        val empty = AtomicInteger()
        val inaccessible = AtomicInteger()
        val indexed = AtomicInteger()
        val failed = AtomicInteger()
        val skipped = AtomicInteger()
        val reused = AtomicInteger()
    }

    suspend fun run(roots: List<File>, opts: IndexOptions, onProgress: (IndexProgress) -> Unit): IndexStats = coroutineScope {
        val c = Counters()
        val ectx = ExtractContext(ctx, opts)
        val work = Channel<FileJob>(QUEUE)
        val results = Channel<IndexedItem>(QUEUE)

        val producer = launch(Dispatchers.IO) {
            try { produce(roots, work, c) } finally { work.close() }
        }
        val workers = List(opts.workers.coerceIn(1, 4)) {
            launch(Dispatchers.Default) { for (job in work) results.send(process(job, ectx, opts)) }
        }
        val writer = launch(Dispatchers.IO) { write(results, opts, c, onProgress) }

        workers.joinAll()
        results.close()
        writer.join()
        producer.join()

        var removed = 0
        if (isActive) {
            removed = repo.removeMissing() + repo.pruneOutside(roots.map { it.path })
            if (c.indexed.get() >= 500) repo.optimize()
        }
        IndexStats(
            c.scanned.get(), c.indexed.get(), c.unchanged.get(), c.failed.get(), c.skipped.get(),
            c.reused.get(), c.empty.get(), c.inaccessible.get(), removed
        )
    }

    private suspend fun produce(roots: List<File>, work: Channel<FileJob>, c: Counters) {
        for (root in roots) {
            if (!root.isDirectory) {
                Log.w(TAG, "root is not a readable directory")
                c.inaccessible.incrementAndGet()
                continue
            }
            val walker = root.walkTopDown()
                .onEnter { d -> d == root || (!d.name.startsWith(".") && !(d.parentFile == root && d.name == "Android")) }
                .onFail { _, e ->
                    c.inaccessible.incrementAndGet()
                    Log.w(TAG, "cannot read directory: " + e.javaClass.simpleName)
                }
            for (f in walker) {
                currentCoroutineContext().ensureActive()
                if (!f.isFile || f.name.startsWith(".")) continue
                c.scanned.incrementAndGet()
                val size = f.length()
                if (size == 0L) { c.empty.incrementAndGet(); continue }
                val mtime = f.lastModified()
                if (!ChangeDetection.needsWork(repo.stateOf(f.path), mtime, size, MAX_ATTEMPTS)) {
                    c.unchanged.incrementAndGet()
                    continue
                }
                work.send(FileJob(f, f.path, mtime, size))
            }
        }
    }

    private fun process(job: FileJob, ectx: ExtractContext, opts: IndexOptions): IndexedItem {
        val ext = job.file.extension.lowercase()
        val kind = FileTypes.kindOf(ext)
        val mime = FileTypes.mimeOf(ext)
        var fp: String? = null
        if (kind != FileKind.OTHER && opts.enabled(kind)) {
            fp = try {
                Fingerprint.of(job.file, job.size)
            } catch (e: IOException) {
                Log.w(TAG, "fingerprint failed: " + e.javaClass.simpleName)
                null
            }
            if (fp != null) {
                val cached = repo.findReusable(fp, job.path)
                if (cached != null) return IndexedItem(job, mime, Status.OK, null, cached, fp, reused = true)
            }
        }
        return when (val r = Extractors.extract(job.file, ext, ectx)) {
            is ExtractResult.Ok -> IndexedItem(job, mime, Status.OK, null, r.data, fp)
            is ExtractResult.Skipped -> IndexedItem(job, mime, Status.SKIPPED, r.reason, Extracted(), fp)
            is ExtractResult.Failed -> IndexedItem(job, mime, Status.FAILED, r.message, Extracted(), fp)
        }
    }

    private suspend fun write(
        results: ReceiveChannel<IndexedItem>,
        opts: IndexOptions,
        c: Counters,
        onProgress: (IndexProgress) -> Unit
    ) {
        val batch = ArrayList<IndexedItem>(opts.batchSize)
        suspend fun flush() {
            if (batch.isEmpty()) return
            val copy = ArrayList(batch)
            batch.clear()
            // Finished extraction work is committed even if the job is being cancelled.
            withContext(NonCancellable) { repo.writeBatch(copy) }
            for (i in copy) {
                when {
                    i.status == Status.FAILED -> c.failed.incrementAndGet()
                    i.status == Status.SKIPPED -> c.skipped.incrementAndGet()
                    else -> c.indexed.incrementAndGet()
                }
                if (i.reused) c.reused.incrementAndGet()
            }
            onProgress(
                IndexProgress(c.scanned.get(), c.indexed.get(), c.failed.get(), c.skipped.get(), c.reused.get(), copy.last().job.file.name)
            )
        }
        try {
            for (first in results) {
                batch.add(first)
                while (batch.size < opts.batchSize) {
                    val next = results.tryReceive().getOrNull() ?: break
                    batch.add(next)
                }
                flush()
            }
        } finally {
            if (batch.isNotEmpty()) flush()
        }
    }
}
