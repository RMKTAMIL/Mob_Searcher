package com.mrk.filerag.index

import com.mrk.filerag.power.PauseReason
import com.mrk.filerag.power.PowerDecision

/** How a power pause is continued: WorkManager constraints plus a bounded wait. Pure logic, unit-tested on the JVM. */
data class ResumePlan(val requiresCharging: Boolean, val delayMinutes: Long, val idlePauses: Int)

object ResumePlanner {
    /** Consecutive pauses without any progress after which automatic resuming stops (bounded, no endless polling). */
    const val MAX_IDLE_PAUSES = 6

    private val BACKOFF_MINUTES = longArrayOf(15, 30, 60)

    /**
     * Returns null when automatic resuming should stop; the work stays resumable from the database and the next
     * manual or periodic run continues it.
     *
     * @param madeProgress whether the run that paused finished at least one file
     * @param previousIdlePauses consecutive no-progress pauses before this one
     * @param chargingRequired the charging-only preference, so thermal/battery waits also keep the charger constraint
     */
    fun plan(pause: PowerDecision.Pause, madeProgress: Boolean, previousIdlePauses: Int, chargingRequired: Boolean): ResumePlan? {
        val idle = if (madeProgress) 0 else previousIdlePauses.coerceAtLeast(0) + 1
        if (idle > MAX_IDLE_PAUSES) return null
        val needsCharger = chargingRequired || pause.reason == PauseReason.NOT_CHARGING
        // Waiting for the charger is expressed as a constraint (no polling); other pauses wait with a growing delay.
        val delay = if (pause.reason == PauseReason.NOT_CHARGING) 0L else BACKOFF_MINUTES[minOf(idle - 1, BACKOFF_MINUTES.size - 1).coerceAtLeast(0)]
        return ResumePlan(needsCharger, delay, idle)
    }
}
