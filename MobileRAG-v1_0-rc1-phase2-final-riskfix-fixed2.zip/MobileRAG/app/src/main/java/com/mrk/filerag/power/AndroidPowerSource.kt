package com.mrk.filerag.power

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager

/** Reads the sticky battery broadcast and (API 29+) the OS thermal status. Needs no permission and no network. */
class AndroidPowerSource(private val ctx: Context) : PowerSource {
    override fun snapshot(): PowerSnapshot {
        val i: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val charging = i?.let { it.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0 }
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val percent = if (level >= 0 && scale > 0) (level * 100) / scale else null
        return PowerSnapshot(charging, percent, thermal())
    }

    private fun thermal(): ThermalLevel {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return ThermalLevel.UNKNOWN
        return try {
            val pm = ctx.getSystemService(PowerManager::class.java) ?: return ThermalLevel.UNKNOWN
            ThermalLevel.fromAndroidStatus(pm.currentThermalStatus)
        } catch (e: Exception) {
            ThermalLevel.UNKNOWN
        }
    }
}
