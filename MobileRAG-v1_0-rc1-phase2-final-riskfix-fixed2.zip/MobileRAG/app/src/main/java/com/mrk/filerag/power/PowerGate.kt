package com.mrk.filerag.power

import kotlinx.coroutines.delay

/** Source of device readings; faked in tests, [AndroidPowerSource] on a phone. No Android imports in this file. */
interface PowerSource {
    fun snapshot(): PowerSnapshot
}

/**
 * Asks "may another batch start?". Callers check between batches only, so a batch that is already running is never
 * interrupted by the gate. The configuration is read on every call, so a changed preference applies to the next batch.
 */
class PowerGate(
    private val source: PowerSource,
    private val config: () -> PowerConfig,
    private val sleep: suspend (Long) -> Unit = { delay(it) }
) {
    fun check(): PowerDecision = PowerPolicy.evaluate(source.snapshot(), config())

    /**
     * Evaluates the conditions, and when the thermal action is THROTTLE waits (cancellably) and re-evaluates once,
     * because charger or temperature may have changed during the wait.
     */
    suspend fun beforeBatch(): PowerDecision {
        val first = check()
        if (first !is PowerDecision.Proceed || first.throttleMs <= 0L) return first
        sleep(first.throttleMs)
        val second = check()
        return if (second is PowerDecision.Proceed) second.copy(throttleMs = 0L) else second
    }
}
