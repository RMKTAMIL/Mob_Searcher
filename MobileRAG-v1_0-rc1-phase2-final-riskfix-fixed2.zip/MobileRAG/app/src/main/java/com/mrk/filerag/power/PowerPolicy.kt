package com.mrk.filerag.power

/**
 * Pure decision logic for power-aware indexing. No Android imports on purpose: everything the policy needs arrives in a
 * [PowerSnapshot], so every branch can be unit-tested on the JVM with plain values.
 */

/** Coarse thermal state. [UNKNOWN] means "no usable reading"; it is never treated as a measured safe temperature. */
enum class ThermalLevel {
    NORMAL, MODERATE, SEVERE, CRITICAL, UNKNOWN;

    companion object {
        /**
         * Maps android.os.PowerManager THERMAL_STATUS_* (0 NONE, 1 LIGHT, 2 MODERATE, 3 SEVERE, 4 CRITICAL,
         * 5 EMERGENCY, 6 SHUTDOWN). A missing or out-of-range value maps to [UNKNOWN], never to [NORMAL].
         */
        fun fromAndroidStatus(status: Int?): ThermalLevel = when (status) {
            0, 1 -> NORMAL
            2 -> MODERATE
            3 -> SEVERE
            4, 5, 6 -> CRITICAL
            else -> UNKNOWN
        }
    }
}

enum class ThermalAction { CONTINUE, THROTTLE, PAUSE }

enum class PauseReason { NOT_CHARGING, BATTERY_LOW, BATTERY_UNKNOWN, THERMAL }

/** One reading of the device. Null means the value could not be read. */
data class PowerSnapshot(val charging: Boolean?, val batteryPercent: Int?, val thermal: ThermalLevel)

data class PowerConfig(
    val requireCharging: Boolean = true,
    /** Lowest battery level (percent) at which a new batch may start while NOT charging. 0 disables the check. */
    val minBatteryPercent: Int = 20,
    val thermal: Map<ThermalLevel, ThermalAction> = DEFAULT_THERMAL,
    /** Pause inserted before a batch when the thermal action is THROTTLE. */
    val throttleMs: Long = 3_000L
) {
    fun actionFor(level: ThermalLevel): ThermalAction = thermal[level] ?: DEFAULT_THERMAL.getValue(level)

    companion object {
        /** UNKNOWN is throttled (not "continue"): missing thermal data is not evidence that the phone is cool. */
        val DEFAULT_THERMAL: Map<ThermalLevel, ThermalAction> = mapOf(
            ThermalLevel.NORMAL to ThermalAction.CONTINUE,
            ThermalLevel.MODERATE to ThermalAction.THROTTLE,
            ThermalLevel.SEVERE to ThermalAction.PAUSE,
            ThermalLevel.CRITICAL to ThermalAction.PAUSE,
            ThermalLevel.UNKNOWN to ThermalAction.THROTTLE
        )
    }
}

sealed class PowerDecision {
    /** A new batch may start after waiting [throttleMs]. [thermal] is carried so callers can report UNKNOWN honestly. */
    data class Proceed(val throttleMs: Long = 0L, val thermal: ThermalLevel = ThermalLevel.NORMAL) : PowerDecision()

    /** No new batch may start. Work already committed is untouched; the run can be resumed later. */
    data class Pause(val reason: PauseReason, val message: String) : PowerDecision()
}

object PowerPolicy {
    fun evaluate(s: PowerSnapshot, cfg: PowerConfig): PowerDecision {
        // An unreadable charging state counts as "not charging": the safe side for a battery-powered device.
        val charging = s.charging == true

        if (cfg.requireCharging && !charging) {
            return PowerDecision.Pause(PauseReason.NOT_CHARGING, "waiting for the charger")
        }

        // The battery floor protects a discharging phone; while charging the level is rising, so it is not enforced.
        if (!charging && cfg.minBatteryPercent > 0) {
            val pct = s.batteryPercent
                ?: return PowerDecision.Pause(PauseReason.BATTERY_UNKNOWN, "battery level unavailable")
            if (pct < cfg.minBatteryPercent) {
                return PowerDecision.Pause(PauseReason.BATTERY_LOW, "battery $pct% is below the ${cfg.minBatteryPercent}% minimum")
            }
        }

        return when (cfg.actionFor(s.thermal)) {
            ThermalAction.PAUSE ->
                PowerDecision.Pause(PauseReason.THERMAL, "device temperature is ${s.thermal.name.lowercase()}")
            ThermalAction.THROTTLE -> PowerDecision.Proceed(cfg.throttleMs, s.thermal)
            ThermalAction.CONTINUE -> PowerDecision.Proceed(0L, s.thermal)
        }
    }
}
