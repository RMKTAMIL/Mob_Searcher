package com.mrk.filerag.search

import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.ln

/** BM25 over SQLite FTS4 matchinfo('pcnalx') output. k1 and b are the standard published defaults. */
object Bm25 {
    const val K1 = 1.2
    const val B = 0.75

    fun decode(blob: ByteArray): IntArray {
        val ib = ByteBuffer.wrap(blob).order(ByteOrder.nativeOrder()).asIntBuffer()
        val out = IntArray(ib.remaining())
        ib.get(out)
        return out
    }

    fun score(info: IntArray, weights: DoubleArray): Double {
        if (info.size < 3) return 0.0
        val p = info[0]
        val c = info[1]
        val n = info[2].toDouble()
        if (c <= 0 || p <= 0 || info.size < 3 + 2 * c + 3 * p * c) return 0.0
        val aOff = 3
        val lOff = 3 + c
        val xOff = 3 + 2 * c
        var s = 0.0
        for (i in 0 until p) {
            for (col in 0 until c) {
                val x = xOff + 3 * (i * c + col)
                val tf = info[x].toDouble()
                if (tf <= 0.0) continue
                val nHit = info[x + 2].toDouble()
                var idf = ln((n - nHit + 0.5) / (nHit + 0.5))
                if (idf <= 0.0) idf = 1e-6
                val avg = info[aOff + col].toDouble().coerceAtLeast(1.0)
                val dl = info[lOff + col].toDouble()
                val w = if (col < weights.size) weights[col] else 1.0
                s += w * idf * (tf * (K1 + 1.0)) / (tf + K1 * (1.0 - B + B * dl / avg))
            }
        }
        return s
    }
}
