package com.mrk.filerag.search

/** Builds SQL fragments for [Filters]. Values that are not numeric constants are bound via [args]. */
object FilterSql {
    private const val BASENAME =
        "lower(substr(files.path, length(rtrim(files.path, replace(files.path, '/', ''))) + 1))"

    fun where(f: Filters, args: MutableList<String>, nowMs: Long = System.currentTimeMillis()): String {
        val sb = StringBuilder()
        if (f.kind.exts.isNotEmpty()) {
            sb.append(" AND (")
            sb.append(f.kind.exts.joinToString(" OR ") { "files.path LIKE '%.$it'" })
            sb.append(")")
        }
        if (f.date.days > 0) {
            sb.append(" AND files.mtime >= ").append(nowMs - f.date.days * 86_400_000L)
        }
        if (f.size.min > 0L) sb.append(" AND files.size >= ").append(f.size.min)
        if (f.size.max != Long.MAX_VALUE) sb.append(" AND files.size < ").append(f.size.max)
        val folder = f.folder
        if (folder != null) {
            val prefix = folder.trimEnd('/') + "/"
            sb.append(" AND substr(files.path, 1, ").append(prefix.length).append(") = ?")
            args.add(prefix)
        }
        val src = f.source
        if (src != null && src.paths.isNotEmpty()) {
            val parts = src.paths.map { p ->
                val prefix = p.trimEnd('/') + "/"
                args.add(prefix)
                "substr(files.path, 1, " + prefix.length + ") = ?"
            }
            sb.append(" AND (").append(parts.joinToString(" OR ")).append(")")
        }
        return sb.toString()
    }

    /** Deterministic order (id tiebreak) so OFFSET paging is stable. */
    fun orderBy(sort: SortBy): String = when (sort) {
        SortBy.OLDEST -> "files.mtime ASC, files.id ASC"
        SortBy.LARGEST -> "files.size DESC, files.id ASC"
        SortBy.NAME -> "$BASENAME ASC, files.id ASC"
        else -> "files.mtime DESC, files.id ASC"
    }
}
