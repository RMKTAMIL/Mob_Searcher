package com.mrk.filerag.search

data class ParsedQuery(val terms: List<String>, val phrases: List<List<String>>) {
    val isEmpty: Boolean get() = terms.isEmpty() && phrases.isEmpty()
}

/** Turns user text into a safe FTS4 MATCH expression. Only letters, digits and combining marks (needed for Indic scripts such as Tamil) survive, so no FTS operators can leak in. */
object QueryParser {
    private val tokenRe = Regex("[\\p{L}\\p{N}\\p{M}]+")
    private val phraseRe = Regex("\"([^\"]*)\"")

    fun parse(raw: String): ParsedQuery {
        val phrases = ArrayList<List<String>>()
        val rest = phraseRe.replace(raw) { m ->
            val toks = tokens(m.groupValues[1])
            if (toks.isNotEmpty()) phrases.add(toks)
            " "
        }
        return ParsedQuery(tokens(rest).distinct(), phrases)
    }

    private fun tokens(s: String): List<String> =
        tokenRe.findAll(s.lowercase()).map { it.value }.filter { it.length >= 2 }.toList()

    fun matchAnd(q: ParsedQuery): String? = build(q, " ")
    fun matchOr(q: ParsedQuery): String? = build(q, " OR ")

    private fun build(q: ParsedQuery, sep: String): String? {
        val parts = ArrayList<String>()
        for (p in q.phrases) parts.add("\"" + p.joinToString(" ") + "\"")
        for (t in q.terms) parts.add("$t*")
        return if (parts.isEmpty()) null else parts.joinToString(sep)
    }

    /** Exact-phrase expression used to rank adjacent-term matches first (only for 2+ plain terms). */
    fun phraseBoost(q: ParsedQuery): String? =
        if (q.phrases.isEmpty() && q.terms.size >= 2) "\"" + q.terms.joinToString(" ") + "\"" else null
}
