package com.mrk.filerag.search

object Ranking {
    /** FTS columns: name, content, labels, ocr. Name hits count double; defaults are conventional and tunable. */
    val COLUMN_WEIGHTS = doubleArrayOf(2.0, 1.0, 1.0, 1.0)

    data class Row(val id: Long, val bm25: Double, val phrase: Boolean, val mtime: Long)

    /** Exact-phrase matches first, then BM25, then recency, then id (deterministic). */
    fun order(rows: List<Row>): List<Row> =
        rows.sortedWith(
            compareByDescending<Row> { it.phrase }
                .thenByDescending { it.bm25 }
                .thenByDescending { it.mtime }
                .thenBy { it.id }
        )
}

/** Reciprocal rank fusion (k=60 is the value from the original RRF paper). Pure and deterministic. */
object Fusion {
    fun rrf(lists: List<List<Long>>, k: Int = 60): List<Long> {
        val score = HashMap<Long, Double>()
        for (list in lists) {
            list.forEachIndexed { rank, id -> score[id] = (score[id] ?: 0.0) + 1.0 / (k + rank + 1) }
        }
        return score.entries
            .sortedWith(compareByDescending<Map.Entry<Long, Double>> { it.value }.thenBy { it.key })
            .map { it.key }
    }
}
