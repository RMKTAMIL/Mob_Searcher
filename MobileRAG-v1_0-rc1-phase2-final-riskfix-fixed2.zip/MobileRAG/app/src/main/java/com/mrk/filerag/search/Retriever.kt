package com.mrk.filerag.search

/** Candidate file ids, best first. [match] is the FTS expression (for snippets) when the retriever is keyword based. */
data class Retrieved(val ids: List<Long>, val truncated: Boolean, val match: String?, val semantic: Boolean = false)

interface Retriever {
    fun retrieve(raw: String, filters: Filters, cap: Int): Retrieved
}
