package com.mrk.filerag.search

import android.database.Cursor
import android.util.Log
import com.mrk.filerag.data.Db
import java.io.File

data class Hit(
    val id: Long,
    val path: String,
    val snippet: String,
    val mtime: Long,
    val size: Long,
    val semantic: Boolean = false
) {
    val name: String get() = File(path).name
}

private val WS = Regex("\\s+")

private fun readHits(c: Cursor, semanticIds: Set<Long> = emptySet()): List<Hit> {
    val out = ArrayList<Hit>()
    while (c.moveToNext()) {
        val id = c.getLong(0)
        out.add(Hit(id, c.getString(1), WS.replace(c.getString(4) ?: "", " ").trim(), c.getLong(2), c.getLong(3), id in semanticIds))
    }
    return out
}

/** FTS4 keyword retrieval with BM25 ranking (matchinfo), exact-phrase boost, AND with OR fallback. */
class KeywordRetriever(private val db: Db) : Retriever {
    override fun retrieve(raw: String, filters: Filters, cap: Int): Retrieved {
        val q = QueryParser.parse(raw)
        val and = QueryParser.matchAnd(q) ?: return Retrieved(emptyList(), false, null)
        var match = and
        var rows = collect(match, filters, cap)
        val or = QueryParser.matchOr(q)
        if (rows.isEmpty() && or != null && or != and) {
            match = or
            rows = collect(match, filters, cap)
        }
        val truncated = rows.size > cap
        if (truncated) rows = rows.subList(0, cap)
        val boostMatch = QueryParser.phraseBoost(q)
        val boosted = if (boostMatch != null && rows.isNotEmpty()) idsOf(boostMatch, filters, cap) else emptySet()
        val ordered = Ranking.order(rows.map { it.copy(phrase = it.id in boosted) })
        return Retrieved(ordered.map { it.id }, truncated, match)
    }

    private fun collect(match: String, f: Filters, cap: Int): List<Ranking.Row> {
        val args = ArrayList<String>()
        args.add(match)
        val sql = "SELECT files.id, files.mtime, matchinfo(docs_fts, 'pcnalx') FROM docs_fts " +
            "JOIN files ON files.id = docs_fts.docid WHERE docs_fts MATCH ?" +
            FilterSql.where(f, args) + " LIMIT " + (cap + 1)
        val out = ArrayList<Ranking.Row>()
        db.readableDatabase.rawQuery(sql, args.toTypedArray()).use { c ->
            while (c.moveToNext()) {
                val info = Bm25.decode(c.getBlob(2))
                out.add(Ranking.Row(c.getLong(0), Bm25.score(info, Ranking.COLUMN_WEIGHTS), false, c.getLong(1)))
            }
        }
        return out
    }

    private fun idsOf(match: String, f: Filters, cap: Int): Set<Long> {
        val args = ArrayList<String>()
        args.add(match)
        val sql = "SELECT files.id FROM docs_fts JOIN files ON files.id = docs_fts.docid WHERE docs_fts MATCH ?" +
            FilterSql.where(f, args) + " LIMIT " + cap
        val out = HashSet<Long>()
        db.readableDatabase.rawQuery(sql, args.toTypedArray()).use { c -> while (c.moveToNext()) out.add(c.getLong(0)) }
        return out
    }
}

/** A paged result list. Pages are loaded lazily, so memory stays flat however many files match. */
abstract class SearchSession {
    abstract val total: Int
    abstract val truncated: Boolean
    abstract val elapsedMs: Long
    abstract fun hasMore(): Boolean
    abstract fun nextPage(): List<Hit>
}

private class EmptySession(t0: Long) : SearchSession() {
    override val total = 0
    override val truncated = false
    override val elapsedMs = (System.nanoTime() - t0) / 1_000_000
    override fun hasMore() = false
    override fun nextPage(): List<Hit> = emptyList()
}

/** SQL-sorted paging (newest/oldest/largest/name, or filter-only browsing). */
private class SqlSession(
    private val db: Db,
    private val match: String?,
    private val f: Filters,
    override val total: Int,
    t0: Long
) : SearchSession() {
    private var offset = 0
    override val truncated = false
    override val elapsedMs = (System.nanoTime() - t0) / 1_000_000
    override fun hasMore() = offset < total

    override fun nextPage(): List<Hit> {
        val args = ArrayList<String>()
        val sql: String
        if (match != null) {
            args.add(match)
            sql = "SELECT files.id, files.path, files.mtime, files.size, snippet(docs_fts, '', '', '…', -1, 14) " +
                "FROM docs_fts JOIN files ON files.id = docs_fts.docid WHERE docs_fts MATCH ?" +
                FilterSql.where(f, args) + " ORDER BY " + FilterSql.orderBy(f.sort) +
                " LIMIT " + SearchEngine.PAGE + " OFFSET " + offset
        } else {
            sql = "SELECT files.id, files.path, files.mtime, files.size, '' FROM files WHERE 1=1" +
                FilterSql.where(f, args) + " ORDER BY " + FilterSql.orderBy(f.sort) +
                " LIMIT " + SearchEngine.PAGE + " OFFSET " + offset
        }
        val hits = db.readableDatabase.rawQuery(sql, args.toTypedArray()).use { readHits(it) }
        offset += SearchEngine.PAGE
        return hits
    }
}

/** Relevance paging: ids are ranked once (cheap longs), details/snippets are loaded per page. */
private class RankedSession(
    private val db: Db,
    private val ids: List<Long>,
    private val match: String?,
    private val semanticOnly: Set<Long>,
    override val truncated: Boolean,
    t0: Long
) : SearchSession() {
    private var offset = 0
    override val total = ids.size
    override val elapsedMs = (System.nanoTime() - t0) / 1_000_000
    override fun hasMore() = offset < ids.size

    override fun nextPage(): List<Hit> {
        val slice = ids.subList(offset, minOf(ids.size, offset + SearchEngine.PAGE))
        offset += slice.size
        if (slice.isEmpty()) return emptyList()
        val idList = slice.joinToString(",")
        val base = HashMap<Long, Hit>()
        db.readableDatabase.rawQuery(
            "SELECT files.id, files.path, files.mtime, files.size, '' FROM files WHERE files.id IN ($idList)", null
        ).use { c -> for (h in readHits(c, semanticOnly)) base[h.id] = h }
        if (match != null) {
            db.readableDatabase.rawQuery(
                "SELECT files.id, files.path, files.mtime, files.size, snippet(docs_fts, '', '', '…', -1, 14) " +
                    "FROM docs_fts JOIN files ON files.id = docs_fts.docid WHERE docs_fts MATCH ? AND files.id IN ($idList)",
                arrayOf(match)
            ).use { c -> for (h in readHits(c, semanticOnly)) base[h.id] = h }
        }
        return slice.mapNotNull { base[it] }
    }
}

class SearchEngine(private val db: Db, private val retrievers: List<Retriever>) {
    companion object {
        const val PAGE = 30
        const val CAP = 20_000
        private const val TAG = "SearchEngine"
    }

    fun start(raw: String, f: Filters): SearchSession {
        val t0 = System.nanoTime()
        val parsed = QueryParser.parse(raw)
        if (parsed.isEmpty) {
            if (!f.isActive) return EmptySession(t0)
            return SqlSession(db, null, f, count(null, f), t0)
        }
        if (f.sort == SortBy.RELEVANCE) {
            // A failing retriever (e.g. semantic model unavailable) must not break keyword search.
            val parts = retrievers.map {
                try {
                    it.retrieve(raw, f, CAP)
                } catch (e: Exception) {
                    Log.w(TAG, "retriever failed: " + e.javaClass.simpleName)
                    Retrieved(emptyList(), false, null)
                }
            }
            val nonEmpty = parts.filter { it.ids.isNotEmpty() }
            val ids = if (nonEmpty.size <= 1) (nonEmpty.firstOrNull()?.ids ?: emptyList())
            else Fusion.rrf(nonEmpty.map { it.ids }).take(CAP)
            val match = parts.firstNotNullOfOrNull { it.match }
            val keywordIds = parts.filter { !it.semantic }.flatMap { it.ids }.toHashSet()
            val semanticOnly = ids.filter { it !in keywordIds }.toHashSet()
            return RankedSession(db, ids, match, semanticOnly, parts.any { it.truncated }, t0)
        }
        // Other sort orders: SQL ORDER BY + paging over keyword matches (semantic retrieval applies to relevance sort).
        val and = QueryParser.matchAnd(parsed)!!
        var match = and
        var total = count(and, f)
        val or = QueryParser.matchOr(parsed)
        if (total == 0 && or != null && or != and) {
            val t2 = count(or, f)
            if (t2 > 0) { match = or; total = t2 }
        }
        return SqlSession(db, match, f, total, t0)
    }

    private fun count(match: String?, f: Filters): Int {
        val args = ArrayList<String>()
        val sql = if (match != null) {
            args.add(match)
            "SELECT COUNT(*) FROM docs_fts JOIN files ON files.id = docs_fts.docid WHERE docs_fts MATCH ?" + FilterSql.where(f, args)
        } else {
            "SELECT COUNT(*) FROM files WHERE 1=1" + FilterSql.where(f, args)
        }
        return db.readableDatabase.rawQuery(sql, args.toTypedArray()).use { if (it.moveToFirst()) it.getInt(0) else 0 }
    }
}
