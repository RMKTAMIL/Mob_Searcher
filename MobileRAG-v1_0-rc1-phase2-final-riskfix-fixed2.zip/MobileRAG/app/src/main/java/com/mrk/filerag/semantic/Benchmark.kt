package com.mrk.filerag.semantic

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Color
import android.os.BatteryManager
import android.os.Build
import android.os.Debug
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * On-device benchmark harness. It MEASURES on the phone it runs on and reports exactly what it measured;
 * nothing here is an assumed or pre-recorded number. Run on a real device (battery section needs it unplugged).
 */
object Benchmark {
    private val sample = ("The quarterly report describes revenue growth across several regions, highlights supply chain delays, " +
        "and lists planned investments in cloud infrastructure, staff training and customer support improvements. ").repeat(6)

    private fun pctl(xs: List<Long>, p: Double): Long = xs.sorted().let { it[((it.size - 1) * p).toInt()] }

    private fun plugged(ctx: Context): Boolean {
        val i: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
    }

    private fun chargeUah(ctx: Context): Long =
        ctx.getSystemService(BatteryManager::class.java).getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)

    fun run(ctx: Context, models: ModelManager, runs: Int = 20): String {
        val sb = StringBuilder()
        sb.append("MobileRAG benchmark ").append(SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())).append('\n')
        sb.append("Device: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.SDK_INT}, ABI ${Build.SUPPORTED_ABIS.firstOrNull()}\n")
        sb.append("Plugged in: ${plugged(ctx)}\n\n")
        models.unloadAll()

        val tm = models.activeTextModel()
        if (tm == null) sb.append("Text model: none selected\n") else {
            val pssBefore = Debug.getPss()
            val t0 = System.nanoTime()
            val ok = models.withText { it.embedQuery("warm up") } != null
            val loadMs = (System.nanoTime() - t0) / 1_000_000
            if (!ok) sb.append("Text model ${tm.manifest.key}: could not load (${models.lastProblem})\n") else {
                val lat = ArrayList<Long>()
                repeat(runs) {
                    val s = System.nanoTime()
                    models.withText { it.embedDocs(listOf(sample)) }
                    lat.add((System.nanoTime() - s) / 1_000_000)
                }
                val pssAfter = Debug.getPss()
                sb.append("Text model ${tm.manifest.key}\n")
                sb.append("  storage: ${tm.bytes / 1_048_576} MB\n  load+first run: $loadMs ms\n")
                sb.append("  ~120-word chunk latency over $runs runs: p50 ${pctl(lat, 0.5)} ms, p95 ${pctl(lat, 0.95)} ms\n")
                sb.append("  process PSS before/after load: ${pssBefore / 1024} MB / ${pssAfter / 1024} MB\n")
            }
        }

        val im = models.activeImageModel()
        if (im == null) sb.append("Image-text model: none selected\n") else {
            val bmp = Bitmap.createBitmap(512, 512, Bitmap.Config.ARGB_8888)
            for (y in 0 until 512 step 8) for (x in 0 until 512 step 8) {
                bmp.setPixel(x, y, Color.rgb(x / 2, y / 2, (x + y) / 4))
            }
            val pssBefore = Debug.getPss()
            val t0 = System.nanoTime()
            val ok = models.withClipImage { it.embed(bmp) } != null
            val loadMs = (System.nanoTime() - t0) / 1_000_000
            if (!ok) sb.append("Image model ${im.manifest.key}: could not load (${models.lastProblem})\n") else {
                val lat = ArrayList<Long>()
                repeat(runs) {
                    val s = System.nanoTime()
                    models.withClipImage { it.embed(bmp) }
                    lat.add((System.nanoTime() - s) / 1_000_000)
                }
                val tl = ArrayList<Long>()
                repeat(runs) {
                    val s = System.nanoTime()
                    models.withClipText { it.embed("a photo of a dog on a beach") }
                    tl.add((System.nanoTime() - s) / 1_000_000)
                }
                sb.append("  image tensor batching (synthetic 512x512 bitmap; not a device-gallery corpus):\\n")
                for (batchSize in listOf(1, 2, 4)) {
                    try {
                        val inputs = List(batchSize) { bmp }
                        models.withClipImage { it.embedBatch(inputs) } // warm-up
                        val samples = ArrayList<Long>()
                        repeat(runs) {
                            val start = System.nanoTime()
                            models.withClipImage { it.embedBatch(inputs) }
                            samples.add((System.nanoTime() - start) / 1_000_000)
                        }
                        sb.append("    batch $batchSize: p50 ${pctl(samples, 0.5)} ms, p95 ${pctl(samples, 0.95)} ms; ${batchSize * 1000L / samples.average().coerceAtLeast(1.0)} images/s\\n")
                    } catch (e: Throwable) {
                        sb.append("    batch $batchSize: unavailable (${e.javaClass.simpleName})\\n")
                    }
                }
                val pssAfter = Debug.getPss()
                sb.append("Image-text model ${im.manifest.key}\n")
                sb.append("  storage: ${im.bytes / 1_048_576} MB\n  image tower load+first run: $loadMs ms\n")
                sb.append("  image embed latency over $runs runs: p50 ${pctl(lat, 0.5)} ms, p95 ${pctl(lat, 0.95)} ms\n")
                sb.append("  text-query embed latency: p50 ${pctl(tl, 0.5)} ms, p95 ${pctl(tl, 0.95)} ms\n")
                sb.append("  process PSS before/after load: ${pssBefore / 1024} MB / ${pssAfter / 1024} MB\n")
            }
            bmp.recycle()
        }
        sb.append("\\nNot measured by this harness: provider cross-comparison (only configured provider), full indexing throughput, end-to-end search latency, and real gallery image corpus. Peak process PSS is sampled around model load; it is not a peak-memory profiler. Unsupported providers must be selected and benchmarked in separate runs.\\n")

        // Battery: continuous embedding for a fixed time, measured with the fuel-gauge charge counter.
        if (plugged(ctx)) {
            sb.append("\nBattery: skipped (device is plugged in). Unplug and run again to measure drain.\n")
        } else if (tm != null && models.isLoaded()) {
            val before = chargeUah(ctx)
            val end = System.currentTimeMillis() + 60_000
            var n = 0
            while (System.currentTimeMillis() < end) {
                models.withText { it.embedDocs(listOf(sample)) }
                n++
            }
            val used = before - chargeUah(ctx)
            sb.append("\nBattery: $n text chunks in 60 s used $used uAh (fuel-gauge counter; coarse on many devices)\n")
        }
        models.unloadAll()

        val dir = File(ctx.filesDir, "benchmarks").apply { mkdirs() }
        val f = File(dir, "benchmark-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".txt")
        f.writeText(sb.toString())
        sb.append("\nSaved: ${f.name} (app-private storage)\n")
        return sb.toString()
    }
}
