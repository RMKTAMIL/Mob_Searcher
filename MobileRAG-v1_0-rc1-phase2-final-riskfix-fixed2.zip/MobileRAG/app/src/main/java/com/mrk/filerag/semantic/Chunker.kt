package com.mrk.filerag.semantic

object Chunker {
    private val ws = Regex("\\s+")

    /** Overlapping word windows. Bounded by [maxChunks] so huge documents cannot cause unbounded work. */
    fun chunk(text: String, maxWords: Int = 180, overlap: Int = 30, maxChunks: Int = 24): List<String> {
        require(maxWords > overlap && overlap >= 0)
        val words = ws.split(text.take(80_000)).filter { it.isNotEmpty() }
        if (words.isEmpty()) return emptyList()
        val out = ArrayList<String>()
        var start = 0
        while (start < words.size && out.size < maxChunks) {
            val end = minOf(words.size, start + maxWords)
            out.add(words.subList(start, end).joinToString(" "))
            if (end == words.size) break
            start = end - overlap
        }
        return out
    }
}
