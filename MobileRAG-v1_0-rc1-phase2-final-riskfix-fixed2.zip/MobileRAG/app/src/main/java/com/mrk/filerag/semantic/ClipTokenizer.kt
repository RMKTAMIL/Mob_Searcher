package com.mrk.filerag.semantic

/**
 * CLIP byte-level BPE tokenizer (same algorithm as OpenAI's simple_tokenizer, without the optional ftfy/html cleanup).
 * [vocab] is vocab.json (token -> id); [merges] are the merge pairs from merges.txt in rank order.
 */
class ClipTokenizer(
    private val vocab: Map<String, Int>,
    merges: List<Pair<String, String>>,
    val contextLen: Int = 77
) {
    private val ranks: Map<Pair<String, String>, Int> = merges.withIndex().associate { it.value to it.index }
    private val byteEncoder: Map<Int, Char> = bytesToUnicode()
    private val cache = HashMap<String, List<String>>()
    private val pat = Regex(
        "<\\|startoftext\\|>|<\\|endoftext\\|>|'s|'t|'re|'ve|'m|'ll|'d|[\\p{L}]+|[\\p{N}]|[^\\s\\p{L}\\p{N}]+",
        RegexOption.IGNORE_CASE
    )
    private val ws = Regex("\\s+")
    private val sot = vocab["<|startoftext|>"] ?: 49406
    val eot = vocab["<|endoftext|>"] ?: 49407

    fun encode(text: String): LongArray {
        val clean = ws.replace(text, " ").trim().lowercase()
        val ids = ArrayList<Int>()
        ids.add(sot)
        for (m in pat.findAll(clean)) {
            val mapped = m.value.toByteArray(Charsets.UTF_8).joinToString("") { byteEncoder[it.toInt() and 0xFF].toString() }
            for (piece in bpe(mapped)) {
                val id = vocab[piece]
                if (id != null) ids.add(id)
            }
        }
        val body = if (ids.size > contextLen - 1) ids.subList(0, contextLen - 1) else ids
        val out = LongArray(contextLen) // zero padded
        for (i in body.indices) out[i] = body[i].toLong()
        out[body.size] = eot.toLong()
        return out
    }

    private fun bpe(token: String): List<String> {
        cache[token]?.let { return it }
        if (token.isEmpty()) return emptyList()
        var word: List<String> = token.map { it.toString() }.toMutableList().also {
            it[it.size - 1] = it[it.size - 1] + "</w>"
        }
        while (word.size > 1) {
            var best: Pair<String, String>? = null
            var bestRank = Int.MAX_VALUE
            for (i in 0 until word.size - 1) {
                val r = ranks[Pair(word[i], word[i + 1])]
                if (r != null && r < bestRank) { bestRank = r; best = Pair(word[i], word[i + 1]) }
            }
            val b = best ?: break
            val next = ArrayList<String>()
            var i = 0
            while (i < word.size) {
                if (i < word.size - 1 && word[i] == b.first && word[i + 1] == b.second) {
                    next.add(b.first + b.second)
                    i += 2
                } else {
                    next.add(word[i])
                    i += 1
                }
            }
            word = next
        }
        if (cache.size > 20_000) cache.clear()
        cache[token] = word
        return word
    }

    companion object {
        fun parseMerges(text: String): List<Pair<String, String>> =
            text.lineSequence()
                .filter { it.isNotBlank() && !it.startsWith("#version") }
                .mapNotNull { line ->
                    val p = line.split(' ')
                    if (p.size == 2) Pair(p[0], p[1]) else null
                }
                .toList()

        fun bytesToUnicode(): Map<Int, Char> {
            val bs = ArrayList<Int>()
            for (c in '!'.code..'~'.code) bs.add(c)
            for (c in 0xA1..0xAC) bs.add(c)
            for (c in 0xAE..0xFF) bs.add(c)
            val cs = ArrayList<Int>(bs)
            var n = 0
            for (b in 0 until 256) {
                if (b !in bs) { bs.add(b); cs.add(256 + n); n++ }
            }
            val map = HashMap<Int, Char>()
            for (i in bs.indices) map[bs[i]] = cs[i].toChar()
            return map
        }
    }
}
