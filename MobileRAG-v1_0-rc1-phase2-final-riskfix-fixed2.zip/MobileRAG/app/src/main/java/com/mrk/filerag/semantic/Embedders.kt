package com.mrk.filerag.semantic

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.graphics.Bitmap
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Thin helpers over ONNX Runtime (CPU execution provider only; everything runs inside this process). */
enum class ExecutionProvider { CPU, XNNPACK, NNAPI }

data class OrtRuntimeConfig(
    val provider: ExecutionProvider = ExecutionProvider.CPU,
    val threads: Int = 2
)

object Ort {
    val env: OrtEnvironment by lazy { OrtEnvironment.getEnvironment() }
    @Volatile var lastActivatedProvider: ExecutionProvider = ExecutionProvider.CPU
        private set

    fun session(path: File, config: OrtRuntimeConfig): OrtSession {
        fun create(provider: ExecutionProvider): OrtSession =
            OrtSession.SessionOptions().use { o ->
                o.setIntraOpNumThreads(config.threads.coerceIn(1, 4))
                o.setInterOpNumThreads(1)
                o.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
                if (provider != ExecutionProvider.CPU) {
                    val methodName = if (provider == ExecutionProvider.NNAPI) "addNnapi" else "addXnnpack"
                    val method = o.javaClass.methods.firstOrNull { it.name == methodName }
                        ?: error("$methodName unavailable in this ONNX Runtime")
                    if (method.parameterCount == 0) method.invoke(o)
                    else if (method.parameterCount == 1 && Map::class.java.isAssignableFrom(method.parameterTypes[0]))
                        method.invoke(o, emptyMap<String, String>())
                    else error("Unsupported $methodName signature")
                }
                env.createSession(path.path, o)
            }
        if (config.provider != ExecutionProvider.CPU) {
            try {
                val session = create(config.provider)
                lastActivatedProvider = config.provider
                android.util.Log.i("Ort", "Session provider activated: ${config.provider}")
                return session
            } catch (e: Throwable) {
                android.util.Log.w("Ort", "${config.provider} session unavailable; retrying with CPU", e)
            }
        }
        val cpu = create(ExecutionProvider.CPU)
        lastActivatedProvider = ExecutionProvider.CPU
        android.util.Log.i("Ort", "Session provider activated: CPU")
        return cpu
    }

    /** Backward-compatible overload. */
    fun session(path: File, threads: Int): OrtSession = session(path, OrtRuntimeConfig(threads = threads))
    fun longTensor(rows: Array<LongArray>): OnnxTensor = OnnxTensor.createTensor(env, rows)
    fun outputIndex(session: OrtSession, name: String?): Int =
        if (name == null) 0 else session.outputNames.toList().indexOf(name).coerceAtLeast(0)
}

/** Sentence embeddings (BERT-style tokenizer + mean pooling + L2 normalization), e.g. all-MiniLM-L6-v2. */
class SbertEmbedder(
    private val m: ModelManifest,
    private val session: OrtSession,
    private val tok: WordPieceTokenizer
) : AutoCloseable {

    fun embedQuery(text: String): FloatArray = embedBatch(listOf(m.queryPrefix + text))[0]

    fun embedDocs(texts: List<String>): List<FloatArray> =
        texts.chunked(8).flatMap { part -> embedBatch(part.map { m.docPrefix + it }) }

    private fun embedBatch(texts: List<String>): List<FloatArray> {
        val enc = texts.map { tok.encode(it, m.maxLen) }
        val len = enc.maxOf { it.ids.size }
        val ids = Array(enc.size) { i -> LongArray(len).also { enc[i].ids.copyInto(it) } }
        val mask = Array(enc.size) { i -> LongArray(len).also { enc[i].mask.copyInto(it) } }
        val types = Array(enc.size) { LongArray(len) }
        val names = session.inputNames
        val tensors = ArrayList<OnnxTensor>()
        try {
            val inputs = HashMap<String, OnnxTensor>()
            fun put(name: String, data: Array<LongArray>) {
                if (names.contains(name)) {
                    val t = Ort.longTensor(data)
                    tensors.add(t)
                    inputs[name] = t
                }
            }
            put("input_ids", ids); put("attention_mask", mask); put("token_type_ids", types)
            session.run(inputs).use { res ->
                val value = res.get(Ort.outputIndex(session, m.names["output"])).value as? Array<*>
                    ?: error("unexpected model output")
                return value.mapIndexed { i, row ->
                    val v = when (row) {
                        is FloatArray -> VectorMath.l2Normalize(row)
                        is Array<*> -> {
                            @Suppress("UNCHECKED_CAST")
                            VectorMath.l2Normalize(VectorMath.meanPool(row as Array<FloatArray>, mask[i]))
                        }
                        else -> error("unexpected output row")
                    }
                    check(v.size == m.dim) { "model dim ${v.size} != manifest dim ${m.dim}" }
                    v
                }
            }
        } finally {
            tensors.forEach { it.close() }
        }
    }

    override fun close() = session.close()
}

/** CLIP text tower: text -> shared image/text embedding space. */
class ClipTextEmbedder(
    private val m: ModelManifest,
    private val session: OrtSession,
    private val tok: ClipTokenizer
) : AutoCloseable {
    fun embed(text: String): FloatArray {
        val ids = tok.encode(text)
        val eotAt = ids.indexOfFirst { it == tok.eot.toLong() }.let { if (it < 0) ids.size - 1 else it }
        val mask = LongArray(ids.size) { if (it <= eotAt) 1L else 0L }
        val tensors = ArrayList<OnnxTensor>()
        try {
            val inputs = HashMap<String, OnnxTensor>()
            val t1 = Ort.longTensor(arrayOf(ids)); tensors.add(t1); inputs["input_ids"] = t1
            if (session.inputNames.contains("attention_mask")) {
                val t2 = Ort.longTensor(arrayOf(mask)); tensors.add(t2); inputs["attention_mask"] = t2
            }
            session.run(inputs).use { res ->
                val rows = res.get(Ort.outputIndex(session, m.names["text_output"])).value as? Array<*> ?: error("unexpected output")
                val v = VectorMath.l2Normalize(rows[0] as? FloatArray ?: error("unexpected output row"))
                check(v.size == m.dim) { "model dim ${v.size} != manifest dim ${m.dim}" }
                return v
            }
        } finally {
            tensors.forEach { it.close() }
        }
    }

    override fun close() = session.close()
}

/** CLIP image tower: bitmap -> shared embedding space. Resize/crop/normalize follow the manifest. */
class ClipImageEmbedder(private val m: ModelManifest, private val session: OrtSession) : AutoCloseable {
    private var inputBuffer: java.nio.FloatBuffer? = null
    private var pixelBuffer: IntArray? = null
    fun embed(src: Bitmap): FloatArray = embedBatch(listOf(src)).single()

    /** One real NCHW tensor; outputs remain in the same order as input bitmaps. */
    fun embedBatch(sources: List<Bitmap>): List<FloatArray> {
        require(sources.isNotEmpty())
        val size = m.imageSize
        val plane = size * size
        val count = sources.size
        val floats = count * 3 * plane
        val fb = inputBuffer?.takeIf { it.capacity() >= floats } ?: ByteBuffer
            .allocateDirect(floats * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().also { inputBuffer = it }
        fb.clear()
        val pixels = pixelBuffer?.takeIf { it.size == plane } ?: IntArray(plane).also { pixelBuffer = it }
        sources.forEachIndexed { imageIndex, src ->
            val (rw, rh) = ImagePrep.resizedDims(src.width, src.height, size)
            val scaled = Bitmap.createScaledBitmap(src, rw, rh, true)
            try {
                val (ox, oy) = ImagePrep.centerCropOrigin(rw, rh, size)
                scaled.getPixels(pixels, 0, size, ox, oy, size, size)
                // Write directly into this image's planar NCHW slice.
                val base = imageIndex * 3 * plane
                for (i in 0 until plane) {
                    val px = pixels[i]
                    fb.put(base + i, ((((px shr 16) and 255) / 255f - m.mean[0]) / m.std[0]))
                    fb.put(base + plane + i, ((((px shr 8) and 255) / 255f - m.mean[1]) / m.std[1]))
                    fb.put(base + 2 * plane + i, (((px and 255) / 255f - m.mean[2]) / m.std[2]))
                }
            } finally {
                if (scaled !== src) scaled.recycle()
            }
        }
        fb.limit(floats)
        fb.position(0)
        val inputName = m.names["image_input"] ?: session.inputNames.first()
        OnnxTensor.createTensor(Ort.env, fb, longArrayOf(count.toLong(), 3, size.toLong(), size.toLong())).use { t ->
            session.run(mapOf(inputName to t)).use { res ->
                val rows = res.get(Ort.outputIndex(session, m.names["image_output"])).value as? Array<*>
                    ?: error("unexpected output")
                check(rows.size == count) { "batch output count ${rows.size} != input count $count" }
                return rows.map { row ->
                    val v = VectorMath.l2Normalize(row as? FloatArray ?: error("unexpected output row"))
                    check(v.size == m.dim) { "model dim ${v.size} != manifest dim ${m.dim}" }
                    v
                }
            }
        }
    }

    override fun close() {
        inputBuffer = null
        pixelBuffer = null
        session.close()
    }
}
