package com.mrk.filerag.semantic

import kotlinx.coroutines.CancellationException

/** Pure batching helper; list order is retained so output index i maps to input index i. */
object ImageBatchPlanner {
    fun <T> chunks(items: List<T>, size: Int): List<List<T>> {
        require(size in listOf(1, 2, 4))
        return items.chunked(size)
    }

    /** Ordinary batch failures retry per item. Cancellation and OOM propagate to the owner. */
    fun <T, R> infer(items: List<T>, batch: (List<T>) -> List<R>, single: (T) -> R): List<R> {
        if (items.isEmpty()) return emptyList()
        return try {
            batch(items).also { check(it.size == items.size) { "batch output count mismatch" } }
        } catch (e: CancellationException) {
            throw e
        } catch (e: OutOfMemoryError) {
            throw e
        } catch (_: Exception) {
            items.map(single)
        }
    }
}
