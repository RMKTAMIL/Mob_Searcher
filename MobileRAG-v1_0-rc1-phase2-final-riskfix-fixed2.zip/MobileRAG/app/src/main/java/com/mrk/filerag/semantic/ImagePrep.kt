package com.mrk.filerag.semantic

object ImagePrep {
    /** Size after scaling the shorter side to [target], keeping aspect ratio. */
    fun resizedDims(w: Int, h: Int, target: Int): Pair<Int, Int> =
        if (w <= h) Pair(target, maxOf(target, Math.round(h * target.toFloat() / w)))
        else Pair(maxOf(target, Math.round(w * target.toFloat() / h)), target)

    /** Top-left corner of a centered [size] x [size] crop. */
    fun centerCropOrigin(w: Int, h: Int, size: Int): Pair<Int, Int> = Pair((w - size) / 2, (h - size) / 2)

    /** ARGB pixels (size*size) -> planar CHW floats, (v/255 - mean) / std per channel. */
    fun toChw(pixels: IntArray, size: Int, mean: FloatArray, std: FloatArray): FloatArray {
        val plane = size * size
        val out = FloatArray(3 * plane)
        for (i in 0 until plane) {
            val p = pixels[i]
            val r = ((p shr 16) and 0xFF) / 255f
            val g = ((p shr 8) and 0xFF) / 255f
            val b = (p and 0xFF) / 255f
            out[i] = (r - mean[0]) / std[0]
            out[plane + i] = (g - mean[1]) / std[1]
            out[2 * plane + i] = (b - mean[2]) / std[2]
        }
        return out
    }
}
