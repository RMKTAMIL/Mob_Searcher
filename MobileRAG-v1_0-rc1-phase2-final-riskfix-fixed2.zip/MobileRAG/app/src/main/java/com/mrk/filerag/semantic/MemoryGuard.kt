package com.mrk.filerag.semantic

import android.app.ActivityManager
import android.content.Context

object MemoryGuard {
    /** Refuse to load a model unless free RAM above the system low-memory threshold is 1.5x its estimate. */
    fun canLoad(ctx: Context, needMb: Int): Boolean {
        val am = ctx.getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        if (mi.lowMemory) return false
        return (mi.availMem - mi.threshold) > needMb.toLong() * 1024L * 1024L * 3L / 2L
    }
}
