package com.mrk.filerag.semantic

import android.content.Context
import android.util.Log
import com.mrk.filerag.settings.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Loads models lazily, refuses to load when RAM is short (callers then fall back to keyword search),
 * and unloads them after [IDLE_MS] of inactivity or when the system asks for memory.
 */
class ModelManager(private val ctx: Context, val store: ModelStore, private val prefs: Prefs) {
    companion object {
        private const val TAG = "ModelManager"
        private const val IDLE_MS = 45_000L
    }

    private val lock = Any()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var idleJob: Job? = null
    private var lastUse = 0L

    private var sbert: SbertEmbedder? = null
    private var sbertKey: String? = null
    private var clipText: ClipTextEmbedder? = null
    private var clipTextKey: String? = null
    private var clipImage: ClipImageEmbedder? = null
    private var clipImageKey: String? = null

    @Volatile
    var lastProblem: String? = null
        private set

    fun activeTextModel(): InstalledModel? =
        prefs.activeTextModel?.let { store.find(it) }?.takeIf { it.manifest.kind == "sbert" }

    fun activeImageModel(): InstalledModel? =
        prefs.activeImageModel?.let { store.find(it) }?.takeIf { it.manifest.kind == "clip" }

    fun <T> withText(block: (SbertEmbedder) -> T): T? = synchronized(lock) {
        val e = loadSbert() ?: return@synchronized null
        touch()
        try { block(e) } finally { touch() }
    }

    fun <T> withClipText(block: (ClipTextEmbedder) -> T): T? = synchronized(lock) {
        val e = loadClipText() ?: return@synchronized null
        touch()
        try { block(e) } finally { touch() }
    }

    fun <T> withClipImage(block: (ClipImageEmbedder) -> T): T? = synchronized(lock) {
        val e = loadClipImage() ?: return@synchronized null
        touch()
        try { block(e) } finally { touch() }
    }

    fun unloadAll() = synchronized(lock) { unloadLocked() }

    fun isLoaded(): Boolean = synchronized(lock) { sbert != null || clipText != null || clipImage != null }

    private fun unloadLocked() {
        try { sbert?.close() } catch (e: Exception) { Log.w(TAG, "close: " + e.javaClass.simpleName) }
        try { clipText?.close() } catch (e: Exception) { Log.w(TAG, "close: " + e.javaClass.simpleName) }
        try { clipImage?.close() } catch (e: Exception) { Log.w(TAG, "close: " + e.javaClass.simpleName) }
        sbert = null; sbertKey = null
        clipText = null; clipTextKey = null
        clipImage = null; clipImageKey = null
    }

    private fun touch() {
        lastUse = System.currentTimeMillis()
        idleJob?.cancel()
        idleJob = scope.launch {
            delay(IDLE_MS)
            synchronized(lock) {
                if (System.currentTimeMillis() - lastUse >= IDLE_MS) unloadLocked()
            }
        }
    }

    private fun runtimeConfig() = OrtRuntimeConfig(
        provider = runCatching { ExecutionProvider.valueOf(prefs.executionProvider) }.getOrDefault(ExecutionProvider.CPU),
        threads = prefs.semanticThreads
    )

    private fun admit(m: InstalledModel): Boolean {
        if (!MemoryGuard.canLoad(ctx, m.manifest.approxRamMb)) {
            lastProblem = "Not enough free memory for ${m.manifest.id}; using keyword search only"
            return false
        }
        return true
    }

    private fun loadSbert(): SbertEmbedder? {
        val im = activeTextModel() ?: run { lastProblem = "No text model selected"; return null }
        if (sbert != null && sbertKey == im.manifest.key) return sbert
        sbert?.close(); sbert = null
        if (!admit(im)) return null
        return try {
            val vocab = HashMap<String, Int>()
            store.fileOf(im, "vocab").useLines { lines -> lines.forEachIndexed { i, l -> vocab[l.trimEnd()] = i } }
            val s = Ort.session(store.fileOf(im, "model"), runtimeConfig())
            SbertEmbedder(im.manifest, s, WordPieceTokenizer(vocab, im.manifest.lowercase)).also { sbert = it; sbertKey = im.manifest.key }
        } catch (e: Throwable) {
            lastProblem = "Text model failed to load: " + e.javaClass.simpleName
            Log.w(TAG, lastProblem ?: "")
            null
        }
    }

    private fun clipTokenizer(im: InstalledModel): ClipTokenizer {
        val vocab = org.json.JSONObject(store.fileOf(im, "vocab").readText())
        val map = HashMap<String, Int>(vocab.length() * 2)
        val keys = vocab.keys()
        while (keys.hasNext()) { val k = keys.next(); map[k] = vocab.getInt(k) }
        val merges = ClipTokenizer.parseMerges(store.fileOf(im, "merges").readText())
        return ClipTokenizer(map, merges, im.manifest.contextLen)
    }

    private fun loadClipText(): ClipTextEmbedder? {
        val im = activeImageModel() ?: run { lastProblem = "No image-text model selected"; return null }
        if (clipText != null && clipTextKey == im.manifest.key) return clipText
        clipText?.close(); clipText = null
        if (!admit(im)) return null
        return try {
            val s = Ort.session(store.fileOf(im, "text"), runtimeConfig())
            ClipTextEmbedder(im.manifest, s, clipTokenizer(im)).also { clipText = it; clipTextKey = im.manifest.key }
        } catch (e: Throwable) {
            lastProblem = "CLIP text tower failed to load: " + e.javaClass.simpleName
            Log.w(TAG, lastProblem ?: "")
            null
        }
    }

    private fun loadClipImage(): ClipImageEmbedder? {
        val im = activeImageModel() ?: run { lastProblem = "No image-text model selected"; return null }
        if (clipImage != null && clipImageKey == im.manifest.key) return clipImage
        clipImage?.close(); clipImage = null
        if (!admit(im)) return null
        return try {
            val s = Ort.session(store.fileOf(im, "image"), runtimeConfig())
            ClipImageEmbedder(im.manifest, s).also { clipImage = it; clipImageKey = im.manifest.key }
        } catch (e: Throwable) {
            lastProblem = "CLIP image tower failed to load: " + e.javaClass.simpleName
            Log.w(TAG, lastProblem ?: "")
            null
        }
    }
}
