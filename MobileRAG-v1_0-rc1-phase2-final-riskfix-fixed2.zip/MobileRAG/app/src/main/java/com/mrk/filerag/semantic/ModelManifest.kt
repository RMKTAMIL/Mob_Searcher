package com.mrk.filerag.semantic

import org.json.JSONArray
import org.json.JSONObject

/**
 * Describes one provisioned model pack (a folder with model.json + model files).
 * kind "sbert": sentence embeddings (files: model, vocab).
 * kind "clip": cross-modal image/text embeddings (files: image, text, vocab, merges).
 * Every file must carry a SHA-256 so imports can be verified; see docs/MODELS.md.
 */
class ModelManifest(
    val id: String,
    val version: String,
    val kind: String,
    val dim: Int,
    val files: Map<String, String>,
    val sha256: Map<String, String>,
    val maxLen: Int,
    val lowercase: Boolean,
    val queryPrefix: String,
    val docPrefix: String,
    val minScore: Float,
    val approxRamMb: Int,
    val imageSize: Int,
    val mean: FloatArray,
    val std: FloatArray,
    val contextLen: Int,
    val names: Map<String, String>
) {
    val key: String get() = "$id@$version"

    companion object {
        private val SAFE = Regex("[A-Za-z0-9._-]{1,64}")
        private val HEX = Regex("[0-9a-fA-F]{64}")

        fun parse(json: String): ModelManifest {
            val o = JSONObject(json)
            val id = o.getString("id")
            val version = o.getString("version")
            require(SAFE.matches(id)) { "invalid model id" }
            require(SAFE.matches(version)) { "invalid model version" }
            val kind = o.getString("kind")
            require(kind == "sbert" || kind == "clip") { "unknown kind: $kind" }
            val dim = o.getInt("dim")
            require(dim in 1..4096) { "invalid dim" }

            val files = strMap(o.getJSONObject("files"))
            val required = if (kind == "sbert") listOf("model", "vocab") else listOf("image", "text", "vocab", "merges")
            for (r in required) require(files.containsKey(r)) { "files.$r is required" }
            for ((_, name) in files) {
                require(SAFE.matches(name)) { "unsafe file name: $name" }
            }
            val sha = strMap(o.getJSONObject("sha256"))
            for ((_, name) in files) {
                require(sha[name]?.let { HEX.matches(it) } == true) { "sha256 missing or malformed for $name" }
            }
            return ModelManifest(
                id = id, version = version, kind = kind, dim = dim, files = files, sha256 = sha,
                maxLen = o.optInt("max_len", 128),
                lowercase = o.optBoolean("lowercase", true),
                queryPrefix = o.optString("query_prefix", ""),
                docPrefix = o.optString("doc_prefix", ""),
                minScore = o.optDouble("min_score", if (kind == "clip") 0.18 else 0.25).toFloat(),
                approxRamMb = o.optInt("approx_ram_mb", if (kind == "clip") 400 else 150),
                imageSize = o.optInt("image_size", 224),
                mean = floats(o.optJSONArray("mean"), floatArrayOf(0.48145466f, 0.4578275f, 0.40821073f)),
                std = floats(o.optJSONArray("std"), floatArrayOf(0.26862954f, 0.26130258f, 0.27577711f)),
                contextLen = o.optInt("context_len", 77),
                names = o.optJSONObject("names")?.let { strMap(it) } ?: emptyMap()
            )
        }

        private fun strMap(o: JSONObject): Map<String, String> {
            val m = LinkedHashMap<String, String>()
            val it = o.keys()
            while (it.hasNext()) { val k = it.next(); m[k] = o.getString(k) }
            return m
        }

        private fun floats(a: JSONArray?, def: FloatArray): FloatArray {
            if (a == null || a.length() != 3) return def
            return FloatArray(3) { a.getDouble(it).toFloat() }
        }
    }
}
