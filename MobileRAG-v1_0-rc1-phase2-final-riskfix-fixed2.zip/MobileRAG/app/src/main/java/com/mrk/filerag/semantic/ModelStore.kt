package com.mrk.filerag.semantic

import android.content.Context
import android.util.Log
import java.io.File
import java.security.MessageDigest

data class InstalledModel(val manifest: ModelManifest, val dir: File, val bytes: Long)

sealed class ImportResult {
    data class Ok(val model: InstalledModel) : ImportResult()
    data class Error(val message: String) : ImportResult()
}

/**
 * Model packs live in app-private storage (filesDir/models/<id>@<version>). The app has no INTERNET permission,
 * so packs are provisioned by copying a folder onto the phone and importing it here; every file is SHA-256 verified.
 */
class ModelStore(ctx: Context) {
    private val root = File(ctx.filesDir, "models").apply { mkdirs() }

    fun installed(): List<InstalledModel> =
        (root.listFiles() ?: emptyArray()).filter { it.isDirectory && !it.name.startsWith(".") }.mapNotNull { dir ->
            try {
                val m = ModelManifest.parse(File(dir, "model.json").readText())
                InstalledModel(m, dir, dir.listFiles()?.sumOf { it.length() } ?: 0L)
            } catch (e: Exception) {
                Log.w(TAG, "skipping unreadable model dir: " + e.javaClass.simpleName)
                null
            }
        }.sortedBy { it.manifest.key }

    fun find(key: String): InstalledModel? = installed().firstOrNull { it.manifest.key == key }

    fun fileOf(m: InstalledModel, role: String): File = File(m.dir, m.manifest.files.getValue(role))

    fun import(source: File): ImportResult {
        val manifestFile = File(source, "model.json")
        if (!manifestFile.isFile) return ImportResult.Error("model.json not found in the selected folder")
        val m = try {
            ModelManifest.parse(manifestFile.readText())
        } catch (e: Exception) {
            return ImportResult.Error("Invalid model.json: " + (e.message ?: e.javaClass.simpleName))
        }
        val srcFiles = m.files.values.map { File(source, it) }
        val missing = srcFiles.firstOrNull { !it.isFile }
        if (missing != null) return ImportResult.Error("Missing file: ${missing.name}")
        val need = srcFiles.sumOf { it.length() }
        if (root.usableSpace < need + need / 10) return ImportResult.Error("Not enough free storage (need ${need / 1_048_576} MB)")

        val tmp = File(root, ".tmp-${m.key}").apply { deleteRecursively(); mkdirs() }
        try {
            for (f in srcFiles) f.copyTo(File(tmp, f.name), overwrite = true)
            manifestFile.copyTo(File(tmp, "model.json"), overwrite = true)
            for ((_, name) in m.files) {
                val actual = sha256(File(tmp, name))
                if (!actual.equals(m.sha256.getValue(name), ignoreCase = true)) {
                    tmp.deleteRecursively()
                    return ImportResult.Error("SHA-256 mismatch for $name (file corrupted or not the expected one)")
                }
            }
            val dst = File(root, m.key)
            dst.deleteRecursively()
            if (!tmp.renameTo(dst)) {
                tmp.deleteRecursively()
                return ImportResult.Error("Could not finalize import")
            }
            return ImportResult.Ok(InstalledModel(m, dst, dst.listFiles()?.sumOf { it.length() } ?: 0L))
        } catch (e: Exception) {
            tmp.deleteRecursively()
            Log.w(TAG, "import failed: " + e.javaClass.simpleName)
            return ImportResult.Error("Import failed: " + e.javaClass.simpleName)
        }
    }

    /** Re-hashes installed files. Returns a list of problems (empty = all good). */
    fun verify(m: InstalledModel): List<String> {
        val problems = ArrayList<String>()
        for ((_, name) in m.manifest.files) {
            val f = File(m.dir, name)
            if (!f.isFile) problems.add("missing $name")
            else if (!sha256(f).equals(m.manifest.sha256.getValue(name), ignoreCase = true)) problems.add("hash mismatch $name")
        }
        return problems
    }

    fun remove(key: String) {
        File(root, key).deleteRecursively()
    }

    private fun sha256(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { s ->
            val buf = ByteArray(1 shl 20)
            while (true) {
                val n = s.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    companion object {
        private const val TAG = "ModelStore"
    }
}
