package com.mrk.filerag.semantic

import android.content.Context
import android.util.Log
import com.mrk.filerag.data.EmbeddingRepository
import com.mrk.filerag.data.IndexRepository
import com.mrk.filerag.extract.BitmapUtil
import com.mrk.filerag.power.PowerDecision
import com.mrk.filerag.power.PowerGate
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow

data class EmbedProgress(val phase: String = "", val done: Int = 0, val total: Int = 0, val message: String = "")

object EmbedState {
    val ui = MutableStateFlow(EmbedProgress())
}

/**
 * Resumable embedding pass. Work is derived from the database ("files without a finished embed_state row for the
 * active model key"), so after an interruption or a model version change it simply continues/re-embeds.
 * Identical files reuse vectors via their fingerprint. Models are unloaded when the pass ends.
 *
 * With a [gate], power/thermal conditions are checked before every batch (and so before the first model load). An unsafe
 * state stops the pass at that batch boundary; every finished file is already committed, so nothing is lost, and
 * [powerPause] tells the caller why it stopped. Without a gate the behaviour is unchanged.
 */
class SemanticIndexer(
    private val ctx: Context,
    private val repo: IndexRepository,
    private val emb: EmbeddingRepository,
    private val models: ModelManager,
    private val gate: PowerGate? = null
) {
    companion object {
        private const val TAG = "SemanticIndexer"
        private const val BATCH = 25
    }

    private var done = 0
    private var failed = 0
    private var reused = 0
    private var emptyDone = 0 // files with no embeddable text, recorded as finished

    /** Set when the pass stopped because power/thermal conditions were unsafe. */
    var powerPause: PowerDecision.Pause? = null
        private set

    /** True when at least one file was embedded, reused, recorded as finished-empty or as failed in this pass. */
    val madeProgress: Boolean get() = done + reused + failed + emptyDone > 0

    /** Checks the gate before a batch starts (may wait when throttling). True means: do not start another batch. */
    private suspend fun gatePaused(): Boolean {
        val d = gate?.beforeBatch() ?: return false
        if (d is PowerDecision.Pause) {
            powerPause = d
            return true
        }
        return false
    }

    /** Returns a short summary. Pauses (without failing files) if a model cannot be loaded, e.g. low memory. */
    suspend fun run(onProgress: (EmbedProgress) -> Unit): String {
        val text = models.activeTextModel()
        val image = models.activeImageModel()
        if (text == null && image == null) return "no semantic model selected"
        var paused: String? = null
        try {
            if (text != null) paused = textPhase(text.manifest.key, onProgress)
            if (paused == null && powerPause == null && image != null) paused = imagePhase(image.manifest.key, onProgress)
        } finally {
            models.unloadAll()
        }
        val base = "embedded $done, reused $reused, failed $failed"
        val why = paused ?: powerPause?.message
        return if (why != null) "$base (paused: $why)" else base
    }

    private suspend fun textPhase(key: String, onProgress: (EmbedProgress) -> Unit): String? {
        val total = emb.countPendingText(key)
        var processed = 0
        while (true) {
            currentCoroutineContext().ensureActive()
            val batch = emb.pendingText(key, BATCH)
            if (batch.isEmpty()) return null
            if (gatePaused()) return null
            for (f in batch) {
                currentCoroutineContext().ensureActive()
                if (emb.reuse(f.id, f.fp, key)) {
                    reused++
                } else {
                    val chunks = Chunker.chunk(repo.textOf(f.id))
                    if (chunks.isEmpty()) {
                        emb.save(f.id, key, emptyList())
                        emptyDone++
                    } else {
                        val vecs = try {
                            models.withText { it.embedDocs(chunks) }
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            Log.w(TAG, "text embed failed: " + e.javaClass.simpleName)
                            emb.markFailed(f.id, key, e.javaClass.simpleName)
                            failed++
                            processed++
                            continue
                        }
                        if (vecs == null) return models.lastProblem ?: "text model unavailable"
                        emb.save(f.id, key, vecs)
                        done++
                    }
                }
                processed++
                onProgress(EmbedProgress("Text embeddings", processed, total))
            }
        }
    }

    private suspend fun imagePhase(key: String, onProgress: (EmbedProgress) -> Unit): String? {
        val total = emb.countPendingImages(key)
        var processed = 0
        val configured = ctx.getSharedPreferences("rag_prefs", Context.MODE_PRIVATE)
            .getInt("image_batch_size", 1).let { if (it in listOf(1, 2, 4)) it else 1 }
        while (true) {
            currentCoroutineContext().ensureActive()
            val pending = emb.pendingImages(key, maxOf(BATCH, configured))
            if (pending.isEmpty()) return null
            if (gatePaused()) return null
            val work = pending.filterNot { emb.reuse(it.id, it.fp, key).also { reusedNow -> if (reusedNow) reused++ } }
            processed += pending.size - work.size
            if (work.isNotEmpty()) {
                for (group in ImageBatchPlanner.chunks(work, configured)) {
                    currentCoroutineContext().ensureActive()
                    val bitmaps = ArrayList<android.graphics.Bitmap>()
                    val valid = ArrayList<com.mrk.filerag.data.PendingFile>()
                    try {
                        try {
                            for (f in group) {
                                val bm = BitmapUtil.decodeUpright(f.path, 512)
                                if (bm == null) {
                                    emb.markFailed(f.id, key, "undecodable image")
                                    failed++
                                    processed++
                                } else {
                                    bitmaps.add(bm)
                                    valid.add(f)
                                }
                            }
                        } catch (e: OutOfMemoryError) {
                            Log.w(TAG, "image decode exhausted memory; leaving batch pending", e)
                            return "paused: insufficient memory while decoding images; pending files will retry on the next run"
                        }

                        if (bitmaps.isNotEmpty()) {
                            var batchVectors: List<FloatArray>? = null
                            var batchFailed = false
                            try {
                                batchVectors = models.withClipImage { it.embedBatch(bitmaps) }
                                if (batchVectors != null && batchVectors!!.size != valid.size) {
                                    batchFailed = true
                                    Log.w(TAG, "image batch output count mismatch; retrying after releasing batch bitmaps")
                                }
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: OutOfMemoryError) {
                                Log.w(TAG, "image batch inference exhausted memory; leaving batch pending", e)
                                return "paused: insufficient memory during image inference; pending files will retry on the next run"
                            } catch (e: Exception) {
                                batchFailed = true
                                Log.w(TAG, "image batch failed; will retry individually after releasing bitmaps", e)
                            }

                            if (!batchFailed && batchVectors != null) {
                                valid.forEachIndexed { i, f ->
                                    emb.save(f.id, key, listOf(batchVectors!![i]))
                                    done++
                                    processed++
                                }
                            } else if (batchFailed) {
                                // Release every batch bitmap before allocating any individual retry bitmap.
                                bitmaps.forEach { if (!it.isRecycled) it.recycle() }
                                bitmaps.clear()
                                valid.forEach { f ->
                                    currentCoroutineContext().ensureActive()
                                    var single: android.graphics.Bitmap? = null
                                    try {
                                        single = BitmapUtil.decodeUpright(f.path, 512)
                                        if (single == null) {
                                            emb.markFailed(f.id, key, "undecodable image")
                                            failed++
                                        } else {
                                            val vector = models.withClipImage { it.embed(single!!) }
                                            if (vector == null) return models.lastProblem ?: "image model unavailable"
                                            emb.save(f.id, key, listOf(vector))
                                            done++
                                        }
                                    } catch (e: CancellationException) {
                                        throw e
                                    } catch (e: OutOfMemoryError) {
                                        Log.w(TAG, "single image retry exhausted memory; leaving remaining files pending", e)
                                        return "paused: insufficient memory during single-image retry; pending files will retry on the next run"
                                    } catch (e: Exception) {
                                        Log.w(TAG, "single image retry failed: " + e.javaClass.simpleName)
                                        emb.markFailed(f.id, key, e.javaClass.simpleName)
                                        failed++
                                    } finally {
                                        single?.let { if (!it.isRecycled) it.recycle() }
                                    }
                                    processed++
                                }
                            } else if (batchVectors == null) {
                                return models.lastProblem ?: "image model unavailable"
                            }
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: OutOfMemoryError) {
                        Log.w(TAG, "image processing exhausted memory; leaving files pending", e)
                        return "paused: insufficient memory while processing images; pending files will retry on the next run"
                    } finally {
                        bitmaps.forEach { if (!it.isRecycled) it.recycle() }
                    }
                    onProgress(EmbedProgress("Image embeddings", processed, total))
                }
            }
        }
    }
}
