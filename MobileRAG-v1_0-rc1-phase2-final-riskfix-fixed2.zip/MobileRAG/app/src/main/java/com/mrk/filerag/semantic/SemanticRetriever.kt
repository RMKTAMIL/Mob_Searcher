package com.mrk.filerag.semantic

import com.mrk.filerag.data.Db
import com.mrk.filerag.data.EmbeddingRepository
import com.mrk.filerag.search.FilterSql
import com.mrk.filerag.search.Filters
import com.mrk.filerag.search.Fusion
import com.mrk.filerag.search.Retrieved
import com.mrk.filerag.search.Retriever
import com.mrk.filerag.settings.Prefs

/**
 * Brute-force cosine search over int8 vectors streamed from SQLite (exact, no ANN index).
 * Text chunks use the sentence model; images use the CLIP image tower queried with the CLIP text tower.
 * Returns an empty result (so keyword search carries on alone) when disabled, not provisioned, or low on memory.
 */
class SemanticRetriever(
    private val db: Db,
    private val emb: EmbeddingRepository,
    private val models: ModelManager,
    private val prefs: Prefs
) : Retriever {

    override fun retrieve(raw: String, filters: Filters, cap: Int): Retrieved {
        if (!prefs.semanticEnabled) return Retrieved(emptyList(), false, null, true)
        val lists = ArrayList<List<Long>>()

        val textModel = models.activeTextModel()
        if (textModel != null && emb.embeddedFiles(textModel.manifest.key) > 0) {
            val q = models.withText { it.embedQuery(raw) }
            if (q != null) lists.add(top(textModel.manifest.key, q, textModel.manifest.minScore, cap))
        }
        val imageModel = models.activeImageModel()
        if (imageModel != null && emb.embeddedFiles(imageModel.manifest.key) > 0) {
            val q = models.withClipText { it.embed(raw) }
            if (q != null) lists.add(top(imageModel.manifest.key, q, imageModel.manifest.minScore, cap))
        }
        val fused = if (lists.size > 1) Fusion.rrf(lists) else (lists.firstOrNull() ?: emptyList())
        val filtered = applyFilters(fused, filters)
        return Retrieved(filtered.take(cap), filtered.size > cap, null, true)
    }

    private fun top(key: String, q: FloatArray, minScore: Float, cap: Int): List<Long> {
        val best = HashMap<Long, Float>()
        emb.scan(key) { id, scale, vec ->
            val s = VectorMath.dot(q, vec, scale)
            if (s >= minScore) {
                val prev = best[id]
                if (prev == null || s > prev) best[id] = s
            }
        }
        return best.entries.sortedWith(compareByDescending<Map.Entry<Long, Float>> { it.value }.thenBy { it.key })
            .take(cap).map { it.key }
    }

    private fun applyFilters(ids: List<Long>, f: Filters): List<Long> {
        if (!f.isActive || ids.isEmpty()) return ids
        val keep = HashSet<Long>()
        for (part in ids.chunked(500)) {
            val args = ArrayList<String>()
            val sql = "SELECT files.id FROM files WHERE files.id IN (" + part.joinToString(",") + ")" + FilterSql.where(f, args)
            db.readableDatabase.rawQuery(sql, args.toTypedArray()).use { c -> while (c.moveToNext()) keep.add(c.getLong(0)) }
        }
        return ids.filter { it in keep }
    }
}
