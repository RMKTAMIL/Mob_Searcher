package com.mrk.filerag.semantic

import java.text.Normalizer

/** BERT-style tokenizer (basic split + WordPiece) for sentence-embedding models such as MiniLM. */
class WordPieceTokenizer(
    private val vocab: Map<String, Int>,
    private val lowercase: Boolean = true,
    private val maxCharsPerWord: Int = 100
) {
    class Encoded(val ids: LongArray, val mask: LongArray, val types: LongArray)

    private val unk = vocab["[UNK]"] ?: 0
    private val cls = vocab["[CLS]"] ?: 101
    private val sep = vocab["[SEP]"] ?: 102

    fun encode(text: String, maxLen: Int): Encoded {
        require(maxLen >= 3)
        val pieces = ArrayList<Int>()
        for (w in basic(text)) {
            pieces.addAll(wordPiece(w))
            if (pieces.size >= maxLen - 2) break
        }
        val body = pieces.take(maxLen - 2)
        val ids = LongArray(body.size + 2)
        ids[0] = cls.toLong()
        for (i in body.indices) ids[i + 1] = body[i].toLong()
        ids[ids.size - 1] = sep.toLong()
        return Encoded(ids, LongArray(ids.size) { 1L }, LongArray(ids.size))
    }

    private fun isWhitespace(ch: Char) =
        ch == ' ' || ch == '\t' || ch == '\n' || ch == '\r' || Character.getType(ch) == Character.SPACE_SEPARATOR.toInt()

    private fun isControl(ch: Char): Boolean {
        if (ch == '\t' || ch == '\n' || ch == '\r') return false
        val t = Character.getType(ch)
        return t == Character.CONTROL.toInt() || t == Character.FORMAT.toInt()
    }

    private fun isPunct(ch: Char): Boolean {
        val c = ch.code
        if (c in 33..47 || c in 58..64 || c in 91..96 || c in 123..126) return true
        return when (Character.getType(ch)) {
            Character.CONNECTOR_PUNCTUATION.toInt(), Character.DASH_PUNCTUATION.toInt(),
            Character.START_PUNCTUATION.toInt(), Character.END_PUNCTUATION.toInt(),
            Character.INITIAL_QUOTE_PUNCTUATION.toInt(), Character.FINAL_QUOTE_PUNCTUATION.toInt(),
            Character.OTHER_PUNCTUATION.toInt() -> true
            else -> false
        }
    }

    internal fun basic(text: String): List<String> {
        val cleaned = StringBuilder()
        for (ch in text) {
            if (ch.code == 0 || ch.code == 0xFFFD || isControl(ch)) continue
            cleaned.append(if (isWhitespace(ch)) ' ' else ch)
        }
        var s = cleaned.toString()
        if (lowercase) {
            s = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
                .filter { Character.getType(it) != Character.NON_SPACING_MARK.toInt() }
        }
        val out = ArrayList<String>()
        for (w in s.split(' ')) {
            if (w.isEmpty()) continue
            val cur = StringBuilder()
            for (ch in w) {
                if (isPunct(ch)) {
                    if (cur.isNotEmpty()) { out.add(cur.toString()); cur.setLength(0) }
                    out.add(ch.toString())
                } else cur.append(ch)
            }
            if (cur.isNotEmpty()) out.add(cur.toString())
        }
        return out
    }

    internal fun wordPiece(token: String): List<Int> {
        if (token.length > maxCharsPerWord) return listOf(unk)
        val ids = ArrayList<Int>()
        var start = 0
        while (start < token.length) {
            var end = token.length
            var found: Int? = null
            while (start < end) {
                var sub = token.substring(start, end)
                if (start > 0) sub = "##$sub"
                val id = vocab[sub]
                if (id != null) { found = id; break }
                end--
            }
            val f = found ?: return listOf(unk)
            ids.add(f)
            start = end
        }
        return ids
    }
}
