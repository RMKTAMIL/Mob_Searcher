package com.mrk.filerag.settings

import android.os.Environment
import com.mrk.filerag.search.AppSource
import java.io.File

/** Candidate media folders of popular apps, resolved against the real storage root at runtime. */
object Sources {
    private val defs = listOf(
        "WhatsApp" to listOf("Android/media/com.whatsapp/WhatsApp/Media", "WhatsApp/Media"),
        "WhatsApp Business" to listOf("Android/media/com.whatsapp.w4b/WhatsApp Business/Media", "WhatsApp Business/Media"),
        "Telegram" to listOf(
            "Android/media/org.telegram.messenger/Telegram", "Telegram",
            "Pictures/Telegram", "Movies/Telegram", "Download/Telegram"
        ),
        "Instagram" to listOf("Pictures/Instagram", "Movies/Instagram", "DCIM/Instagram"),
        "Camera" to listOf("DCIM/Camera"),
        "Screenshots" to listOf("Pictures/Screenshots", "DCIM/Screenshots"),
        "Downloads" to listOf("Download"),
        "Documents" to listOf("Documents")
    )

    fun detected(): List<AppSource> {
        val root = Environment.getExternalStorageDirectory()
        return defs.mapNotNull { (label, rels) ->
            val found = rels.map { File(root, it) }.filter { it.isDirectory }.map { it.path }
            if (found.isEmpty()) null else AppSource(label, found)
        }
    }
}
