package com.mrk.filerag.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mrk.filerag.files.fmtSize
import com.mrk.filerag.files.shortName
import com.mrk.filerag.index.IndexUi
import com.mrk.filerag.search.AppSource
import com.mrk.filerag.search.DateRange
import com.mrk.filerag.search.Filters
import com.mrk.filerag.search.Hit
import com.mrk.filerag.search.Kind
import com.mrk.filerag.search.SizeRange
import com.mrk.filerag.search.SortBy
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.text.DateFormat
import java.util.Date

@Composable
fun HomeScreen(
    holder: SearchHolder,
    folders: List<String>,
    sources: List<AppSource>,
    indexedCount: Int,
    indexUi: IndexUi,
    semanticStatus: String,
    dataVersion: Int,
    onOpen: (Hit) -> Unit,
    onIndexScreen: () -> Unit,
    onSettings: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val focus = LocalFocusManager.current

    LaunchedEffect(holder.query, holder.filters, dataVersion) {
        delay(250)
        holder.refresh()
    }
    LaunchedEffect(holder.query, dataVersion) { holder.loadChips() }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("File RAG", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = onIndexScreen) { Text("Index") }
                OutlinedButton(onClick = onSettings) { Text("Settings") }
            }
        }
        OutlinedTextField(
            value = holder.query,
            onValueChange = { holder.query = it },
            label = { Text("Describe a file or photo") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = {
                scope.launch { holder.record() }
                focus.clearFocus()
            }),
            trailingIcon = {
                if (holder.query.isNotEmpty()) TextButton(onClick = { holder.query = "" }) { Text("Clear") }
            },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
        )
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val f = holder.filters
            Picker("Type", f.kind, Kind.values().toList(), { it.label }) { holder.filters = holder.filters.copy(kind = it) }
            Picker("Date", f.date, DateRange.values().toList(), { it.label }) { holder.filters = holder.filters.copy(date = it) }
            Picker("Size", f.size, SizeRange.values().toList(), { it.label }) { holder.filters = holder.filters.copy(size = it) }
            Picker("Sort", f.sort, SortBy.values().toList(), { it.label }) { holder.filters = holder.filters.copy(sort = it) }
            if (folders.isNotEmpty()) {
                Picker("Folder", f.folder, listOf<String?>(null) + folders, { p -> p?.let { shortName(it) } ?: "All" }) {
                    holder.filters = holder.filters.copy(folder = it)
                }
            }
            if (sources.isNotEmpty()) {
                Picker("App", f.source, listOf<AppSource?>(null) + sources, { s -> s?.label ?: "All apps" }) {
                    holder.filters = holder.filters.copy(source = it)
                }
            }
            if (f.isActive) TextButton(onClick = { holder.filters = Filters() }) { Text("Reset") }
        }

        Text("$indexedCount files indexed  |  Semantic: $semanticStatus", fontSize = 12.sp)
        if (indexUi.running) {
            Text(
                indexUi.phase + ": " + (if (indexUi.message.isNotEmpty()) indexUi.message else "${indexUi.progress.indexed} new, ${indexUi.progress.failed} failed"),
                fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }

        if (holder.chips.isNotEmpty()) {
            Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
                Text(if (holder.query.trim().length >= 2) "Suggestions:" else "Recent:", fontSize = 12.sp)
                holder.chips.forEach { chip -> TextButton(onClick = { holder.query = chip }) { Text(chip, fontSize = 13.sp) } }
                if (holder.query.isBlank()) {
                    TextButton(onClick = { scope.launch { holder.history.clear(); holder.loadChips() } }) { Text("Clear history", fontSize = 12.sp) }
                }
            }
        }

        val err = holder.error
        when {
            err != null -> Text("Search failed: $err", color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 12.dp))
            holder.hits.isEmpty() && !holder.busy -> Text(
                when {
                    indexedCount == 0 -> "Nothing indexed yet. Open Index and tap Index now (choose folders in Settings first if you like)."
                    holder.query.isBlank() && !holder.filters.isActive -> "Type what you are looking for, or pick a filter to browse."
                    else -> "No matches. Try fewer words, or quotes for an exact phrase."
                },
                modifier = Modifier.padding(top = 16.dp)
            )
            else -> {
                if (holder.hits.isNotEmpty()) {
                    Text(
                        "${holder.total}${if (holder.truncated) "+" else ""} results in ${holder.elapsedMs} ms" +
                            (if (holder.truncated) " (very broad query: narrow it for complete results)" else ""),
                        fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)
                    )
                }
                LazyColumn(Modifier.fillMaxSize()) {
                    itemsIndexed(holder.hits) { index, h ->
                        ResultRow(h) {
                            scope.launch { holder.record() }
                            onOpen(h)
                        }
                        if (index == holder.hits.lastIndex && holder.hasMore) {
                            LaunchedEffect(holder.hits.size) { holder.loadMore() }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ResultRow(h: Hit, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 10.dp)) {
        Text(h.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(
            File(h.path).extension.uppercase() + "  |  " + fmtSize(h.size) + "  |  " +
                DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(h.mtime)) +
                (if (h.semantic) "  |  meaning match" else ""),
            fontSize = 11.sp
        )
        if (h.snippet.isNotBlank()) Text(h.snippet, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Text(h.path, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.primary)
    }
}
