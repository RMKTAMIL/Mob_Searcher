package com.mrk.filerag.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mrk.filerag.AppContainer
import com.mrk.filerag.data.DbStats
import com.mrk.filerag.data.FailedFile
import com.mrk.filerag.files.fmtSize
import com.mrk.filerag.index.IndexUi
import com.mrk.filerag.semantic.Benchmark
import com.mrk.filerag.semantic.EmbedState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

private data class SemStats(
    val textKey: String?, val textDone: Int, val textPending: Int,
    val imageKey: String?, val imageDone: Int, val imagePending: Int,
    val keys: List<Pair<String, Int>>
)

@Composable
fun IndexScreen(
    c: AppContainer,
    indexUi: IndexUi,
    busy: Boolean,
    refreshKey: Int,
    onToggle: () -> Unit,
    onEmbedOnly: () -> Unit,
    onStartAfterReset: () -> Unit,
    onChanged: () -> Unit,
    onBack: () -> Unit
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val embed by EmbedState.ui.collectAsState()
    var stats by remember { mutableStateOf<DbStats?>(null) }
    var failed by remember { mutableStateOf(emptyList<FailedFile>()) }
    var sem by remember { mutableStateOf<SemStats?>(null) }
    var showFailed by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf("") }
    var bench by remember { mutableStateOf("") }
    var benchRunning by remember { mutableStateOf(false) }

    LaunchedEffect(busy, refreshKey, embed.done) {
        withContext(Dispatchers.IO) {
            stats = c.repo.stats()
            failed = c.repo.failedFiles()
            val t = c.models.activeTextModel()?.manifest?.key
            val i = c.models.activeImageModel()?.manifest?.key
            sem = SemStats(
                t, t?.let { c.embeddings.embeddedFiles(it) } ?: 0, t?.let { c.embeddings.countPendingText(it) } ?: 0,
                i, i?.let { c.embeddings.embeddedFiles(it) } ?: 0, i?.let { c.embeddings.countPendingImages(it) } ?: 0,
                c.embeddings.keysInUse()
            )
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = onBack) { Text("Back") }
            Spacer(Modifier.width(12.dp))
            Text("Index", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }

        SectionTitle("Status")
        Text(
            when {
                indexUi.running -> indexUi.phase + (if (indexUi.message.isNotEmpty()) " (${indexUi.message})" else "")
                busy -> "Queued"
                else -> "Idle"
            }
        )
        if (indexUi.running) {
            val p = indexUi.progress
            Text("scanned ${p.scanned}, new/changed ${p.indexed}, failed ${p.failed}, skipped ${p.skipped}, reused ${p.reused}", fontSize = 12.sp)
            if (p.current.isNotEmpty()) Text("last: ${p.current}", fontSize = 12.sp, maxLines = 1)
        } else if (indexUi.message.isNotEmpty()) {
            Text(indexUi.message, fontSize = 12.sp)
        }
        if (c.prefs.runInProgress && !busy) {
            Text("The last run was interrupted. Tap Index now to continue where it stopped.", fontSize = 12.sp)
        }

        val s = stats
        if (s != null) {
            SectionTitle("Index")
            Text("${s.total} files: ${s.ok} indexed, ${s.failed} failed, ${s.skipped} skipped")
            Text("Indexed content size: ${fmtSize(s.totalBytes)}  |  Database: ${fmtSize(s.dbBytes)}", fontSize = 13.sp)
            Text(
                "Last indexed file: " + (if (s.lastIndexedAt > 0) DateFormat.getDateTimeInstance().format(Date(s.lastIndexedAt)) else "never"),
                fontSize = 13.sp
            )
            if (c.prefs.lastSummary.isNotEmpty()) Text("Last run: " + c.prefs.lastSummary, fontSize = 12.sp)
        }

        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onToggle) { Text(if (busy) "Stop" else "Index now") }
            if (c.prefs.semanticEnabled) OutlinedButton(onClick = onEmbedOnly, enabled = !busy) { Text("Semantic only") }
        }

        val sm = sem
        if (c.prefs.semanticEnabled && sm != null) {
            SectionTitle("Semantic index (on device)")
            Text("Text model: ${sm.textKey ?: "none"}  |  ${sm.textDone} files embedded, ${sm.textPending} pending", fontSize = 13.sp)
            Text("Image model: ${sm.imageKey ?: "none"}  |  ${sm.imageDone} files embedded, ${sm.imagePending} pending", fontSize = 13.sp)
            if (embed.phase.isNotEmpty()) Text("${embed.phase}: ${embed.done}/${embed.total}", fontSize = 12.sp)
            if (sm.keys.isNotEmpty()) {
                Text("Embeddings stored per model version: " + sm.keys.joinToString { "${it.first} (${it.second})" }, fontSize = 12.sp)
            }
        }

        SectionTitle("Maintenance")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { showFailed = !showFailed }, enabled = failed.isNotEmpty()) { Text("Failed files (${stats?.failed ?: 0})") }
            OutlinedButton(onClick = { confirm = "retry" }, enabled = !busy && (stats?.failed ?: 0) > 0) { Text("Retry failed") }
        }
        if (showFailed) {
            failed.forEach {
                Text("${it.path}\n  ${it.error} (attempts ${it.attempts})", fontSize = 11.sp, modifier = Modifier.padding(vertical = 3.dp))
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { confirm = "reindex" }, enabled = !busy) { Text("Re-index all") }
            OutlinedButton(onClick = { confirm = "clear" }, enabled = !busy) { Text("Clear index") }
        }
        val old = sm?.keys?.filter { it.first != sm.textKey && it.first != sm.imageKey } ?: emptyList()
        if (old.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { confirm = "purge" }, enabled = !busy) { Text("Delete embeddings of old model versions") }
        }

        SectionTitle("Benchmark (measured on this phone)")
        Text("Unplug the phone for the battery measurement. Takes about 1-2 minutes.", fontSize = 12.sp)
        OutlinedButton(
            enabled = !benchRunning && !busy,
            onClick = {
                benchRunning = true
                bench = "Running..."
                scope.launch {
                    bench = try {
                        withContext(Dispatchers.Default) { Benchmark.run(ctx.applicationContext, c.models) }
                    } catch (e: Exception) {
                        "Benchmark failed: " + e.javaClass.simpleName
                    }
                    benchRunning = false
                }
            }
        ) { Text("Run benchmark") }
        if (bench.isNotEmpty()) SelectionContainer { Text(bench, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp)) }
    }

    when (confirm) {
        "retry" -> Confirm("Retry failed files?", "Failed files are queued again and indexed on the next run.", "Retry",
            { scope.launch(Dispatchers.IO) { c.repo.resetFailed() }; onStartAfterReset() }, { confirm = "" })
        "reindex" -> Confirm("Re-index everything?", "Every file is re-read on the next run. Current search results stay usable until each file is replaced; nothing is deleted.", "Re-index",
            { scope.launch(Dispatchers.IO) { c.repo.markAllStale() }; onStartAfterReset() }, { confirm = "" })
        "clear" -> Confirm("Clear index?", "Deletes the search index and all embeddings. Your files are not touched. You will need to index again.", "Clear",
            { scope.launch(Dispatchers.IO) { c.repo.clear(); withContext(Dispatchers.Main) { onChanged() } } }, { confirm = "" })
        "purge" -> Confirm("Delete old embeddings?", "Removes embeddings made by model versions that are no longer selected. Files are not touched.", "Delete",
            {
                scope.launch(Dispatchers.IO) {
                    val keep = listOfNotNull(c.models.activeTextModel()?.manifest?.key, c.models.activeImageModel()?.manifest?.key).toSet()
                    c.embeddings.purgeExcept(keep)
                    withContext(Dispatchers.Main) { onChanged() }
                }
            }, { confirm = "" })
    }
}
