package com.mrk.filerag.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.work.WorkManager
import com.mrk.filerag.AppContainer
import com.mrk.filerag.files.hasAccess
import com.mrk.filerag.index.IndexScheduler
import com.mrk.filerag.index.IndexState
import com.mrk.filerag.search.Hit
import com.mrk.filerag.settings.Sources
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val container = AppContainer.get(this)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { AppRoot(container) }
            }
        }
    }
}

enum class Screen { HOME, INDEX, SETTINGS }

@Composable
fun AppRoot(c: AppContainer) {
    val ctx = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle

    var access by remember { mutableStateOf(hasAccess(ctx)) }
    DisposableEffect(lifecycle) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) access = hasAccess(ctx) }
        lifecycle.addObserver(obs)
        onDispose { lifecycle.removeObserver(obs) }
    }
    val legacyLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { access = hasAccess(ctx) }

    var screen by remember { mutableStateOf(Screen.HOME) }
    var viewing by remember { mutableStateOf<Hit?>(null) }
    val holder = remember { SearchHolder(c.search, c.history) }
    var folders by remember { mutableStateOf(c.prefs.folders()) }
    val sources = remember(access) { Sources.detected() }

    val indexUi by IndexState.ui.collectAsState()
    val infos by WorkManager.getInstance(ctx).getWorkInfosForUniqueWorkFlow(IndexScheduler.NOW).collectAsState(initial = emptyList())
    val busy = indexUi.running || infos.any { !it.state.isFinished }

    var dataVersion by remember { mutableStateOf(0) }
    LaunchedEffect(busy) { if (!busy) dataVersion++ }
    var indexedCount by remember { mutableStateOf(0) }
    var semanticStatus by remember { mutableStateOf("off") }
    LaunchedEffect(dataVersion, screen) {
        withContext(Dispatchers.IO) {
            indexedCount = c.repo.count()
            semanticStatus = when {
                !c.prefs.semanticEnabled -> "off"
                c.models.activeTextModel() == null && c.models.activeImageModel() == null -> "on, no model selected"
                c.models.lastProblem != null -> "fallback (" + c.models.lastProblem + ")"
                else -> "on"
            }
        }
    }

    val view = LocalView.current
    SideEffect { view.keepScreenOn = busy }

    BackHandler(enabled = viewing != null || screen != Screen.HOME) {
        if (viewing != null) viewing = null else screen = Screen.HOME
    }

    if (!access) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
            Text("File RAG", fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.padding(8.dp))
            Text(
                "To index your documents and photos the app needs access to all files. " +
                    "This is the one broad permission it requests; the app has no network permission, so nothing can leave the phone."
            )
            Spacer(Modifier.padding(8.dp))
            Button(onClick = {
                if (Build.VERSION.SDK_INT >= 30) {
                    ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + ctx.packageName)))
                } else {
                    legacyLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                }
            }) { Text("Grant access") }
        }
        return
    }

    val v = viewing
    if (v != null) {
        Viewer(v) { viewing = null }
        return
    }

    val toggle = { if (busy) IndexScheduler.stop(ctx) else IndexScheduler.start(ctx) }

    when (screen) {
        Screen.HOME -> HomeScreen(
            holder = holder, folders = folders, sources = sources, indexedCount = indexedCount, indexUi = indexUi,
            semanticStatus = semanticStatus, dataVersion = dataVersion,
            onOpen = { viewing = it }, onIndexScreen = { screen = Screen.INDEX }, onSettings = { screen = Screen.SETTINGS }
        )
        Screen.INDEX -> IndexScreen(
            c = c, indexUi = indexUi, busy = busy, refreshKey = dataVersion,
            onToggle = { toggle() },
            onEmbedOnly = { IndexScheduler.start(ctx, IndexScheduler.MODE_EMBED) },
            onStartAfterReset = { IndexScheduler.start(ctx) },
            onChanged = { dataVersion++ },
            onBack = { screen = Screen.HOME }
        )
        Screen.SETTINGS -> SettingsScreen(
            c = c, folders = folders, sources = sources,
            onFolders = { folders = it; c.prefs.setFolders(it); if (holder.filters.folder !in it) holder.filters = holder.filters.copy(folder = null) },
            onChanged = { dataVersion++ },
            onBack = { screen = Screen.HOME }
        )
    }
}
