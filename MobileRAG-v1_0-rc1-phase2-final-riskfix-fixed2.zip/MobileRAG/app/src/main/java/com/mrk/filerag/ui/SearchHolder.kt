package com.mrk.filerag.ui

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.mrk.filerag.data.HistoryStore
import com.mrk.filerag.search.Filters
import com.mrk.filerag.search.Hit
import com.mrk.filerag.search.SearchEngine
import com.mrk.filerag.search.SearchSession
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** UI state for the search screen. All database work runs on Dispatchers.IO. */
class SearchHolder(private val engine: SearchEngine, val history: HistoryStore) {
    var query by mutableStateOf("")
    var filters by mutableStateOf(Filters())
    var hits by mutableStateOf(emptyList<Hit>())
    var total by mutableStateOf(0)
    var truncated by mutableStateOf(false)
    var elapsedMs by mutableStateOf(0L)
    var error by mutableStateOf<String?>(null)
    var busy by mutableStateOf(false)
    var hasMore by mutableStateOf(false)
    var chips by mutableStateOf(emptyList<String>())

    private var session: SearchSession? = null
    private var loadingMore = false

    suspend fun refresh() {
        busy = true
        try {
            val s = withContext(Dispatchers.IO) { engine.start(query, filters) }
            val first = withContext(Dispatchers.IO) { s.nextPage() }
            session = s
            hits = first
            total = s.total
            truncated = s.truncated
            elapsedMs = s.elapsedMs
            hasMore = s.hasMore()
            error = null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e("SearchHolder", "search failed", e)
            hits = emptyList()
            hasMore = false
            error = e.message ?: e.javaClass.simpleName
        } finally {
            busy = false
        }
    }

    suspend fun loadMore() {
        val s = session ?: return
        if (loadingMore || !s.hasMore()) return
        loadingMore = true
        try {
            val more = withContext(Dispatchers.IO) { s.nextPage() }
            hits = hits + more
            hasMore = s.hasMore()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e("SearchHolder", "load more failed", e)
            error = e.message ?: e.javaClass.simpleName
        } finally {
            loadingMore = false
        }
    }

    suspend fun loadChips() {
        chips = withContext(Dispatchers.IO) {
            if (query.trim().length >= 2) history.suggest(query) else history.recent()
        }
    }

    suspend fun record() {
        withContext(Dispatchers.IO) { history.record(query) }
        loadChips()
    }
}
