package com.mrk.filerag.ui

import android.Manifest
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mrk.filerag.AppContainer
import com.mrk.filerag.files.fmtSize
import com.mrk.filerag.files.hasNoInternetPermission
import com.mrk.filerag.files.treeUriToPath
import com.mrk.filerag.index.IndexScheduler
import com.mrk.filerag.search.AppSource
import com.mrk.filerag.semantic.ImportResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun SettingsScreen(
    c: AppContainer,
    folders: List<String>,
    sources: List<AppSource>,
    onFolders: (List<String>) -> Unit,
    onChanged: () -> Unit,
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = c.prefs
    var labels by remember { mutableStateOf(prefs.labels) }
    var ocr by remember { mutableStateOf(prefs.ocr) }
    var docs by remember { mutableStateOf(prefs.docs) }
    var text by remember { mutableStateOf(prefs.text) }
    var auto by remember { mutableStateOf(prefs.autoIndex) }
    var workers by remember { mutableStateOf(prefs.workers) }
    var semantic by remember { mutableStateOf(prefs.semanticEnabled) }
    var charging by remember { mutableStateOf(prefs.semanticOnlyCharging) }
    var threads by remember { mutableStateOf(prefs.semanticThreads) }
    var imageBatch by remember { mutableStateOf(prefs.imageBatchSize) }
    var provider by remember { mutableStateOf(prefs.executionProvider) }
    var cacheMb by remember { mutableStateOf(prefs.thumbnailCacheMb) }
    var activeText by remember { mutableStateOf(prefs.activeTextModel) }
    var activeImage by remember { mutableStateOf(prefs.activeImageModel) }
    var installed by remember { mutableStateOf(c.models.store.installed()) }
    var message by remember { mutableStateOf("") }

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            val p = treeUriToPath(uri)
            if (p == null) Toast.makeText(ctx, "Pick a folder in phone or SD card storage", Toast.LENGTH_LONG).show()
            else if (p !in folders) onFolders(folders + p)
        }
    }
    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            val p = treeUriToPath(uri)
            if (p == null) message = "Pick the model folder on phone or SD card storage"
            else {
                message = "Importing and verifying (SHA-256)..."
                scope.launch {
                    val r = withContext(Dispatchers.IO) { c.models.store.import(File(p)) }
                    message = when (r) {
                        is ImportResult.Ok -> "Imported ${r.model.manifest.key} (${fmtSize(r.model.bytes)})"
                        is ImportResult.Error -> "Import failed: ${r.message}"
                    }
                    installed = withContext(Dispatchers.IO) { c.models.store.installed() }
                }
            }
        }
    }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = onBack) { Text("Back") }
            Spacer(Modifier.width(12.dp))
            Text("Settings", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }

        SectionTitle("Quick add app folders")
        if (sources.isEmpty()) Text("No app folders found on this phone.", fontSize = 13.sp)
        sources.forEach { s ->
            val added = s.paths.all { it in folders }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(s.label, modifier = Modifier.weight(1f))
                if (added) OutlinedButton(onClick = { onFolders(folders - s.paths.toSet()) }) { Text("Remove") }
                else Button(onClick = { onFolders((folders + s.paths).distinct()) }) { Text("Add") }
            }
        }

        SectionTitle("Folders to index")
        if (folders.isEmpty()) {
            Text("None chosen: the whole phone storage is indexed, except the Android folder. Add WhatsApp or Telegram above to include their media.", fontSize = 13.sp)
        }
        folders.forEach { p ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(p, fontSize = 12.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { onFolders(folders - p) }) { Text("Remove") }
            }
        }
        OutlinedButton(onClick = { folderPicker.launch(null) }) { Text("Add folder") }
        Text("After a full run, files outside the chosen folders are dropped from the index.", fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))

        SectionTitle("What to read inside files")
        SwitchRow("Photos: object labels (ML Kit, on device)", labels) { labels = it; prefs.labels = it }
        SwitchRow("Photos and scanned PDFs: text (OCR)", ocr) { ocr = it; prefs.ocr = it }
        SwitchRow("PDF, Word, PowerPoint, Excel, HTML text", docs) { docs = it; prefs.docs = it }
        SwitchRow("Text and code files", text) { text = it; prefs.text = it }
        Text("File names, dates and photo metadata are always indexed. A changed switch applies to new or changed files; use Index > Re-index all to redo everything.", fontSize = 12.sp)

        SectionTitle("Background indexing")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Parallel workers: $workers", modifier = Modifier.weight(1f))
            Picker("Workers", workers, listOf(1, 2, 3, 4), { it.toString() }) { workers = it; prefs.workers = it }
        }
        SwitchRow("Re-scan every ~12 hours while charging", auto) {
            auto = it; prefs.autoIndex = it; IndexScheduler.setPeriodic(ctx, it)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            OutlinedButton(onClick = { notif.launch(Manifest.permission.POST_NOTIFICATIONS) }) { Text("Allow progress notification") }
        }
        Text("Android decides when background work runs and may stop it. Indexing is resumable: a stopped run continues where it left off.", fontSize = 12.sp)

        SectionTitle("Semantic search (on-device AI)")
        Text(
            "Finds files by meaning (\"photo of my dog at the beach\", \"invoice from last winter\"). Models are NOT included " +
                "and the app cannot download them: it has no network permission. Copy a model pack folder to your phone and import it here. " +
                "See docs/MODELS.md. Without models, search uses keywords, OCR text and image labels only.",
            fontSize = 12.sp
        )
        SwitchRow("Enable semantic search", semantic) { semantic = it; prefs.semanticEnabled = it; onChanged() }
        installed.forEach { m ->
            val mf = m.manifest
            val isText = mf.kind == "sbert"
            val active = if (isText) activeText == mf.key else activeImage == mf.key
            Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Text("${mf.key}  (${if (isText) "text" else "image+text"}, ${mf.dim} dims, ${fmtSize(m.bytes)})", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Row {
                    if (active) Text("Active", fontSize = 12.sp, modifier = Modifier.padding(end = 8.dp, top = 12.dp))
                    else TextButton(onClick = {
                        if (isText) { activeText = mf.key; prefs.activeTextModel = mf.key } else { activeImage = mf.key; prefs.activeImageModel = mf.key }
                        c.models.unloadAll(); onChanged()
                    }) { Text("Use") }
                    TextButton(onClick = {
                        scope.launch {
                            val problems = withContext(Dispatchers.IO) { c.models.store.verify(m) }
                            message = if (problems.isEmpty()) "${mf.key}: all files verified (SHA-256)" else "${mf.key}: " + problems.joinToString()
                        }
                    }) { Text("Verify") }
                    TextButton(onClick = {
                        c.models.unloadAll()
                        scope.launch {
                            withContext(Dispatchers.IO) { c.models.store.remove(mf.key) }
                            if (activeText == mf.key) { activeText = null; prefs.activeTextModel = null }
                            if (activeImage == mf.key) { activeImage = null; prefs.activeImageModel = null }
                            installed = withContext(Dispatchers.IO) { c.models.store.installed() }
                            onChanged()
                        }
                    }) { Text("Remove") }
                }
            }
        }
        OutlinedButton(onClick = { modelPicker.launch(null) }) { Text("Import model pack (folder)") }
        if (message.isNotEmpty()) Text(message, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Inference threads: $threads", modifier = Modifier.weight(1f))
            Picker("Threads", threads, listOf(1, 2, 3, 4), { it.toString() }) { threads = it; prefs.semanticThreads = it; c.models.unloadAll() }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Image inference batch: $imageBatch", modifier = Modifier.weight(1f))
            Picker("Image batch", imageBatch, listOf(1, 2, 4), { it.toString() }) { imageBatch = it; prefs.imageBatchSize = it }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("ONNX provider: $provider", modifier = Modifier.weight(1f))
            Picker("Provider", listOf("CPU", "XNNPACK", "NNAPI").indexOf(provider).coerceAtLeast(0),
                listOf(0, 1, 2), { listOf("CPU", "XNNPACK", "NNAPI")[it] }) {
                provider = listOf("CPU", "XNNPACK", "NNAPI")[it]; prefs.executionProvider = provider; c.models.unloadAll()
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Thumbnail cache: $cacheMb MB", modifier = Modifier.weight(1f))
            Picker("Thumbnail cache", cacheMb, listOf(32, 64, 128, 256), { "$it MB" }) { cacheMb = it; prefs.thumbnailCacheMb = it; c.thumbnails.setMaxBytes(it * 1024 * 1024) }
        }
        Text("Provider, thread count and batch size apply to newly created sessions; model reload/unload is required for provider or thread changes. CPU is the conservative default. NNAPI may delegate supported operators to CPU; this is not a guarantee of GPU acceleration. Thumbnail cache stores derived previews only.", fontSize = 12.sp)
        SwitchRow("Background semantic indexing only while charging", charging) { charging = it; prefs.semanticOnlyCharging = it }
        Text("Embeddings and models never leave the phone. Models are unloaded after 45 s idle or when Android is short on memory; then search falls back to keywords.", fontSize = 12.sp)

        SectionTitle("Privacy")
        val offline = remember { hasNoInternetPermission(ctx) }
        Text(
            if (offline) "Network permission: not declared. Android will not let this app use the network."
            else "Network permission: DECLARED. This build can reach the network; do not rely on it being offline.",
            fontSize = 13.sp
        )
        Text("This is a static check of the installed app. It is not a substitute for testing in airplane mode.", fontSize = 12.sp)
    }
}
