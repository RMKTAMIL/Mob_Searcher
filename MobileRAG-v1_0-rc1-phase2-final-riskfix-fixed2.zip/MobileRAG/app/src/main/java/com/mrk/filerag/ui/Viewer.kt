package com.mrk.filerag.ui

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mrk.filerag.extract.BitmapUtil
import com.mrk.filerag.extract.FileKind
import com.mrk.filerag.extract.FileTypes
import com.mrk.filerag.extract.Limits
import com.mrk.filerag.extract.readChars
import com.mrk.filerag.files.openExternal
import com.mrk.filerag.search.Hit
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun Viewer(hit: Hit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val file = File(hit.path)
    val kind = FileTypes.kindOf(file.extension)
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = onBack) { Text("Back") }
            Spacer(Modifier.width(8.dp))
            OutlinedButton(onClick = { openExternal(ctx, file) }) { Text("Open with...") }
        }
        SelectionContainer { Text("Path: " + hit.path, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp)) }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (!file.exists()) Text("This file no longer exists. Re-run indexing to update the list.")
            else when (kind) {
                FileKind.IMAGE -> ImageView(file)
                FileKind.PDF -> PdfView(file)
                FileKind.TEXT, FileKind.HTML -> TextView(file)
                else -> Text("No built-in viewer for this file type. Tap Open with...")
            }
        }
    }
}

@Composable
private fun ImageView(file: File) {
    val bmp by produceState<Bitmap?>(null, file) {
        value = withContext(Dispatchers.IO) { BitmapUtil.decodeUpright(file.path, 2048) }
    }
    val b = bmp
    if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
    else CircularProgressIndicator()
}

@Composable
private fun TextView(file: File) {
    val text by produceState("Loading...", file) {
        value = withContext(Dispatchers.IO) {
            try { file.bufferedReader().use { readChars(it, Limits.TEXT_CHARS) } } catch (e: Exception) { "Cannot read this file." }
        }
    }
    SelectionContainer { Text(text, fontSize = 13.sp, modifier = Modifier.verticalScroll(rememberScrollState())) }
}

@Composable
private fun PdfView(file: File) {
    val mutex = remember { Mutex() }
    val holder = remember(file) {
        try {
            val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            Pair(PdfRenderer(pfd), pfd)
        } catch (e: Exception) {
            null
        }
    }
    DisposableEffect(holder) {
        onDispose {
            // Close only after any in-flight page render has finished (PdfRenderer is not thread safe).
            CoroutineScope(Dispatchers.IO).launch {
                mutex.withLock {
                    try { holder?.first?.close() } catch (e: Exception) { android.util.Log.w("PdfView", "close failed") }
                    try { holder?.second?.close() } catch (e: Exception) { android.util.Log.w("PdfView", "close failed") }
                }
            }
        }
    }
    if (holder == null) {
        Text("Cannot open this PDF here. Tap Open with...")
        return
    }
    val renderer = holder.first
    LazyColumn(Modifier.fillMaxSize()) {
        items(renderer.pageCount) { i ->
            val bmp by produceState<Bitmap?>(null, i) {
                value = withContext(Dispatchers.IO) {
                    mutex.withLock { try { BitmapUtil.renderPage(renderer, i, 1000) } catch (e: Exception) { null } }
                }
            }
            val b = bmp
            if (b != null) {
                Image(b.asImageBitmap(), null, Modifier.fillMaxWidth().padding(bottom = 6.dp), contentScale = ContentScale.FillWidth)
            } else {
                Box(Modifier.fillMaxWidth().heightIn(min = 240.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            }
        }
    }
}
