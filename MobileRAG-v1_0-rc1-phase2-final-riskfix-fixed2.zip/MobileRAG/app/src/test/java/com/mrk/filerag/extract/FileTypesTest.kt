package com.mrk.filerag.extract

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FileTypesTest {
    @Test fun kindsByExtension() {
        assertEquals(FileKind.IMAGE, FileTypes.kindOf("JPG"))
        assertEquals(FileKind.IMAGE, FileTypes.kindOf("heic"))
        assertEquals(FileKind.PDF, FileTypes.kindOf("pdf"))
        assertEquals(FileKind.WORD, FileTypes.kindOf("docx"))
        assertEquals(FileKind.SLIDES, FileTypes.kindOf("pptx"))
        assertEquals(FileKind.SHEET, FileTypes.kindOf("xlsx"))
        assertEquals(FileKind.HTML, FileTypes.kindOf("html"))
        assertEquals(FileKind.TEXT, FileTypes.kindOf("kt"))
        assertEquals(FileKind.OTHER, FileTypes.kindOf("mp4"))
    }

    @Test fun mimeTypes() {
        assertEquals("application/pdf", FileTypes.mimeOf("pdf"))
        assertEquals("text/markdown", FileTypes.mimeOf("md"))
        assertEquals("application/octet-stream", FileTypes.mimeOf("zzz"))
    }

    @Test fun binaryDetection() {
        val text = "hello world\n".toByteArray()
        assertFalse(FileTypes.looksBinary(text, text.size))
        val bin = byteArrayOf(1, 2, 0, 3)
        assertTrue(FileTypes.looksBinary(bin, bin.size))
        assertFalse(FileTypes.looksBinary(ByteArray(0), 0))
    }
}
