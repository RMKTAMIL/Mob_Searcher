package com.mrk.filerag.extract

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class OfficeTextTest {
    @Test fun wordParagraphsAndRuns() {
        val xml = "<w:p><w:r><w:t>Hello</w:t></w:r><w:r><w:t xml:space=\"preserve\"> World</w:t></w:r></w:p>" +
            "<w:p><w:r><w:t>Second</w:t></w:r></w:p><w:tab/>"
        assertEquals("Hello World\nSecond", OfficeText.wordText(xml).trim())
    }

    @Test fun slides() {
        val xml = "<a:p><a:r><a:t>Title</a:t></a:r></a:p><a:p><a:r><a:t>Point &amp; more</a:t></a:r></a:p>"
        assertEquals("Title\nPoint & more", OfficeText.slideText(xml).trim())
    }

    @Test fun sharedStringsAndSheetNames() {
        val xml = "<sst><si><t>Alpha</t></si><si><r><t>Be</t></r><r><t>ta</t></r></si></sst>"
        assertEquals("Alpha\nBeta", OfficeText.sharedStrings(xml).trim())
        assertEquals("Budget Plan", OfficeText.sheetNames("<sheets><sheet name=\"Budget\" sheetId=\"1\"/><sheet name=\"Plan\" sheetId=\"2\"/></sheets>"))
    }

    @Test fun htmlStripsScriptsAndTags() {
        val html = "<html><head><style>p{color:red}</style><script>var x=1;</script></head><body><p>Hi&nbsp;there</p><!-- c --></body></html>"
        val t = OfficeText.htmlText(html)
        assertEquals("Hi there", t)
        assertFalse(t.contains("color"))
    }

    @Test fun entities() {
        assertEquals("& A B <", OfficeText.decodeEntities("&amp; &#65; &#x42; &lt;"))
        assertEquals("&bogus;", OfficeText.decodeEntities("&bogus;"))
    }

    @Test fun coreMeta() {
        val xml = "<cp:coreProperties><dc:title>My Doc</dc:title><dc:creator>Ann</dc:creator></cp:coreProperties>"
        assertTrue(OfficeText.coreMeta(xml).contains("My Doc"))
        assertTrue(OfficeText.coreMeta(xml).contains("Ann"))
    }
}
