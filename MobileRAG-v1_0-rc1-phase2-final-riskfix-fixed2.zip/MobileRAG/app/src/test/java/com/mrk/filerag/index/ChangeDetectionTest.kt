package com.mrk.filerag.index

import com.mrk.filerag.data.Status
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ChangeDetectionTest {
    private val ok = FileState(100, 10, Status.OK, 0)

    @Test fun newFile() = assertTrue(ChangeDetection.needsWork(null, 100, 10, 3))
    @Test fun unchanged() = assertFalse(ChangeDetection.needsWork(ok, 100, 10, 3))
    @Test fun modifiedTime() = assertTrue(ChangeDetection.needsWork(ok, 101, 10, 3))
    @Test fun modifiedSize() = assertTrue(ChangeDetection.needsWork(ok, 100, 11, 3))
    @Test fun failedWithRetriesLeft() = assertTrue(ChangeDetection.needsWork(FileState(100, 10, Status.FAILED, 1), 100, 10, 3))
    @Test fun failedExhausted() = assertFalse(ChangeDetection.needsWork(FileState(100, 10, Status.FAILED, 3), 100, 10, 3))
    @Test fun skippedStaysSkipped() = assertFalse(ChangeDetection.needsWork(FileState(100, 10, Status.SKIPPED, 0), 100, 10, 3))
    @Test fun staleMarkerForcesWork() = assertTrue(ChangeDetection.needsWork(FileState(-1, 10, Status.OK, 0), 100, 10, 3))
}
