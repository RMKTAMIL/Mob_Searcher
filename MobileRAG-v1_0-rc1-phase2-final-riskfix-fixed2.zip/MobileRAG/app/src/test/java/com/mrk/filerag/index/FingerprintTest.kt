package com.mrk.filerag.index

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test
import java.io.File

class FingerprintTest {
    private fun temp(bytes: ByteArray): File = File.createTempFile("fpt", ".bin").also { it.deleteOnExit(); it.writeBytes(bytes) }

    @Test fun identicalContentSameFingerprint() {
        val data = ByteArray(300_000) { (it % 251).toByte() }
        val a = temp(data); val b = temp(data)
        assertEquals(Fingerprint.of(a, a.length()), Fingerprint.of(b, b.length()))
    }

    @Test fun differentTailDiffers() {
        val data = ByteArray(300_000) { (it % 251).toByte() }
        val other = data.copyOf().also { it[it.size - 1] = (it[it.size - 1] + 1).toByte() }
        val a = temp(data); val b = temp(other)
        assertNotEquals(Fingerprint.of(a, a.length()), Fingerprint.of(b, b.length()))
    }

    @Test fun smallFilesWork() {
        val a = temp("abc".toByteArray())
        assertEquals(40, Fingerprint.of(a, a.length()).length)
    }
}
