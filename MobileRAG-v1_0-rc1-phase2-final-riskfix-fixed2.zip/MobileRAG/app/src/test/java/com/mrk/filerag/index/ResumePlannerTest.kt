package com.mrk.filerag.index

import com.mrk.filerag.power.PauseReason
import com.mrk.filerag.power.PowerDecision
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ResumePlannerTest {
    private fun pause(r: PauseReason) = PowerDecision.Pause(r, r.name)

    @Test fun notChargingWaitsOnTheChargerConstraintWithoutPolling() {
        val p = ResumePlanner.plan(pause(PauseReason.NOT_CHARGING), false, 0, chargingRequired = true)!!
        assertTrue(p.requiresCharging)
        assertEquals(0L, p.delayMinutes)
    }

    @Test fun thermalPauseWaitsWithADelay() {
        val p = ResumePlanner.plan(pause(PauseReason.THERMAL), false, 0, chargingRequired = false)!!
        assertFalse(p.requiresCharging)
        assertEquals(15L, p.delayMinutes)
    }

    @Test fun chargingPreferenceKeepsTheChargerConstraintForEveryPause() {
        assertTrue(ResumePlanner.plan(pause(PauseReason.THERMAL), true, 0, chargingRequired = true)!!.requiresCharging)
        assertTrue(ResumePlanner.plan(pause(PauseReason.BATTERY_LOW), true, 0, chargingRequired = true)!!.requiresCharging)
    }

    @Test fun delayGrowsWhileNothingProgressesAndIsCapped() {
        val delays = (0 until ResumePlanner.MAX_IDLE_PAUSES).map {
            ResumePlanner.plan(pause(PauseReason.THERMAL), false, it, false)!!.delayMinutes
        }
        assertEquals(listOf(15L, 30L, 60L, 60L, 60L, 60L), delays)
    }

    @Test fun progressResetsTheIdleCounter() {
        val p = ResumePlanner.plan(pause(PauseReason.THERMAL), true, ResumePlanner.MAX_IDLE_PAUSES, false)
        assertNotNull(p)
        assertEquals(0, p!!.idlePauses)
        assertEquals(15L, p.delayMinutes)
    }

    @Test fun givesUpAfterTooManyPausesWithoutProgress() {
        assertNull(ResumePlanner.plan(pause(PauseReason.THERMAL), false, ResumePlanner.MAX_IDLE_PAUSES, false))
        assertNotNull(ResumePlanner.plan(pause(PauseReason.THERMAL), false, ResumePlanner.MAX_IDLE_PAUSES - 1, false))
    }

    @Test fun idleCounterIncrementsWithoutProgress() =
        assertEquals(3, ResumePlanner.plan(pause(PauseReason.BATTERY_LOW), false, 2, false)!!.idlePauses)

    @Test fun negativeStoredCounterIsTreatedAsZero() =
        assertEquals(1, ResumePlanner.plan(pause(PauseReason.THERMAL), false, -5, false)!!.idlePauses)
}
