package com.mrk.filerag.power

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PowerGateTest {
    private class FakeSource(var snap: PowerSnapshot) : PowerSource {
        var reads = 0
        override fun snapshot(): PowerSnapshot { reads++; return snap }
    }

    private val hot = PowerSnapshot(true, 90, ThermalLevel.SEVERE)
    private val ok = PowerSnapshot(true, 90, ThermalLevel.NORMAL)
    private val moderate = PowerSnapshot(true, 90, ThermalLevel.MODERATE)

    @Test fun pauseThenResumeWhenConditionsRecover() = runBlocking {
        val src = FakeSource(hot)
        val gate = PowerGate(src, { PowerConfig() }, { })
        assertTrue(gate.beforeBatch() is PowerDecision.Pause)
        src.snap = ok // the phone cooled down: the very next check allows a batch again
        assertTrue(gate.beforeBatch() is PowerDecision.Proceed)
    }

    @Test fun throttleWaitsBeforeTheBatch() = runBlocking {
        val waits = ArrayList<Long>()
        val gate = PowerGate(FakeSource(moderate), { PowerConfig(throttleMs = 1234) }, { waits.add(it) })
        val d = gate.beforeBatch()
        assertTrue(d is PowerDecision.Proceed)
        assertEquals(listOf(1234L), waits)
        assertEquals(0L, (d as PowerDecision.Proceed).throttleMs)
    }

    @Test fun normalThermalDoesNotWait() = runBlocking {
        val waits = ArrayList<Long>()
        PowerGate(FakeSource(ok), { PowerConfig() }, { waits.add(it) }).beforeBatch()
        assertTrue(waits.isEmpty())
    }

    @Test fun unplugDuringThrottleWaitPausesTheBatch() = runBlocking {
        val src = FakeSource(moderate)
        val gate = PowerGate(src, { PowerConfig() }, { src.snap = moderate.copy(charging = false) })
        val d = gate.beforeBatch()
        assertEquals(PauseReason.NOT_CHARGING, (d as PowerDecision.Pause).reason)
    }

    @Test fun cancellationDuringThrottleIsPromptAndPropagates() = runBlocking {
        val gate = PowerGate(FakeSource(moderate), { PowerConfig(throttleMs = 60_000) }) // real delay()
        val started = System.nanoTime()
        val job = async(Dispatchers.Default) { gate.beforeBatch() }
        delay(50)
        job.cancel()
        var cancelled = false
        try { job.await() } catch (e: CancellationException) { cancelled = true }
        assertTrue(cancelled)
        assertTrue("cancel must not wait out the throttle", (System.nanoTime() - started) / 1_000_000 < 5_000)
    }

    @Test fun configurationIsReadFreshForEveryBatch() = runBlocking {
        var cfg = PowerConfig(requireCharging = false, minBatteryPercent = 0)
        val src = FakeSource(PowerSnapshot(false, 50, ThermalLevel.NORMAL))
        val gate = PowerGate(src, { cfg }, { })
        assertTrue(gate.beforeBatch() is PowerDecision.Proceed)
        cfg = cfg.copy(requireCharging = true) // user switched "only while charging" on mid-run
        assertTrue(gate.beforeBatch() is PowerDecision.Pause)
    }

    @Test fun checkDoesNotSleep() {
        var slept = false
        val gate = PowerGate(FakeSource(moderate), { PowerConfig() }, { slept = true })
        assertTrue(gate.check() is PowerDecision.Proceed)
        assertFalse(slept)
    }
}
