package com.mrk.filerag.power

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PowerPolicyTest {
    private fun snap(charging: Boolean? = true, pct: Int? = 80, t: ThermalLevel = ThermalLevel.NORMAL) = PowerSnapshot(charging, pct, t)
    private val cfg = PowerConfig(requireCharging = true, minBatteryPercent = 20)

    private fun pauseReason(d: PowerDecision) = (d as PowerDecision.Pause).reason

    // ---- charging ----
    @Test fun chargingRequiredAndCharging() = assertTrue(PowerPolicy.evaluate(snap(charging = true), cfg) is PowerDecision.Proceed)

    @Test fun chargingRequiredButOnBatteryPauses() =
        assertEquals(PauseReason.NOT_CHARGING, pauseReason(PowerPolicy.evaluate(snap(charging = false), cfg)))

    @Test fun chargingRequiredAndStateUnreadablePauses() =
        assertEquals(PauseReason.NOT_CHARGING, pauseReason(PowerPolicy.evaluate(snap(charging = null), cfg)))

    @Test fun chargingNotRequiredRunsOnBatteryAboveFloor() =
        assertTrue(PowerPolicy.evaluate(snap(charging = false, pct = 50), cfg.copy(requireCharging = false)) is PowerDecision.Proceed)

    // ---- battery threshold ----
    @Test fun batteryBelowThresholdPauses() =
        assertEquals(PauseReason.BATTERY_LOW, pauseReason(PowerPolicy.evaluate(snap(charging = false, pct = 19), cfg.copy(requireCharging = false))))

    @Test fun batteryAtThresholdProceeds() =
        assertTrue(PowerPolicy.evaluate(snap(charging = false, pct = 20), cfg.copy(requireCharging = false)) is PowerDecision.Proceed)

    @Test fun batteryAboveThresholdProceeds() =
        assertTrue(PowerPolicy.evaluate(snap(charging = false, pct = 21), cfg.copy(requireCharging = false)) is PowerDecision.Proceed)

    @Test fun lowBatteryIgnoredWhileCharging() = assertTrue(PowerPolicy.evaluate(snap(charging = true, pct = 3), cfg) is PowerDecision.Proceed)

    @Test fun unknownBatteryLevelOnBatteryPauses() =
        assertEquals(PauseReason.BATTERY_UNKNOWN, pauseReason(PowerPolicy.evaluate(snap(charging = false, pct = null), cfg.copy(requireCharging = false))))

    @Test fun zeroFloorDisablesBatteryCheck() =
        assertTrue(PowerPolicy.evaluate(snap(charging = false, pct = null), cfg.copy(requireCharging = false, minBatteryPercent = 0)) is PowerDecision.Proceed)

    // ---- thermal ----
    @Test fun normalThermalContinuesWithoutDelay() =
        assertEquals(PowerDecision.Proceed(0L, ThermalLevel.NORMAL), PowerPolicy.evaluate(snap(t = ThermalLevel.NORMAL), cfg))

    @Test fun moderateThermalThrottlesByDefault() =
        assertEquals(PowerDecision.Proceed(cfg.throttleMs, ThermalLevel.MODERATE), PowerPolicy.evaluate(snap(t = ThermalLevel.MODERATE), cfg))

    @Test fun severeThermalPausesByDefault() =
        assertEquals(PauseReason.THERMAL, pauseReason(PowerPolicy.evaluate(snap(t = ThermalLevel.SEVERE), cfg)))

    @Test fun criticalThermalPausesByDefault() =
        assertEquals(PauseReason.THERMAL, pauseReason(PowerPolicy.evaluate(snap(t = ThermalLevel.CRITICAL), cfg)))

    @Test fun thermalBehaviourIsConfigurable() {
        val lenient = cfg.copy(thermal = PowerConfig.DEFAULT_THERMAL + (ThermalLevel.SEVERE to ThermalAction.THROTTLE) + (ThermalLevel.MODERATE to ThermalAction.CONTINUE))
        assertEquals(PowerDecision.Proceed(0L, ThermalLevel.MODERATE), PowerPolicy.evaluate(snap(t = ThermalLevel.MODERATE), lenient))
        assertEquals(PowerDecision.Proceed(cfg.throttleMs, ThermalLevel.SEVERE), PowerPolicy.evaluate(snap(t = ThermalLevel.SEVERE), lenient))
        val strict = cfg.copy(thermal = PowerConfig.DEFAULT_THERMAL + (ThermalLevel.MODERATE to ThermalAction.PAUSE))
        assertEquals(PauseReason.THERMAL, pauseReason(PowerPolicy.evaluate(snap(t = ThermalLevel.MODERATE), strict)))
    }

    // ---- missing thermal information ----
    @Test fun unknownThermalIsNotReportedAsNormalAndIsThrottled() {
        val d = PowerPolicy.evaluate(snap(t = ThermalLevel.UNKNOWN), cfg) as PowerDecision.Proceed
        assertEquals(ThermalLevel.UNKNOWN, d.thermal)
        assertEquals(cfg.throttleMs, d.throttleMs)
    }

    @Test fun missingStatusMapsToUnknownNotNormal() {
        assertEquals(ThermalLevel.UNKNOWN, ThermalLevel.fromAndroidStatus(null))
        assertEquals(ThermalLevel.UNKNOWN, ThermalLevel.fromAndroidStatus(-1))
        assertEquals(ThermalLevel.UNKNOWN, ThermalLevel.fromAndroidStatus(99))
    }

    @Test fun androidStatusMapping() {
        assertEquals(ThermalLevel.NORMAL, ThermalLevel.fromAndroidStatus(0))   // NONE
        assertEquals(ThermalLevel.NORMAL, ThermalLevel.fromAndroidStatus(1))   // LIGHT
        assertEquals(ThermalLevel.MODERATE, ThermalLevel.fromAndroidStatus(2))
        assertEquals(ThermalLevel.SEVERE, ThermalLevel.fromAndroidStatus(3))
        assertEquals(ThermalLevel.CRITICAL, ThermalLevel.fromAndroidStatus(4)) // CRITICAL
        assertEquals(ThermalLevel.CRITICAL, ThermalLevel.fromAndroidStatus(5)) // EMERGENCY
        assertEquals(ThermalLevel.CRITICAL, ThermalLevel.fromAndroidStatus(6)) // SHUTDOWN
    }

    @Test fun chargingCheckComesBeforeThermal() =
        assertEquals(PauseReason.NOT_CHARGING, pauseReason(PowerPolicy.evaluate(snap(charging = false, t = ThermalLevel.CRITICAL), cfg)))
}
