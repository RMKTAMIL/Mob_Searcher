package com.mrk.filerag.search

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.nio.ByteBuffer
import java.nio.ByteOrder

class Bm25Test {
    // matchinfo 'pcnalx' for 1 phrase, 4 columns, n=100 rows.
    private fun info(tf: IntArray, rowsWithHit: Int = 5, len: IntArray = intArrayOf(10, 100, 5, 5), avg: IntArray = intArrayOf(10, 100, 5, 5)): IntArray {
        val x = IntArray(12)
        for (c in 0 until 4) { x[3 * c] = tf[c]; x[3 * c + 1] = tf[c] * rowsWithHit; x[3 * c + 2] = if (tf[c] > 0) rowsWithHit else 0 }
        return intArrayOf(1, 4, 100) + avg + len + x
    }

    private val w = Ranking.COLUMN_WEIGHTS

    @Test fun noHitsScoresZero() = assertEquals(0.0, Bm25.score(info(intArrayOf(0, 0, 0, 0)), w), 1e-12)

    @Test fun moreOccurrencesScoreHigher() {
        val one = Bm25.score(info(intArrayOf(0, 1, 0, 0)), w)
        val three = Bm25.score(info(intArrayOf(0, 3, 0, 0)), w)
        assertTrue(three > one)
    }

    @Test fun nameHitBeatsContentHitWhenEqual() {
        val name = Bm25.score(info(intArrayOf(1, 0, 0, 0), len = intArrayOf(10, 10, 5, 5), avg = intArrayOf(10, 10, 5, 5)), w)
        val content = Bm25.score(info(intArrayOf(0, 1, 0, 0), len = intArrayOf(10, 10, 5, 5), avg = intArrayOf(10, 10, 5, 5)), w)
        assertTrue(name > content)
    }

    @Test fun rarerTermScoresHigher() {
        val rare = Bm25.score(info(intArrayOf(0, 1, 0, 0), rowsWithHit = 2), w)
        val common = Bm25.score(info(intArrayOf(0, 1, 0, 0), rowsWithHit = 60), w)
        assertTrue(rare > common)
    }

    @Test fun malformedInfoIsSafe() {
        assertEquals(0.0, Bm25.score(intArrayOf(1), w), 0.0)
        assertEquals(0.0, Bm25.score(intArrayOf(1, 4, 100, 1, 2), w), 0.0)
    }

    @Test fun decodeRoundTrip() {
        val ints = intArrayOf(1, 4, 100, 7)
        val bb = ByteBuffer.allocate(16).order(ByteOrder.nativeOrder())
        ints.forEach { bb.putInt(it) }
        assertEquals(ints.toList(), Bm25.decode(bb.array()).toList())
    }
}
