package com.mrk.filerag.search

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FilterSqlTest {
    @Test fun defaultsProduceNothing() {
        val args = ArrayList<String>()
        assertEquals("", FilterSql.where(Filters(), args))
        assertTrue(args.isEmpty())
    }

    @Test fun kindDateSize() {
        val args = ArrayList<String>()
        val sql = FilterSql.where(Filters(kind = Kind.PDF, date = DateRange.WEEK, size = SizeRange.MEDIUM), args, nowMs = 10 * 86_400_000L)
        assertTrue(sql.contains("files.path LIKE '%.pdf'"))
        assertTrue(sql.contains("files.mtime >= " + 3 * 86_400_000L))
        assertTrue(sql.contains("files.size >= 1048576"))
        assertTrue(sql.contains("files.size < 10485760"))
        assertTrue(args.isEmpty())
    }

    @Test fun folderAndSourceBindPrefixes() {
        val args = ArrayList<String>()
        val src = AppSource("WA", listOf("/s/a", "/s/b"))
        val sql = FilterSql.where(Filters(folder = "/x/y/", source = src), args)
        assertEquals(listOf("/x/y/", "/s/a/", "/s/b/"), args)
        assertEquals(3, sql.count { it == '?' })
        assertTrue(sql.contains(" OR "))
    }

    @Test fun orderByIsDeterministic() {
        SortBy.values().forEach { assertTrue(FilterSql.orderBy(it).endsWith("files.id ASC")) }
    }
}
