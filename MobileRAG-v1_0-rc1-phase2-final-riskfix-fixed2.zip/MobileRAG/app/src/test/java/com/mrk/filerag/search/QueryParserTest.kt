package com.mrk.filerag.search

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class QueryParserTest {
    @Test fun termsAndPhrases() {
        val q = QueryParser.parse("Free fire \"my account\"")
        assertEquals(listOf("free", "fire"), q.terms)
        assertEquals(listOf(listOf("my", "account")), q.phrases)
        assertEquals("\"my account\" free* fire*", QueryParser.matchAnd(q))
        assertEquals("\"my account\" OR free* OR fire*", QueryParser.matchOr(q))
    }

    @Test fun operatorsCannotLeakIn() {
        val q = QueryParser.parse("a-b; DROP TABLE x* OR NEAR(\"y\")")
        // only letters/digits survive; single characters are dropped
        assertTrue(q.terms.all { t -> t.all { it.isLetterOrDigit() } })
        assertTrue(QueryParser.matchAnd(q)!!.none { it == ';' || it == '(' || it == ')' })
    }

    @Test fun phraseBoostOnlyForPlainMultiTerm() {
        assertEquals("\"free fire\"", QueryParser.phraseBoost(QueryParser.parse("free fire")))
        assertNull(QueryParser.phraseBoost(QueryParser.parse("free")))
        assertNull(QueryParser.phraseBoost(QueryParser.parse("\"free fire\" x1")))
    }

    @Test fun emptyQuery() {
        assertTrue(QueryParser.parse("  !! ").isEmpty)
        assertNull(QueryParser.matchAnd(QueryParser.parse("")))
    }

    @Test fun unicodeLettersKept() {
        assertEquals(listOf("café", "மொழி"), QueryParser.parse("Café மொழி").terms)
    }
}
