package com.mrk.filerag.search

import org.junit.Assert.assertEquals
import org.junit.Test

class RankingTest {
    @Test fun orderIsPhraseThenBm25ThenRecencyThenId() {
        val rows = listOf(
            Ranking.Row(1, 5.0, false, 100),
            Ranking.Row(2, 1.0, true, 100),
            Ranking.Row(3, 5.0, false, 200),
            Ranking.Row(4, 5.0, false, 200)
        )
        assertEquals(listOf(2L, 3L, 4L, 1L), Ranking.order(rows).map { it.id })
    }

    @Test fun rrfFavoursItemsInBothLists() {
        assertEquals(listOf(1L, 2L, 3L), Fusion.rrf(listOf(listOf(1L, 2L), listOf(1L, 3L))))
    }

    @Test fun rrfEmpty() = assertEquals(emptyList<Long>(), Fusion.rrf(emptyList()))
}
