package com.mrk.filerag.semantic

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ChunkerTest {
    private val words = (0 until 500).joinToString(" ") { "w$it" }

    @Test fun overlappingWindows() {
        val c = Chunker.chunk(words, maxWords = 180, overlap = 30, maxChunks = 24)
        assertTrue(c.size >= 3)
        assertTrue(c[0].startsWith("w0 "))
        assertTrue(c[1].startsWith("w150 "))
        assertTrue(c.last().endsWith("w499"))
    }

    @Test fun boundedByMaxChunks() = assertEquals(2, Chunker.chunk(words, 50, 10, 2).size)
    @Test fun emptyText() = assertTrue(Chunker.chunk("  \n ").isEmpty())
    @Test fun shortTextSingleChunk() = assertEquals(listOf("hello world"), Chunker.chunk("hello   world"))
}
