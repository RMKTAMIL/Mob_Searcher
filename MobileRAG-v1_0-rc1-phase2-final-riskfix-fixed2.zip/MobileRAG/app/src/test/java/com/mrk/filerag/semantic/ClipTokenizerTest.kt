package com.mrk.filerag.semantic

import org.junit.Assert.assertEquals
import org.junit.Test

class ClipTokenizerTest {
    // Tiny synthetic vocabulary: not the real CLIP vocab (see docs/MODELS.md for real-model checks).
    private val vocab = mapOf(
        "<|startoftext|>" to 100, "<|endoftext|>" to 101,
        "a</w>" to 1, "b</w>" to 2, "ab</w>" to 3, "c</w>" to 4
    )
    private val merges = listOf(Pair("a", "b</w>"))

    @Test fun mergesAndPads() {
        val t = ClipTokenizer(vocab, merges, contextLen = 8)
        assertEquals(listOf(100L, 3L, 4L, 101L, 0L, 0L, 0L, 0L), t.encode("AB  c").toList())
    }

    @Test fun truncatesButKeepsEot() {
        val t = ClipTokenizer(vocab, merges, contextLen = 4)
        assertEquals(listOf(100L, 3L, 4L, 101L), t.encode("ab c a b c").toList())
    }

    @Test fun byteEncoderMatchesReference() {
        val m = ClipTokenizer.bytesToUnicode()
        assertEquals(256, m.size)
        assertEquals('a', m['a'.code])
        assertEquals('Ġ', m[32])
    }

    @Test fun mergesParsing() {
        assertEquals(listOf(Pair("a", "b</w>")), ClipTokenizer.parseMerges("#version: 0.2\na b</w>\n\n"))
    }
}
