package com.mrk.filerag.semantic

import kotlinx.coroutines.CancellationException
import org.junit.Assert.*
import org.junit.Test

class ImageBatchPlannerTest {
    @Test fun mapsOutputsToInputOrder() {
        val files = listOf("a", "b", "c", "d")
        val vectors = ImageBatchPlanner.infer(files, { it.map { name -> "vec-$name" } }, { "vec-$it" })
        assertEquals(listOf("vec-a", "vec-b", "vec-c", "vec-d"), vectors)
    }

    @Test fun handlesIncompleteFinalBatch() {
        assertEquals(listOf(listOf(1, 2, 3, 4), listOf(5, 6)),
            ImageBatchPlanner.chunks((1..6).toList(), 4))
    }

    @Test fun ordinaryBatchFailureRetriesEveryItem() {
        val seen = ArrayList<Int>()
        val result = ImageBatchPlanner.infer(listOf(1, 2, 3),
            { throw IllegalStateException("ordinary inference error") },
            { seen.add(it); it * 10 })
        assertEquals(listOf(10, 20, 30), result)
        assertEquals(listOf(1, 2, 3), seen)
    }

    @Test fun cancellationPropagatesWithoutIndividualRetry() {
        val cancellation = CancellationException("cancelled")
        var individualCalls = 0
        try {
            ImageBatchPlanner.infer(listOf(1, 2), { throw cancellation }, { individualCalls++; it })
            fail("cancellation must propagate")
        } catch (actual: CancellationException) {
            assertSame(cancellation, actual)
        }
        assertEquals(0, individualCalls)
    }

    @Test fun outOfMemoryPropagatesWithoutIndividualRetry() {
        var individualCalls = 0
        try {
            ImageBatchPlanner.infer(listOf(1, 2), { throw OutOfMemoryError("test") },
                { individualCalls++; it })
            fail("OOM must propagate to resource owner")
        } catch (_: OutOfMemoryError) { }
        assertEquals(0, individualCalls)
    }

    @Test fun rejectsUnsupportedBatchSize() {
        try { ImageBatchPlanner.chunks(listOf(1), 3); fail("expected IllegalArgumentException") }
        catch (_: IllegalArgumentException) { }
    }
}
