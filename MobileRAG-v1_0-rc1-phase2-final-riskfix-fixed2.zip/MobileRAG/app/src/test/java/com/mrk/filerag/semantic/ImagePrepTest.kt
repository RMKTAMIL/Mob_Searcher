package com.mrk.filerag.semantic

import org.junit.Assert.assertEquals
import org.junit.Test

class ImagePrepTest {
    @Test fun resizeKeepsAspect() {
        assertEquals(Pair(448, 224), ImagePrep.resizedDims(400, 200, 224))
        assertEquals(Pair(224, 448), ImagePrep.resizedDims(200, 400, 224))
        assertEquals(Pair(224, 224), ImagePrep.resizedDims(500, 500, 224))
    }

    @Test fun centerCrop() = assertEquals(Pair(112, 0), ImagePrep.centerCropOrigin(448, 224, 224))

    @Test fun chwNormalization() {
        val px = intArrayOf(0xFFFF0000.toInt(), 0xFF00FF00.toInt(), 0xFF0000FF.toInt(), 0xFFFFFFFF.toInt())
        val out = ImagePrep.toChw(px, 2, floatArrayOf(0f, 0f, 0f), floatArrayOf(1f, 1f, 1f))
        assertEquals(12, out.size)
        assertEquals(1f, out[0], 1e-6f)   // R of pixel 0
        assertEquals(0f, out[4], 1e-6f)   // G of pixel 0
        assertEquals(1f, out[5], 1e-6f)   // G of pixel 1
        assertEquals(1f, out[10], 1e-6f)  // B of pixel 2
    }
}
