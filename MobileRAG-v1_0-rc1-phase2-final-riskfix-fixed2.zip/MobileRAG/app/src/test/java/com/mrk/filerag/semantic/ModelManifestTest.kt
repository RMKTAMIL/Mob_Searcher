package com.mrk.filerag.semantic

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class ModelManifestTest {
    private val hash = "a".repeat(64)
    private fun sbert(extra: String = "", model: String = "model.onnx") = """
        {"id":"minilm","version":"1","kind":"sbert","dim":384,
         "files":{"model":"$model","vocab":"vocab.txt"},
         "sha256":{"$model":"$hash","vocab.txt":"$hash"}$extra}
    """.trimIndent()

    @Test fun parsesValidManifest() {
        val m = ModelManifest.parse(sbert(",\"max_len\":256,\"query_prefix\":\"query: \""))
        assertEquals("minilm@1", m.key)
        assertEquals(384, m.dim)
        assertEquals(256, m.maxLen)
        assertEquals("query: ", m.queryPrefix)
    }

    @Test fun rejectsPathTraversalInFileNames() {
        assertThrows(Exception::class.java) { ModelManifest.parse(sbert(model = "../evil.onnx")) }
    }

    @Test fun rejectsMissingHash() {
        val bad = """{"id":"x","version":"1","kind":"sbert","dim":8,"files":{"model":"m.onnx","vocab":"v.txt"},"sha256":{"m.onnx":"$hash"}}"""
        assertThrows(Exception::class.java) { ModelManifest.parse(bad) }
    }

    @Test fun rejectsUnknownKindAndBadId() {
        assertThrows(Exception::class.java) { ModelManifest.parse(sbert().replace("sbert", "llm")) }
        assertThrows(Exception::class.java) { ModelManifest.parse(sbert().replace("minilm", "a/b")) }
    }

    @Test fun clipRequiresAllFiles() {
        val clip = """{"id":"clip","version":"1","kind":"clip","dim":512,"files":{"image":"i.onnx","text":"t.onnx","vocab":"v.json"},
            "sha256":{"i.onnx":"$hash","t.onnx":"$hash","v.json":"$hash"}}"""
        assertThrows(Exception::class.java) { ModelManifest.parse(clip) }
    }
}
