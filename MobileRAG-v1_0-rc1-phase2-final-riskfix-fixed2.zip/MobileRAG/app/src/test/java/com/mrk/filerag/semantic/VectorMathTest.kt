package com.mrk.filerag.semantic

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.sqrt
import kotlin.random.Random

class VectorMathTest {
    private fun randomUnit(dim: Int, seed: Int): FloatArray {
        val r = Random(seed)
        return VectorMath.l2Normalize(FloatArray(dim) { r.nextFloat() * 2 - 1 })
    }

    @Test fun normalizeGivesUnitLength() {
        val v = randomUnit(384, 1)
        assertEquals(1.0, sqrt(v.sumOf { it.toDouble() * it }), 1e-5)
    }

    @Test fun int8QuantizationKeepsCosine() {
        val a = randomUnit(384, 2)
        val b = randomUnit(384, 3)
        val (qa, sa) = VectorMath.quantize(a)
        val exact = VectorMath.cosine(a, b)
        val approx = VectorMath.dot(b, qa, sa)
        assertEquals(exact.toDouble(), approx.toDouble(), 0.01)
        val self = VectorMath.dot(a, qa, sa)
        assertTrue(self > 0.999f)
    }

    @Test fun meanPoolRespectsMask() {
        val hidden = arrayOf(floatArrayOf(1f, 1f), floatArrayOf(3f, 3f), floatArrayOf(100f, 100f))
        val pooled = VectorMath.meanPool(hidden, longArrayOf(1, 1, 0))
        assertEquals(2f, pooled[0], 1e-6f)
    }

    @Test fun zeroVectorIsSafe() {
        assertEquals(0f, VectorMath.l2Normalize(FloatArray(4))[0], 0f)
        val (q, s) = VectorMath.quantize(FloatArray(4))
        assertEquals(0, q[0].toInt()); assertEquals(1f, s, 0f)
    }
}
