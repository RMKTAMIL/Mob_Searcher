package com.mrk.filerag.semantic

import org.junit.Assert.assertEquals
import org.junit.Test

class WordPieceTokenizerTest {
    private val vocab = listOf("[PAD]", "[UNK]", "[CLS]", "[SEP]", "hello", ",", "world", "!", "un", "##want", "##ed", "cafe")
        .withIndex().associate { it.value to it.index }
    private val tok = WordPieceTokenizer(vocab)

    @Test fun basicSentence() {
        val e = tok.encode("Hello, world!", 16)
        assertEquals(listOf(2L, 4L, 5L, 6L, 7L, 3L), e.ids.toList())
        assertEquals(List(6) { 1L }, e.mask.toList())
    }

    @Test fun subwords() = assertEquals(listOf(8, 9, 10), tok.wordPiece("unwanted"))
    @Test fun unknownWord() = assertEquals(listOf(1), tok.wordPiece("xyzzy"))
    @Test fun accentsStripped() = assertEquals(listOf(2L, 11L, 3L), tok.encode("Café", 8).ids.toList())

    @Test fun truncationKeepsSep() {
        val e = tok.encode("hello hello hello hello hello", 4)
        assertEquals(4, e.ids.size)
        assertEquals(3L, e.ids.last())
        assertEquals(2L, e.ids.first())
    }
}
