# Verifying "works offline" (NOT YET PERFORMED)

Do not describe the app as verified-offline until this is done and the results are recorded below.

1. Install the APK. Models: import them (provisioning needs no network on the phone).
2. Static checks: Settings > Privacy must say "Network permission: not declared". On a computer:
   `adb shell dumpsys package com.mrk.filerag | grep -i internet` must print nothing;
   `aapt2 dump permissions app-debug.apk` must not list INTERNET (CI checks this too).
3. Turn on airplane mode, then switch Wi-Fi and Bluetooth off.
4. Index files (photos, PDFs, Office files), run semantic indexing, search by keyword, phrase, filters and meaning.
5. Inspect traffic anyway: `adb shell dumpsys netstats detail | grep -A6 "uid=$(adb shell pm list packages -U com.mrk.filerag | sed 's/.*uid://')"`
   counters must not grow; optionally capture with a VPN-based capture app while Wi-Fi is on and confirm zero packets.
6. Repeat with the phone's internet ON to confirm behaviour is identical.

| Date | Phone / Android | Result | Notes |
|---|---|---|---|
| (none yet) | | | |
