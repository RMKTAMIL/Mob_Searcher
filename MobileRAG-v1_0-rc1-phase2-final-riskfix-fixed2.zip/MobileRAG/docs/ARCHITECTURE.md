# Architecture (1.0.0-rc1)

```
ui/            Compose screens: Home (search), Index (dashboard), Settings, Viewer
search/        Query parsing, FilterSql, BM25 + ranking, KeywordRetriever, paged SearchSession, RRF fusion
semantic/      ModelStore/Manager (load, unload, memory guard), ONNX embedders, tokenizers,
               SemanticIndexer (resumable), SemanticRetriever, Benchmark
extract/       FileTypes, per-format extractors, ML Kit (bundled), limits
index/         Indexer pipeline, change detection, fingerprint, WorkManager worker/scheduler
data/          Db (schema + migrations), IndexRepository, EmbeddingRepository, HistoryStore
settings/      Prefs, app-folder presets
files/         Storage access helpers, FileProvider-safe external open
```
Pure Kotlin (no Android imports, covered by JVM tests): FileTypes, OfficeText, ChangeDetection, Fingerprint, QueryParser,
Bm25, Ranking/Fusion, FilterSql, VectorMath, Chunker, WordPiece/Clip tokenizers, ImagePrep, ModelManifest.

## Indexing
`produce` (walk, skip unchanged by mtime+size, skip failed-and-exhausted) -> `N workers` (1-4, extraction in parallel)
-> one `writer` committing batches of 20 in a single transaction. Cancellation commits finished work. After a complete
run: delete rows for vanished files, prune outside chosen folders, FTS `optimize` after large runs.
A run that is stopped by Android (WorkManager can be delayed, stopped, or killed) resumes by running again; nothing is
assumed to complete. Only one run at a time (process-wide lock). Non-expedited background runs have OS time limits.

## Database (schema v2)
`files(id, path UNIQUE, mtime, size, mime, status, attempts, error, indexed_at, fp, width, height)`,
`docs_fts` FTS4 (name, content, labels, ocr; porter), `embeddings(file_id, model_key, chunk, dim, scale, vec)`,
`embed_state(file_id, model_key, status, attempts, error, updated_at)`, `search_history`.
Foreign keys with ON DELETE CASCADE tie embeddings to files. FTS tables cannot carry foreign keys, so rows are kept in
sync in the same transaction and orphans are swept after each run.
Migration v1->v2 (v0.1-v0.3 databases) is non-destructive: columns are added, FTS text is copied, never discarded;
the old database file is also copied to `rag.db.v1.bak` before the first open. FTS4 was kept (FTS5 is not available on
all supported Android versions; no benchmark was run to justify switching).

## Search
Query -> safe FTS expression (letters/digits only, prefix on terms, quoted phrases). Keyword retriever: BM25 over
matchinfo (column weights name 2, others 1; k1 1.2, b 0.75 are the standard defaults and are untuned), exact-phrase
matches first, then BM25, recency, id. Semantic retriever (optional): cosine over int8 vectors. When both return
results they are merged with reciprocal rank fusion. A failing retriever never breaks the other.
Semantic retrieval applies to the "Best match" sort; other sorts are SQL-ordered keyword searches.

## On-device AI (non-negotiable constraints)
All inference is ONNX Runtime on the CPU inside the app process; ML Kit models are bundled. No INTERNET permission is
declared (CI fails if it appears). Models are provisioned by importing a folder (SHA-256 verified), never downloaded
by the app. Model versions are part of every embedding's key (`id@version`): selecting a new version makes
`SemanticIndexer` re-embed in the background (resumable); old embeddings stay until the user deletes them.
Duplicate files reuse vectors. Models load on demand, unload after 45 s idle or on `onTrimMemory`, and are refused when
free RAM is below 1.5x the model's declared estimate; search then falls back to keywords + OCR + labels.
Vector search is an exact brute-force scan streamed from SQLite (no ANN index): fine for tens of thousands of vectors,
to be benchmarked (Index > Benchmark) before relying on it at 100k+.

## Permissions and trade-offs
- `MANAGE_EXTERNAL_STORAGE`: needed to walk arbitrary folders by path (WhatsApp/Telegram media, any folder) with
  fast traversal, plain `File` I/O for PDFBox/ML Kit/ExifInterface, and real paths in results. Storage Access Framework
  would avoid the broad permission but is much slower for tree walks, has no real paths, and would need a rewrite of
  extraction and path display. Mitigations: no network permission, app-private database, no backups, narrow
  FileProvider, index only the folders you choose.
- `FOREGROUND_SERVICE(_DATA_SYNC)`, `POST_NOTIFICATIONS`: progress notification while indexing.
- No `INTERNET`, no analytics, no crash reporting.

## Known limits
Not compiled or run by the author; first CI build may need fixes. HEIC needs Android 9+. CLIP preprocessing uses the
platform bilinear resize (reference models use bicubic) and omits the optional ftfy text cleanup, so embeddings differ
slightly from reference implementations. `min_score` cut-offs are uncalibrated defaults.
