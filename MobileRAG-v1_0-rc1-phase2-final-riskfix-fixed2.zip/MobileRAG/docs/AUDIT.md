# Engineering audit of v0.3 (Stage 1)

Method: read every source file, the manifest, Gradle files, SQL, the FileProvider config and the workflow.
Nothing was executed (no Android SDK in the authoring environment), so runtime claims below are from reading code.

| # | Finding | Impact | Fix in 1.0.0-rc1 |
|---|---|---|---|
| 1 | Indexing ran in the Compose scope | Died with the activity; not resumable except by mtime comparison | WorkManager `IndexWorker`, foreground notification, resumable by construction |
| 2 | `catch (e: Throwable) { "" }` in extraction | Failed files were stored as "indexed, empty" and never retried; errors invisible | Typed `ExtractResult`; status/attempts/error columns; retry up to 3x; failed-files list |
| 3 | One transaction + one query per file, single-threaded | Slow indexing; DB lock churn | Bounded producer/worker/writer pipeline, batched transactions |
| 4 | Search loaded `substr(content,1,20000)` for up to 400-600 rows and scored in Kotlin with arbitrary constants | Memory spikes; hard recall cap; unprincipled ranking | BM25 from FTS4 `matchinfo`, ids ranked once, details loaded per page, cap 20k with a visible "broad query" notice |
| 5 | OR semantics for every query; no phrases | Low precision | AND first, OR fallback, quoted phrases, exact-phrase boost |
| 6 | No pagination | All results in memory | Paged sessions (30/page), SQL ORDER BY + OFFSET for other sorts |
| 7 | Rollback-journal DB (no WAL), DB opened on main thread, several `Db` instances | Search stalls while indexing; jank | WAL, singleton, all DB work off the main thread |
| 8 | Labels + OCR merged in one column | Cannot weight or search separately; no metadata | Columns name/content/labels/ocr, dimensions, EXIF date/camera (no GPS), EXIF rotation applied |
| 9 | DOCX via tag stripping; no PPTX/XLSX/HTML; no binary detection | Garbage text, missing formats | Modular extractors, entity decoding, size caps, binary detection |
| 10 | FileProvider `root-path` | Whole filesystem addressable via the provider | `external-path` only; other volumes copied to cache for external open |
| 11 | INTERNET may be merged in from libraries | Cannot claim offline | `tools:node="remove"` + CI check on the built APK + in-app static check |
| 12 | PdfRenderer closed while a page render could be in flight | Possible crash | Close under the render mutex |
| 13 | Identical files (e.g. WhatsApp copies) re-OCRed | Wasted battery | Content fingerprint reuse for extraction and embeddings |
| 14 | No tests, no test step in CI | Regressions invisible | 14 JVM test classes + 4 instrumented classes (written, NOT yet run) |
| 15 | `debug.keystore` committed | A known debug key signs your builds | Kept deliberately so updates install over each other; it is a public debug key, not a secret. Release signing uses CI secrets only. Remove the file and use a secret if you prefer. |

Not changed (and why): storage access still uses `MANAGE_EXTERNAL_STORAGE` and file paths; see ARCHITECTURE.md.
