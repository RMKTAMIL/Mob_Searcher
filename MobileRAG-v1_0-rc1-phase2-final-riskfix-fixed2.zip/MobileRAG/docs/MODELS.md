# On-device models: evaluation, provisioning, storage

Honest status: **none of this has been run on a device.** The authoring environment could not download models or run
Android. Sizes and names below are from memory and must be confirmed with `tools/make_model_pack.py`, which prints
real sizes and hashes. Benchmark results must come from Index > Benchmark on your own phone.

## Candidates considered
| Role | Model | Notes (to verify) |
|---|---|---|
| Sentence embeddings | all-MiniLM-L6-v2, int8 ONNX (22M params, 384-d) | **Default.** Smallest practical option, English-centric, BERT WordPiece tokenizer (implemented), Apache-2.0. Roughly 20-25 MB quantized. |
| Sentence embeddings | bge-small-en-v1.5 (33M, 384-d) | Better retrieval quality, needs a query prefix (supported via `query_prefix`). |
| Sentence embeddings | multilingual MiniLM / e5-small multilingual (~118M) | Larger (100+ MB). Check that YOUR languages are covered; the paraphrase-multilingual list does not obviously include Tamil. |
| Sentence embeddings | EmbeddingGemma (~300M) | Multilingual, but heavy for a background indexer and has its own license terms. Not first choice for 4-6 GB phones. |
| Image-text | OpenAI CLIP ViT-B/32, int8 ONNX towers (512-d) | **Default.** MIT license, BPE tokenizer (implemented). Image tower roughly 90 MB, text tower roughly 60 MB quantized. Image embedding is the expensive step. |
| Image-text | MobileCLIP S0/S1/S2 | Designed for phones (faster, smaller). Check weight license and find a trustworthy ONNX export; preprocessing differs (set `image_size`, `mean`, `std` in model.json). Worth benchmarking against ViT-B/32. |
| Image-text | SigLIP base | Better quality, larger and slower; different text handling (not supported by the bundled tokenizer). |

Android compatibility reasoning (not a substitute for testing): ONNX Runtime Android supports API 24+ (app minSdk 26),
runs int8 quantized models on the CPU provider, and ships arm64-v8a/x86_64 libraries (the only ABIs built). The APK grows
by tens of MB for the runtime. Check each model loads and returns the manifest `dim` on your phone before indexing.

## Provision (offline phone)
1. On a computer with internet: `python tools/make_model_pack.py sbert ./packs/minilm` and `... clip ./packs/clip`.
2. Copy the pack folders to the phone (USB, any location).
3. App: Settings > Semantic search > Import model pack > pick the folder. The app copies it to private storage and
   verifies every SHA-256. Press Use, enable semantic search, then Index > Semantic only.

Storage: the model files (see above) are stored once, in app-private storage. Embeddings: 1 byte per dimension plus a
4-byte scale per vector (a 384-d text chunk is about 0.4 KB, a 512-d image about 0.5 KB), plus SQLite overhead.

## model.json
```json
{ "id": "minilm-l6-v2-int8", "version": "1", "kind": "sbert", "dim": 384, "max_len": 128, "lowercase": true,
  "query_prefix": "", "doc_prefix": "", "min_score": 0.25, "approx_ram_mb": 150,
  "files": { "model": "model.onnx", "vocab": "vocab.txt" },
  "sha256": { "model.onnx": "<64 hex>", "vocab.txt": "<64 hex>" } }
```
`kind: "clip"` needs files `image`, `text`, `vocab` (vocab.json), `merges` (merges.txt) plus optional `image_size`, `mean`,
`std`, `context_len`, and `names` (`image_input`, `image_output`, `text_output`).

## Versioning and migration
Change `version` (or `id`) when the model files change. Embeddings are stored per `id@version`; the new key starts with
no embeddings, so the next semantic run re-embeds everything (resumable, duplicates reused). Old embeddings are kept
until you choose Index > Delete embeddings of old model versions.

## Calibrate before trusting
`min_score` decides which files count as a meaning match. The defaults (0.25 text, 0.18 image-text) are guesses.
Try known queries on your own files, adjust in model.json, re-import.

## Benchmark and battery
Index > Run benchmark measures model load time, p50/p95 latency, process PSS before/after load, and (unplugged only)
fuel-gauge drain over 60 s of continuous embedding. Reports are saved in app-private storage. Record your numbers in
DEVELOPMENT_PROGRESS.md; none exist yet.
