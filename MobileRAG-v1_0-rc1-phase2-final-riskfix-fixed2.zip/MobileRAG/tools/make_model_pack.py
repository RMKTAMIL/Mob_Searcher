#!/usr/bin/env python3
"""
Builds a MobileRAG model pack folder on a computer WITH internet access. Copy the resulting folder to the phone
and import it from Settings > Semantic search > Import model pack. The app itself never touches the network.

    pip install huggingface_hub
    python tools/make_model_pack.py sbert  ./packs/minilm-l6-v2-int8
    python tools/make_model_pack.py clip   ./packs/clip-vit-b32-int8

STATUS: written but NOT executed by the author (the authoring environment had no access to Hugging Face).
Repository and file names below are as recalled and must be checked; if a download fails, adjust SOURCES.
The script writes SHA-256 hashes of exactly the files it downloaded; the app verifies them on import.
Check each model's license before use.
"""
import hashlib, json, os, shutil, sys

try:
    from huggingface_hub import hf_hub_download
except ImportError:
    sys.exit("pip install huggingface_hub")

SOURCES = {
    "sbert": {
        "repo": "Xenova/all-MiniLM-L6-v2",
        "files": {"model": ("onnx/model_quantized.onnx", "model.onnx"), "vocab": ("vocab.txt", "vocab.txt")},
        "manifest": {
            "id": "minilm-l6-v2-int8", "version": "1", "kind": "sbert", "dim": 384, "max_len": 128, "lowercase": True,
            "min_score": 0.25, "approx_ram_mb": 150,
        },
    },
    "clip": {
        "repo": "Xenova/clip-vit-base-patch32",
        "files": {
            "image": ("onnx/vision_model_quantized.onnx", "image.onnx"),
            "text": ("onnx/text_model_quantized.onnx", "text.onnx"),
            "vocab": ("vocab.json", "vocab.json"),
            "merges": ("merges.txt", "merges.txt"),
        },
        "manifest": {
            "id": "clip-vit-b32-int8", "version": "1", "kind": "clip", "dim": 512, "image_size": 224, "context_len": 77,
            "mean": [0.48145466, 0.4578275, 0.40821073], "std": [0.26862954, 0.26130258, 0.27577711],
            "min_score": 0.18, "approx_ram_mb": 500,
            "names": {"image_input": "pixel_values", "image_output": "image_embeds", "text_output": "text_embeds"},
        },
    },
}


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    if len(sys.argv) != 3 or sys.argv[1] not in SOURCES:
        sys.exit(__doc__)
    spec, out = SOURCES[sys.argv[1]], sys.argv[2]
    os.makedirs(out, exist_ok=True)
    manifest = dict(spec["manifest"])
    manifest["files"], manifest["sha256"] = {}, {}
    total = 0
    for role, (remote, local) in spec["files"].items():
        src = hf_hub_download(spec["repo"], remote)
        dst = os.path.join(out, local)
        shutil.copyfile(src, dst)
        manifest["files"][role] = local
        manifest["sha256"][local] = sha256(dst)
        size = os.path.getsize(dst)
        total += size
        print(f"{local}: {size / 1e6:.1f} MB  sha256={manifest['sha256'][local][:16]}...")
    with open(os.path.join(out, "model.json"), "w") as f:
        json.dump(manifest, f, indent=2)
    print(f"\nPack ready in {out} ({total / 1e6:.1f} MB). Copy it to the phone and import it in the app.")
    print("min_score and approx_ram_mb are UNCALIBRATED defaults: measure on your phone (Index > Benchmark) and edit model.json.")


if __name__ == "__main__":
    main()
