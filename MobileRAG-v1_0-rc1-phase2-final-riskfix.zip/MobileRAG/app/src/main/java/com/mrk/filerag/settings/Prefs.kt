package com.mrk.filerag.settings

import android.content.Context
import com.mrk.filerag.index.IndexOptions
import com.mrk.filerag.power.PowerConfig
import com.mrk.filerag.power.ThermalAction
import com.mrk.filerag.power.ThermalLevel

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("rag_prefs", Context.MODE_PRIVATE)

    private fun b(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun setB(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()

    fun folders(): List<String> = (sp.getString("folders", "") ?: "").split("\n").filter { it.isNotBlank() }
    fun setFolders(l: List<String>) = sp.edit().putString("folders", l.joinToString("\n")).apply()

    var labels: Boolean get() = b("labels", true); set(v) = setB("labels", v)
    var ocr: Boolean get() = b("ocr", true); set(v) = setB("ocr", v)
    var docs: Boolean get() = b("docs", true); set(v) = setB("docs", v)
    var text: Boolean get() = b("text", true); set(v) = setB("text", v)
    var autoIndex: Boolean get() = b("auto_index", false); set(v) = setB("auto_index", v)
    var workers: Int
        get() = sp.getInt("workers", 2)
        set(v) = sp.edit().putInt("workers", v).apply()

    // Semantic search (on-device models). Off until the user provisions models and enables it.
    var semanticEnabled: Boolean get() = b("semantic", false); set(v) = setB("semantic", v)
    var semanticOnlyCharging: Boolean get() = b("semantic_charging", true); set(v) = setB("semantic_charging", v)
    /** Lowest battery percent at which a new semantic batch may start while not charging (0 = no floor). */
    var semanticMinBattery: Int
        get() = sp.getInt("semantic_min_battery", 20)
        set(v) = sp.edit().putInt("semantic_min_battery", v.coerceIn(0, 100)).apply()

    fun thermalAction(level: ThermalLevel): ThermalAction {
        val stored = sp.getString("thermal_" + level.name.lowercase(), null)
        return ThermalAction.values().firstOrNull { it.name == stored } ?: PowerConfig.DEFAULT_THERMAL.getValue(level)
    }
    fun setThermalAction(level: ThermalLevel, action: ThermalAction) =
        sp.edit().putString("thermal_" + level.name.lowercase(), action.name).apply()

    /** Snapshot of the power/thermal preferences for the PowerGate (read again before every batch). */
    fun powerConfig() = PowerConfig(
        requireCharging = semanticOnlyCharging,
        minBatteryPercent = semanticMinBattery,
        thermal = ThermalLevel.values().associateWith { thermalAction(it) }
    )

    var semanticThreads: Int
        get() = sp.getInt("semantic_threads", 2)
        set(v) = sp.edit().putInt("semantic_threads", v).apply()

    var imageBatchSize: Int
        get() = sp.getInt("image_batch_size", 1).let { if (it in listOf(1, 2, 4)) it else 1 }
        set(v) = sp.edit().putInt("image_batch_size", if (v in listOf(1, 2, 4)) v else 1).apply()
    var executionProvider: String
        get() = sp.getString("execution_provider", "CPU") ?: "CPU"
        set(v) = sp.edit().putString("execution_provider", v.takeIf { it in listOf("CPU", "XNNPACK", "NNAPI") } ?: "CPU").apply()
    var thumbnailCacheMb: Int
        get() = sp.getInt("thumbnail_cache_mb", 64).coerceIn(8, 512)
        set(v) = sp.edit().putInt("thumbnail_cache_mb", v.coerceIn(8, 512)).apply()
\n    var activeTextModel: String?
        get() = sp.getString("active_text", null)
        set(v) = sp.edit().putString("active_text", v).apply()
    var activeImageModel: String?
        get() = sp.getString("active_image", null)
        set(v) = sp.edit().putString("active_image", v).apply()

    var runInProgress: Boolean get() = b("run_in_progress", false); set(v) = setB("run_in_progress", v)
    var lastRunStart: Long
        get() = sp.getLong("last_run_start", 0L)
        set(v) = sp.edit().putLong("last_run_start", v).apply()
    var lastRunEnd: Long
        get() = sp.getLong("last_run_end", 0L)
        set(v) = sp.edit().putLong("last_run_end", v).apply()
    var lastSummary: String
        get() = sp.getString("last_summary", "") ?: ""
        set(v) = sp.edit().putString("last_summary", v).apply()

    fun indexOptions() = IndexOptions(
        workers = workers.coerceIn(1, 4), labels = labels, ocr = ocr, docs = docs, text = text
    )
}
